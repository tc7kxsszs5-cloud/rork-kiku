__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "./cjs/react.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "./cjs/react.development.js");
  }
},9,[10,11],"node_modules/react/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},10,[],"node_modules/metro-config/node_modules/metro-runtime/src/modules/empty-module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * react.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function defineDeprecationWarning(methodName, info) {
      Object.defineProperty(Component.prototype, methodName, {
        get: function () {
          console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
        }
      });
    }
    function getIteratorFn(maybeIterable) {
      if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
      maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
      return "function" === typeof maybeIterable ? maybeIterable : null;
    }
    function warnNoop(publicInstance, callerName) {
      publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
      var warningKey = publicInstance + "." + callerName;
      didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
    }
    function Component(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function ComponentDummy() {}
    function PureComponent(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function testStringCoercion(value) {
      return "" + value;
    }
    function checkKeyStringCoercion(value) {
      try {
        testStringCoercion(value);
        var JSCompiler_inline_result = !1;
      } catch (e) {
        JSCompiler_inline_result = !0;
      }
      if (JSCompiler_inline_result) {
        JSCompiler_inline_result = console;
        var JSCompiler_temp_const = JSCompiler_inline_result.error;
        var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
        JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
        return testStringCoercion(value);
      }
    }
    function getComponentNameFromType(type) {
      if (null == type) return null;
      if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if ("string" === typeof type) return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
      }
      if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
        case REACT_PORTAL_TYPE:
          return "Portal";
        case REACT_CONTEXT_TYPE:
          return (type.displayName || "Context") + ".Provider";
        case REACT_CONSUMER_TYPE:
          return (type._context.displayName || "Context") + ".Consumer";
        case REACT_FORWARD_REF_TYPE:
          var innerType = type.render;
          type = type.displayName;
          type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
          return type;
        case REACT_MEMO_TYPE:
          return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
        case REACT_LAZY_TYPE:
          innerType = type._payload;
          type = type._init;
          try {
            return getComponentNameFromType(type(innerType));
          } catch (x) {}
      }
      return null;
    }
    function getTaskName(type) {
      if (type === REACT_FRAGMENT_TYPE) return "<>";
      if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
      try {
        var name = getComponentNameFromType(type);
        return name ? "<" + name + ">" : "<...>";
      } catch (x) {
        return "<...>";
      }
    }
    function getOwner() {
      var dispatcher = ReactSharedInternals.A;
      return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
      return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
      if (hasOwnProperty.call(config, "key")) {
        var getter = Object.getOwnPropertyDescriptor(config, "key").get;
        if (getter && getter.isReactWarning) return !1;
      }
      return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
      function warnAboutAccessingKey() {
        specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
      }
      warnAboutAccessingKey.isReactWarning = !0;
      Object.defineProperty(props, "key", {
        get: warnAboutAccessingKey,
        configurable: !0
      });
    }
    function elementRefGetterWithDeprecationWarning() {
      var componentName = getComponentNameFromType(this.type);
      didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
      componentName = this.props.ref;
      return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, self, source, owner, props, debugStack, debugTask) {
      self = props.ref;
      type = {
        $$typeof: REACT_ELEMENT_TYPE,
        type: type,
        key: key,
        props: props,
        _owner: owner
      };
      null !== (void 0 !== self ? self : null) ? Object.defineProperty(type, "ref", {
        enumerable: !1,
        get: elementRefGetterWithDeprecationWarning
      }) : Object.defineProperty(type, "ref", {
        enumerable: !1,
        value: null
      });
      type._store = {};
      Object.defineProperty(type._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      });
      Object.defineProperty(type, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      });
      Object.defineProperty(type, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugStack
      });
      Object.defineProperty(type, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugTask
      });
      Object.freeze && (Object.freeze(type.props), Object.freeze(type));
      return type;
    }
    function cloneAndReplaceKey(oldElement, newKey) {
      newKey = ReactElement(oldElement.type, newKey, void 0, void 0, oldElement._owner, oldElement.props, oldElement._debugStack, oldElement._debugTask);
      oldElement._store && (newKey._store.validated = oldElement._store.validated);
      return newKey;
    }
    function isValidElement(object) {
      return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    function escape(key) {
      var escaperLookup = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + key.replace(/[=:]/g, function (match) {
        return escaperLookup[match];
      });
    }
    function getElementKey(element, index) {
      return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
    }
    function noop$1() {}
    function resolveThenable(thenable) {
      switch (thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          throw thenable.reason;
        default:
          switch ("string" === typeof thenable.status ? thenable.then(noop$1, noop$1) : (thenable.status = "pending", thenable.then(function (fulfilledValue) {
            "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
          }, function (error) {
            "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          })), thenable.status) {
            case "fulfilled":
              return thenable.value;
            case "rejected":
              throw thenable.reason;
          }
      }
      throw thenable;
    }
    function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
      var type = typeof children;
      if ("undefined" === type || "boolean" === type) children = null;
      var invokeCallback = !1;
      if (null === children) invokeCallback = !0;else switch (type) {
        case "bigint":
        case "string":
        case "number":
          invokeCallback = !0;
          break;
        case "object":
          switch (children.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
              invokeCallback = !0;
              break;
            case REACT_LAZY_TYPE:
              return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
          }
      }
      if (invokeCallback) {
        invokeCallback = children;
        callback = callback(invokeCallback);
        var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
        isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function (c) {
          return c;
        })) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
        return 1;
      }
      invokeCallback = 0;
      childKey = "" === nameSoFar ? "." : nameSoFar + ":";
      if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if ("object" === type) {
        if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
        array = String(children);
        throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
      }
      return invokeCallback;
    }
    function mapChildren(children, func, context) {
      if (null == children) return children;
      var result = [],
        count = 0;
      mapIntoArray(children, result, "", "", function (child) {
        return func.call(context, child, count++);
      });
      return result;
    }
    function lazyInitializer(payload) {
      if (-1 === payload._status) {
        var ctor = payload._result;
        ctor = ctor();
        ctor.then(function (moduleObject) {
          if (0 === payload._status || -1 === payload._status) payload._status = 1, payload._result = moduleObject;
        }, function (error) {
          if (0 === payload._status || -1 === payload._status) payload._status = 2, payload._result = error;
        });
        -1 === payload._status && (payload._status = 0, payload._result = ctor);
      }
      if (1 === payload._status) return ctor = payload._result, void 0 === ctor && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ctor), "default" in ctor || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ctor), ctor.default;
      throw payload._result;
    }
    function resolveDispatcher() {
      var dispatcher = ReactSharedInternals.H;
      null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
      return dispatcher;
    }
    function noop() {}
    function enqueueTask(task) {
      if (null === enqueueTaskImpl) try {
        var requireString = ("require" + Math.random()).slice(0, 7);
        enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
      } catch (_err) {
        enqueueTaskImpl = function (callback) {
          !1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
          var channel = new MessageChannel();
          channel.port1.onmessage = callback;
          channel.port2.postMessage(void 0);
        };
      }
      return enqueueTaskImpl(task);
    }
    function aggregateErrors(errors) {
      return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
    }
    function popActScope(prevActQueue, prevActScopeDepth) {
      prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
      actScopeDepth = prevActScopeDepth;
    }
    function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
      var queue = ReactSharedInternals.actQueue;
      if (null !== queue) if (0 !== queue.length) try {
        flushActQueue(queue);
        enqueueTask(function () {
          return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
        });
        return;
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      } else ReactSharedInternals.actQueue = null;
      0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
    }
    function flushActQueue(queue) {
      if (!isFlushing) {
        isFlushing = !0;
        var i = 0;
        try {
          for (; i < queue.length; i++) {
            var callback = queue[i];
            do {
              ReactSharedInternals.didUsePromise = !1;
              var continuation = callback(!1);
              if (null !== continuation) {
                if (ReactSharedInternals.didUsePromise) {
                  queue[i] = callback;
                  queue.splice(0, i);
                  return;
                }
                callback = continuation;
              } else break;
            } while (1);
          }
          queue.length = 0;
        } catch (error) {
          queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
        } finally {
          isFlushing = !1;
        }
      }
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
      REACT_PORTAL_TYPE = Symbol.for("react.portal"),
      REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
      REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
      REACT_PROFILER_TYPE = Symbol.for("react.profiler");
    Symbol.for("react.provider");
    var REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
      REACT_CONTEXT_TYPE = Symbol.for("react.context"),
      REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
      REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
      REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"),
      REACT_MEMO_TYPE = Symbol.for("react.memo"),
      REACT_LAZY_TYPE = Symbol.for("react.lazy"),
      REACT_ACTIVITY_TYPE = Symbol.for("react.activity"),
      MAYBE_ITERATOR_SYMBOL = Symbol.iterator,
      didWarnStateUpdateForUnmountedComponent = {},
      ReactNoopUpdateQueue = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function (publicInstance) {
          warnNoop(publicInstance, "forceUpdate");
        },
        enqueueReplaceState: function (publicInstance) {
          warnNoop(publicInstance, "replaceState");
        },
        enqueueSetState: function (publicInstance) {
          warnNoop(publicInstance, "setState");
        }
      },
      assign = Object.assign,
      emptyObject = {};
    Object.freeze(emptyObject);
    Component.prototype.isReactComponent = {};
    Component.prototype.setState = function (partialState, callback) {
      if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, partialState, callback, "setState");
    };
    Component.prototype.forceUpdate = function (callback) {
      this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
    };
    var deprecatedAPIs = {
        isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
        replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
      },
      fnName;
    for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
    ComponentDummy.prototype = Component.prototype;
    deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
    deprecatedAPIs.constructor = PureComponent;
    assign(deprecatedAPIs, Component.prototype);
    deprecatedAPIs.isPureReactComponent = !0;
    var isArrayImpl = Array.isArray,
      REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"),
      ReactSharedInternals = {
        H: null,
        A: null,
        T: null,
        S: null,
        V: null,
        actQueue: null,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      },
      hasOwnProperty = Object.prototype.hasOwnProperty,
      createTask = console.createTask ? console.createTask : function () {
        return null;
      };
    deprecatedAPIs = {
      "react-stack-bottom-frame": function (callStackForError) {
        return callStackForError();
      }
    };
    var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = deprecatedAPIs["react-stack-bottom-frame"].bind(deprecatedAPIs, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutMaps = !1,
      userProvidedKeyEscapeRegex = /\/+/g,
      reportGlobalError = "function" === typeof reportError ? reportError : function (error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error: error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      },
      didWarnAboutMessageChannel = !1,
      enqueueTaskImpl = null,
      actScopeDepth = 0,
      didWarnNoAwaitAct = !1,
      isFlushing = !1,
      queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function (callback) {
        queueMicrotask(function () {
          return queueMicrotask(callback);
        });
      } : enqueueTask;
    deprecatedAPIs = Object.freeze({
      __proto__: null,
      c: function (size) {
        return resolveDispatcher().useMemoCache(size);
      }
    });
    exports.Children = {
      map: mapChildren,
      forEach: function (children, forEachFunc, forEachContext) {
        mapChildren(children, function () {
          forEachFunc.apply(this, arguments);
        }, forEachContext);
      },
      count: function (children) {
        var n = 0;
        mapChildren(children, function () {
          n++;
        });
        return n;
      },
      toArray: function (children) {
        return mapChildren(children, function (child) {
          return child;
        }) || [];
      },
      only: function (children) {
        if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
        return children;
      }
    };
    exports.Component = Component;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.PureComponent = PureComponent;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
    exports.__COMPILER_RUNTIME = deprecatedAPIs;
    exports.act = function (callback) {
      var prevActQueue = ReactSharedInternals.actQueue,
        prevActScopeDepth = actScopeDepth;
      actScopeDepth++;
      var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [],
        didAwaitActCall = !1;
      try {
        var result = callback();
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      }
      if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      if (null !== result && "object" === typeof result && "function" === typeof result.then) {
        var thenable = result;
        queueSeveralMicrotasks(function () {
          didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
        });
        return {
          then: function (resolve, reject) {
            didAwaitActCall = !0;
            thenable.then(function (returnValue) {
              popActScope(prevActQueue, prevActScopeDepth);
              if (0 === prevActScopeDepth) {
                try {
                  flushActQueue(queue), enqueueTask(function () {
                    return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                  });
                } catch (error$0) {
                  ReactSharedInternals.thrownErrors.push(error$0);
                }
                if (0 < ReactSharedInternals.thrownErrors.length) {
                  var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
                  ReactSharedInternals.thrownErrors.length = 0;
                  reject(_thrownError);
                }
              } else resolve(returnValue);
            }, function (error) {
              popActScope(prevActQueue, prevActScopeDepth);
              0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
            });
          }
        };
      }
      var returnValue$jscomp$0 = result;
      popActScope(prevActQueue, prevActScopeDepth);
      0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function () {
        didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
      }), ReactSharedInternals.actQueue = null);
      if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      return {
        then: function (resolve, reject) {
          didAwaitActCall = !0;
          0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function () {
            return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
          })) : resolve(returnValue$jscomp$0);
        }
      };
    };
    exports.cache = function (fn) {
      return function () {
        return fn.apply(null, arguments);
      };
    };
    exports.captureOwnerStack = function () {
      var getCurrentStack = ReactSharedInternals.getCurrentStack;
      return null === getCurrentStack ? null : getCurrentStack();
    };
    exports.cloneElement = function (element, config, children) {
      if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
      var props = assign({}, element.props),
        key = element.key,
        owner = element._owner;
      if (null != config) {
        var JSCompiler_inline_result;
        a: {
          if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
            JSCompiler_inline_result = !1;
            break a;
          }
          JSCompiler_inline_result = void 0 !== config.ref;
        }
        JSCompiler_inline_result && (owner = getOwner());
        hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
        for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
      }
      var propName = arguments.length - 2;
      if (1 === propName) props.children = children;else if (1 < propName) {
        JSCompiler_inline_result = Array(propName);
        for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
        props.children = JSCompiler_inline_result;
      }
      props = ReactElement(element.type, key, void 0, void 0, owner, props, element._debugStack, element._debugTask);
      for (key = 2; key < arguments.length; key++) owner = arguments[key], isValidElement(owner) && owner._store && (owner._store.validated = 1);
      return props;
    };
    exports.createContext = function (defaultValue) {
      defaultValue = {
        $$typeof: REACT_CONTEXT_TYPE,
        _currentValue: defaultValue,
        _currentValue2: defaultValue,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      };
      defaultValue.Provider = defaultValue;
      defaultValue.Consumer = {
        $$typeof: REACT_CONSUMER_TYPE,
        _context: defaultValue
      };
      defaultValue._currentRenderer = null;
      defaultValue._currentRenderer2 = null;
      return defaultValue;
    };
    exports.createElement = function (type, config, children) {
      for (var i = 2; i < arguments.length; i++) {
        var node = arguments[i];
        isValidElement(node) && node._store && (node._store.validated = 1);
      }
      i = {};
      node = null;
      if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), node = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
      var childrenLength = arguments.length - 2;
      if (1 === childrenLength) i.children = children;else if (1 < childrenLength) {
        for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
        Object.freeze && Object.freeze(childArray);
        i.children = childArray;
      }
      if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
      node && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
      var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return ReactElement(type, node, void 0, void 0, getOwner(), i, propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
    exports.createRef = function () {
      var refObject = {
        current: null
      };
      Object.seal(refObject);
      return refObject;
    };
    exports.forwardRef = function (render) {
      null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
      null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
      var elementType = {
          $$typeof: REACT_FORWARD_REF_TYPE,
          render: render
        },
        ownName;
      Object.defineProperty(elementType, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          render.name || render.displayName || (Object.defineProperty(render, "name", {
            value: name
          }), render.displayName = name);
        }
      });
      return elementType;
    };
    exports.isValidElement = isValidElement;
    exports.lazy = function (ctor) {
      return {
        $$typeof: REACT_LAZY_TYPE,
        _payload: {
          _status: -1,
          _result: ctor
        },
        _init: lazyInitializer
      };
    };
    exports.memo = function (type, compare) {
      null == type && console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
      compare = {
        $$typeof: REACT_MEMO_TYPE,
        type: type,
        compare: void 0 === compare ? null : compare
      };
      var ownName;
      Object.defineProperty(compare, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          type.name || type.displayName || (Object.defineProperty(type, "name", {
            value: name
          }), type.displayName = name);
        }
      });
      return compare;
    };
    exports.startTransition = function (scope) {
      var prevTransition = ReactSharedInternals.T,
        currentTransition = {};
      ReactSharedInternals.T = currentTransition;
      currentTransition._updatedFibers = new Set();
      try {
        var returnValue = scope(),
          onStartTransitionFinish = ReactSharedInternals.S;
        null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
        "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
      } catch (error) {
        reportGlobalError(error);
      } finally {
        null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), ReactSharedInternals.T = prevTransition;
      }
    };
    exports.unstable_useCacheRefresh = function () {
      return resolveDispatcher().useCacheRefresh();
    };
    exports.use = function (usable) {
      return resolveDispatcher().use(usable);
    };
    exports.useActionState = function (action, initialState, permalink) {
      return resolveDispatcher().useActionState(action, initialState, permalink);
    };
    exports.useCallback = function (callback, deps) {
      return resolveDispatcher().useCallback(callback, deps);
    };
    exports.useContext = function (Context) {
      var dispatcher = resolveDispatcher();
      Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
      return dispatcher.useContext(Context);
    };
    exports.useDebugValue = function (value, formatterFn) {
      return resolveDispatcher().useDebugValue(value, formatterFn);
    };
    exports.useDeferredValue = function (value, initialValue) {
      return resolveDispatcher().useDeferredValue(value, initialValue);
    };
    exports.useEffect = function (create, createDeps, update) {
      null == create && console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      var dispatcher = resolveDispatcher();
      if ("function" === typeof update) throw Error("useEffect CRUD overload is not enabled in this build of React.");
      return dispatcher.useEffect(create, createDeps);
    };
    exports.useId = function () {
      return resolveDispatcher().useId();
    };
    exports.useImperativeHandle = function (ref, create, deps) {
      return resolveDispatcher().useImperativeHandle(ref, create, deps);
    };
    exports.useInsertionEffect = function (create, deps) {
      null == create && console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useInsertionEffect(create, deps);
    };
    exports.useLayoutEffect = function (create, deps) {
      null == create && console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useLayoutEffect(create, deps);
    };
    exports.useMemo = function (create, deps) {
      return resolveDispatcher().useMemo(create, deps);
    };
    exports.useOptimistic = function (passthrough, reducer) {
      return resolveDispatcher().useOptimistic(passthrough, reducer);
    };
    exports.useReducer = function (reducer, initialArg, init) {
      return resolveDispatcher().useReducer(reducer, initialArg, init);
    };
    exports.useRef = function (initialValue) {
      return resolveDispatcher().useRef(initialValue);
    };
    exports.useState = function (initialState) {
      return resolveDispatcher().useState(initialState);
    };
    exports.useSyncExternalStore = function (subscribe, getSnapshot, getServerSnapshot) {
      return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
    };
    exports.useTransition = function () {
      return resolveDispatcher().useTransition();
    };
    exports.version = "19.1.0";
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  }();
},11,[],"node_modules/react/cjs/react.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Trans", {
    enumerable: true,
    get: function () {
      return _TransJs.Trans;
    }
  });
  Object.defineProperty(exports, "TransWithoutContext", {
    enumerable: true,
    get: function () {
      return _TransWithoutContextJs.Trans;
    }
  });
  Object.defineProperty(exports, "IcuTrans", {
    enumerable: true,
    get: function () {
      return _IcuTransJs.IcuTrans;
    }
  });
  Object.defineProperty(exports, "IcuTransWithoutContext", {
    enumerable: true,
    get: function () {
      return _IcuTransWithoutContextJs.IcuTransWithoutContext;
    }
  });
  Object.defineProperty(exports, "useTranslation", {
    enumerable: true,
    get: function () {
      return _useTranslationJs.useTranslation;
    }
  });
  Object.defineProperty(exports, "withTranslation", {
    enumerable: true,
    get: function () {
      return _withTranslationJs.withTranslation;
    }
  });
  Object.defineProperty(exports, "Translation", {
    enumerable: true,
    get: function () {
      return _TranslationJs.Translation;
    }
  });
  Object.defineProperty(exports, "I18nextProvider", {
    enumerable: true,
    get: function () {
      return _I18nextProviderJs.I18nextProvider;
    }
  });
  Object.defineProperty(exports, "withSSR", {
    enumerable: true,
    get: function () {
      return _withSSRJs.withSSR;
    }
  });
  Object.defineProperty(exports, "useSSR", {
    enumerable: true,
    get: function () {
      return _useSSRJs.useSSR;
    }
  });
  Object.defineProperty(exports, "initReactI18next", {
    enumerable: true,
    get: function () {
      return _initReactI18nextJs.initReactI18next;
    }
  });
  Object.defineProperty(exports, "setDefaults", {
    enumerable: true,
    get: function () {
      return _defaultsJs.setDefaults;
    }
  });
  Object.defineProperty(exports, "getDefaults", {
    enumerable: true,
    get: function () {
      return _defaultsJs.getDefaults;
    }
  });
  Object.defineProperty(exports, "setI18n", {
    enumerable: true,
    get: function () {
      return _i18nInstanceJs.setI18n;
    }
  });
  Object.defineProperty(exports, "getI18n", {
    enumerable: true,
    get: function () {
      return _i18nInstanceJs.getI18n;
    }
  });
  Object.defineProperty(exports, "I18nContext", {
    enumerable: true,
    get: function () {
      return _contextJs.I18nContext;
    }
  });
  Object.defineProperty(exports, "composeInitialProps", {
    enumerable: true,
    get: function () {
      return _contextJs.composeInitialProps;
    }
  });
  Object.defineProperty(exports, "getInitialProps", {
    enumerable: true,
    get: function () {
      return _contextJs.getInitialProps;
    }
  });
  Object.defineProperty(exports, "date", {
    enumerable: true,
    get: function () {
      return date;
    }
  });
  Object.defineProperty(exports, "time", {
    enumerable: true,
    get: function () {
      return time;
    }
  });
  Object.defineProperty(exports, "number", {
    enumerable: true,
    get: function () {
      return number;
    }
  });
  Object.defineProperty(exports, "select", {
    enumerable: true,
    get: function () {
      return select;
    }
  });
  Object.defineProperty(exports, "plural", {
    enumerable: true,
    get: function () {
      return plural;
    }
  });
  Object.defineProperty(exports, "selectOrdinal", {
    enumerable: true,
    get: function () {
      return selectOrdinal;
    }
  });
  var _TransJs = require(_dependencyMap[0], "./Trans.js");
  var _TransWithoutContextJs = require(_dependencyMap[1], "./TransWithoutContext.js");
  var _IcuTransJs = require(_dependencyMap[2], "./IcuTrans.js");
  var _IcuTransWithoutContextJs = require(_dependencyMap[3], "./IcuTransWithoutContext.js");
  var _useTranslationJs = require(_dependencyMap[4], "./useTranslation.js");
  var _withTranslationJs = require(_dependencyMap[5], "./withTranslation.js");
  var _TranslationJs = require(_dependencyMap[6], "./Translation.js");
  var _I18nextProviderJs = require(_dependencyMap[7], "./I18nextProvider.js");
  var _withSSRJs = require(_dependencyMap[8], "./withSSR.js");
  var _useSSRJs = require(_dependencyMap[9], "./useSSR.js");
  var _initReactI18nextJs = require(_dependencyMap[10], "./initReactI18next.js");
  var _defaultsJs = require(_dependencyMap[11], "./defaults.js");
  var _i18nInstanceJs = require(_dependencyMap[12], "./i18nInstance.js");
  var _contextJs = require(_dependencyMap[13], "./context.js");
  const date = () => '';
  const time = () => '';
  const number = () => '';
  const select = () => '';
  const plural = () => '';
  const selectOrdinal = () => '';
},2369,[2370,2371,2381,2382,2388,2392,2393,2394,2395,2396,2380,2376,2378,2379],"node_modules/react-i18next/dist/es/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "nodesToString", {
    enumerable: true,
    get: function () {
      return _TransWithoutContextJs.nodesToString;
    }
  });
  exports.Trans = Trans;
  var _react = require(_dependencyMap[0], "react");
  var _TransWithoutContextJs = require(_dependencyMap[1], "./TransWithoutContext.js");
  var _contextJs = require(_dependencyMap[2], "./context.js");
  function Trans({
    children,
    count,
    parent,
    i18nKey,
    context,
    tOptions = {},
    values,
    defaults,
    components,
    ns,
    i18n: i18nFromProps,
    t: tFromProps,
    shouldUnescape,
    ...additionalProps
  }) {
    const {
      i18n: i18nFromContext,
      defaultNS: defaultNSFromContext
    } = (0, _react.useContext)(_contextJs.I18nContext) || {};
    const i18n = i18nFromProps || i18nFromContext || (0, _contextJs.getI18n)();
    const t = tFromProps || i18n?.t.bind(i18n);
    return (0, _TransWithoutContextJs.Trans)({
      children,
      count,
      parent,
      i18nKey,
      context,
      tOptions,
      values,
      defaults,
      components,
      ns: ns || t?.ns || defaultNSFromContext || i18n?.options?.defaultNS,
      i18n,
      t: tFromProps,
      shouldUnescape,
      ...additionalProps
    });
  }
},2370,[9,2371,2379],"node_modules/react-i18next/dist/es/Trans.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "nodesToString", {
    enumerable: true,
    get: function () {
      return nodesToString;
    }
  });
  exports.Trans = Trans;
  var _react = require(_dependencyMap[0], "react");
  var _i18next = require(_dependencyMap[1], "i18next");
  var _htmlParseStringify = require(_dependencyMap[2], "html-parse-stringify");
  var HTML = _interopDefault(_htmlParseStringify);
  var _utilsJs = require(_dependencyMap[3], "./utils.js");
  var _defaultsJs = require(_dependencyMap[4], "./defaults.js");
  var _i18nInstanceJs = require(_dependencyMap[5], "./i18nInstance.js");
  const hasChildren = (node, checkLength) => {
    if (!node) return false;
    const base = node.props?.children ?? node.children;
    if (checkLength) return base.length > 0;
    return !!base;
  };
  const getChildren = node => {
    if (!node) return [];
    const children = node.props?.children ?? node.children;
    return node.props?.i18nIsDynamicList ? getAsArray(children) : children;
  };
  const hasValidReactChildren = children => Array.isArray(children) && children.every(_react.isValidElement);
  const getAsArray = data => Array.isArray(data) ? data : [data];
  const mergeProps = (source, target) => {
    const newTarget = {
      ...target
    };
    newTarget.props = Object.assign(source.props, target.props);
    return newTarget;
  };
  const nodesToString = (children, i18nOptions, i18n, i18nKey) => {
    if (!children) return '';
    let stringNode = '';
    const childrenArray = getAsArray(children);
    const keepArray = i18nOptions?.transSupportBasicHtmlNodes ? i18nOptions.transKeepBasicHtmlNodesFor ?? [] : [];
    childrenArray.forEach((child, childIndex) => {
      if ((0, _utilsJs.isString)(child)) {
        stringNode += `${child}`;
        return;
      }
      if (/*#__PURE__*/(0, _react.isValidElement)(child)) {
        const {
          props,
          type
        } = child;
        const childPropsCount = Object.keys(props).length;
        const shouldKeepChild = keepArray.indexOf(type) > -1;
        const childChildren = props.children;
        if (!childChildren && shouldKeepChild && !childPropsCount) {
          stringNode += `<${type}/>`;
          return;
        }
        if (!childChildren && (!shouldKeepChild || childPropsCount) || props.i18nIsDynamicList) {
          stringNode += `<${childIndex}></${childIndex}>`;
          return;
        }
        if (shouldKeepChild && childPropsCount === 1 && (0, _utilsJs.isString)(childChildren)) {
          stringNode += `<${type}>${childChildren}</${type}>`;
          return;
        }
        const content = nodesToString(childChildren, i18nOptions, i18n, i18nKey);
        stringNode += `<${childIndex}>${content}</${childIndex}>`;
        return;
      }
      if (child === null) {
        (0, _utilsJs.warn)(i18n, 'TRANS_NULL_VALUE', `Passed in a null value as child`, {
          i18nKey
        });
        return;
      }
      if ((0, _utilsJs.isObject)(child)) {
        const {
          format,
          ...clone
        } = child;
        const keys = Object.keys(clone);
        if (keys.length === 1) {
          const value = format ? `${keys[0]}, ${format}` : keys[0];
          stringNode += `{{${value}}}`;
          return;
        }
        (0, _utilsJs.warn)(i18n, 'TRANS_INVALID_OBJ', `Invalid child - Object should only have keys {{ value, format }} (format is optional).`, {
          i18nKey,
          child
        });
        return;
      }
      (0, _utilsJs.warn)(i18n, 'TRANS_INVALID_VAR', `Passed in a variable like {number} - pass variables for interpolation as full objects like {{number}}.`, {
        i18nKey,
        child
      });
    });
    return stringNode;
  };
  const escapeLiteralLessThan = (str, keepArray = [], knownComponentsMap = {}) => {
    if (!str) return str;
    const knownNames = Object.keys(knownComponentsMap);
    const allValidNames = [...keepArray, ...knownNames];
    let result = '';
    let i = 0;
    while (i < str.length) {
      if (str[i] === '<') {
        let isValidTag = false;
        const closingMatch = str.slice(i).match(/^<\/(\d+|[a-zA-Z][a-zA-Z0-9-]*)>/);
        if (closingMatch) {
          const tagName = closingMatch[1];
          if (/^\d+$/.test(tagName) || allValidNames.includes(tagName)) {
            isValidTag = true;
            result += closingMatch[0];
            i += closingMatch[0].length;
          }
        }
        if (!isValidTag) {
          const openingMatch = str.slice(i).match(/^<(\d+|[a-zA-Z][a-zA-Z0-9-]*)(\s+[\w-]+(?:=(?:"[^"]*"|'[^']*'|[^\s>]+))?)*\s*(\/)?>/);
          if (openingMatch) {
            const tagName = openingMatch[1];
            if (/^\d+$/.test(tagName) || allValidNames.includes(tagName)) {
              isValidTag = true;
              result += openingMatch[0];
              i += openingMatch[0].length;
            }
          }
        }
        if (!isValidTag) {
          result += '&lt;';
          i += 1;
        }
      } else {
        result += str[i];
        i += 1;
      }
    }
    return result;
  };
  const renderNodes = (children, knownComponentsMap, targetString, i18n, i18nOptions, combinedTOpts, shouldUnescape) => {
    if (targetString === '') return [];
    const keepArray = i18nOptions.transKeepBasicHtmlNodesFor || [];
    const emptyChildrenButNeedsHandling = targetString && new RegExp(keepArray.map(keep => `<${keep}`).join('|')).test(targetString);
    if (!children && !knownComponentsMap && !emptyChildrenButNeedsHandling && !shouldUnescape) return [targetString];
    const data = knownComponentsMap ?? {};
    const getData = childs => {
      const childrenArray = getAsArray(childs);
      childrenArray.forEach(child => {
        if ((0, _utilsJs.isString)(child)) return;
        if (hasChildren(child)) getData(getChildren(child));else if ((0, _utilsJs.isObject)(child) && ! /*#__PURE__*/(0, _react.isValidElement)(child)) Object.assign(data, child);
      });
    };
    getData(children);
    const escapedString = escapeLiteralLessThan(targetString, keepArray, data);
    const ast = HTML.default.parse(`<0>${escapedString}</0>`);
    const opts = {
      ...data,
      ...combinedTOpts
    };
    const renderInner = (child, node, rootReactNode) => {
      const childs = getChildren(child);
      const mappedChildren = mapAST(childs, node.children, rootReactNode);
      return hasValidReactChildren(childs) && mappedChildren.length === 0 || child.props?.i18nIsDynamicList ? childs : mappedChildren;
    };
    const pushTranslatedJSX = (child, inner, mem, i, isVoid) => {
      if (child.dummy) {
        child.children = inner;
        mem.push(/*#__PURE__*/(0, _react.cloneElement)(child, {
          key: i
        }, isVoid ? undefined : inner));
      } else {
        mem.push(..._react.Children.map([child], c => {
          const INTERNAL_DYNAMIC_MARKER = 'data-i18n-is-dynamic-list';
          const override = {
            key: i,
            [INTERNAL_DYNAMIC_MARKER]: undefined
          };
          if (c && c.props) {
            Object.keys(c.props).forEach(k => {
              if (k === 'ref' || k === 'children' || k === 'i18nIsDynamicList' || k === INTERNAL_DYNAMIC_MARKER) return;
              override[k] = c.props[k];
            });
          }
          return /*#__PURE__*/(0, _react.cloneElement)(c, override, isVoid ? null : inner);
        }));
      }
    };
    const mapAST = (reactNode, astNode, rootReactNode) => {
      const reactNodes = getAsArray(reactNode);
      const astNodes = getAsArray(astNode);
      return astNodes.reduce((mem, node, i) => {
        const translationContent = node.children?.[0]?.content && i18n.services.interpolator.interpolate(node.children[0].content, opts, i18n.language);
        if (node.type === 'tag') {
          let tmp = reactNodes[parseInt(node.name, 10)];
          if (!tmp && knownComponentsMap) tmp = knownComponentsMap[node.name];
          if (rootReactNode.length === 1 && !tmp) tmp = rootReactNode[0][node.name];
          if (!tmp) tmp = {};
          const child = Object.keys(node.attrs).length !== 0 ? mergeProps({
            props: node.attrs
          }, tmp) : tmp;
          const isElement = /*#__PURE__*/(0, _react.isValidElement)(child);
          const isValidTranslationWithChildren = isElement && hasChildren(node, true) && !node.voidElement;
          const isEmptyTransWithHTML = emptyChildrenButNeedsHandling && (0, _utilsJs.isObject)(child) && child.dummy && !isElement;
          const isKnownComponent = (0, _utilsJs.isObject)(knownComponentsMap) && Object.hasOwnProperty.call(knownComponentsMap, node.name);
          if ((0, _utilsJs.isString)(child)) {
            const value = i18n.services.interpolator.interpolate(child, opts, i18n.language);
            mem.push(value);
          } else if (hasChildren(child) || isValidTranslationWithChildren) {
            const inner = renderInner(child, node, rootReactNode);
            pushTranslatedJSX(child, inner, mem, i);
          } else if (isEmptyTransWithHTML) {
            const inner = mapAST(reactNodes, node.children, rootReactNode);
            pushTranslatedJSX(child, inner, mem, i);
          } else if (Number.isNaN(parseFloat(node.name))) {
            if (isKnownComponent) {
              const inner = renderInner(child, node, rootReactNode);
              pushTranslatedJSX(child, inner, mem, i, node.voidElement);
            } else if (i18nOptions.transSupportBasicHtmlNodes && keepArray.indexOf(node.name) > -1) {
              if (node.voidElement) {
                mem.push(/*#__PURE__*/(0, _react.createElement)(node.name, {
                  key: `${node.name}-${i}`
                }));
              } else {
                const inner = mapAST(reactNodes, node.children, rootReactNode);
                mem.push(/*#__PURE__*/(0, _react.createElement)(node.name, {
                  key: `${node.name}-${i}`
                }, inner));
              }
            } else if (node.voidElement) {
              mem.push(`<${node.name} />`);
            } else {
              const inner = mapAST(reactNodes, node.children, rootReactNode);
              mem.push(`<${node.name}>${inner}</${node.name}>`);
            }
          } else if ((0, _utilsJs.isObject)(child) && !isElement) {
            const content = node.children[0] ? translationContent : null;
            if (content) mem.push(content);
          } else {
            pushTranslatedJSX(child, translationContent, mem, i, node.children.length !== 1 || !translationContent);
          }
        } else if (node.type === 'text') {
          const wrapTextNodes = i18nOptions.transWrapTextNodes;
          const content = shouldUnescape ? i18nOptions.unescape(i18n.services.interpolator.interpolate(node.content, opts, i18n.language)) : i18n.services.interpolator.interpolate(node.content, opts, i18n.language);
          if (wrapTextNodes) {
            mem.push(/*#__PURE__*/(0, _react.createElement)(wrapTextNodes, {
              key: `${node.name}-${i}`
            }, content));
          } else {
            mem.push(content);
          }
        }
        return mem;
      }, []);
    };
    const result = mapAST([{
      dummy: true,
      children: children || []
    }], ast, getAsArray(children || []));
    return getChildren(result[0]);
  };
  const fixComponentProps = (component, index, translation) => {
    const componentKey = component.key || index;
    const comp = /*#__PURE__*/(0, _react.cloneElement)(component, {
      key: componentKey
    });
    if (!comp.props || !comp.props.children || translation.indexOf(`${index}/>`) < 0 && translation.indexOf(`${index} />`) < 0) {
      return comp;
    }
    function Componentized() {
      return /*#__PURE__*/(0, _react.createElement)(_react.Fragment, null, comp);
    }
    return /*#__PURE__*/(0, _react.createElement)(Componentized, {
      key: componentKey
    });
  };
  const generateArrayComponents = (components, translation) => components.map((c, index) => fixComponentProps(c, index, translation));
  const generateObjectComponents = (components, translation) => {
    const componentMap = {};
    Object.keys(components).forEach(c => {
      Object.assign(componentMap, {
        [c]: fixComponentProps(components[c], c, translation)
      });
    });
    return componentMap;
  };
  const generateComponents = (components, translation, i18n, i18nKey) => {
    if (!components) return null;
    if (Array.isArray(components)) {
      return generateArrayComponents(components, translation);
    }
    if ((0, _utilsJs.isObject)(components)) {
      return generateObjectComponents(components, translation);
    }
    (0, _utilsJs.warnOnce)(i18n, 'TRANS_INVALID_COMPONENTS', `<Trans /> "components" prop expects an object or array`, {
      i18nKey
    });
    return null;
  };
  const isComponentsMap = object => {
    if (!(0, _utilsJs.isObject)(object)) return false;
    if (Array.isArray(object)) return false;
    return Object.keys(object).reduce((acc, key) => acc && Number.isNaN(Number.parseFloat(key)), true);
  };
  function Trans({
    children,
    count,
    parent,
    i18nKey,
    context,
    tOptions = {},
    values,
    defaults,
    components,
    ns,
    i18n: i18nFromProps,
    t: tFromProps,
    shouldUnescape,
    ...additionalProps
  }) {
    const i18n = i18nFromProps || (0, _i18nInstanceJs.getI18n)();
    if (!i18n) {
      (0, _utilsJs.warnOnce)(i18n, 'NO_I18NEXT_INSTANCE', `Trans: You need to pass in an i18next instance using i18nextReactModule`, {
        i18nKey
      });
      return children;
    }
    const t = tFromProps || i18n.t.bind(i18n) || (k => k);
    const reactI18nextOptions = {
      ...(0, _defaultsJs.getDefaults)(),
      ...i18n.options?.react
    };
    let namespaces = ns || t.ns || i18n.options?.defaultNS;
    namespaces = (0, _utilsJs.isString)(namespaces) ? [namespaces] : namespaces || ['translation'];
    const nodeAsString = nodesToString(children, reactI18nextOptions, i18n, i18nKey);
    const defaultValue = defaults || tOptions?.defaultValue || nodeAsString || reactI18nextOptions.transEmptyNodeValue || (typeof i18nKey === 'function' ? (0, _i18next.keyFromSelector)(i18nKey) : i18nKey);
    const {
      hashTransKey
    } = reactI18nextOptions;
    const key = i18nKey || (hashTransKey ? hashTransKey(nodeAsString || defaultValue) : nodeAsString || defaultValue);
    if (i18n.options?.interpolation?.defaultVariables) {
      values = values && Object.keys(values).length > 0 ? {
        ...values,
        ...i18n.options.interpolation.defaultVariables
      } : {
        ...i18n.options.interpolation.defaultVariables
      };
    }
    const interpolationOverride = values || count !== undefined && !i18n.options?.interpolation?.alwaysFormat || !children ? tOptions.interpolation : {
      interpolation: {
        ...tOptions.interpolation,
        prefix: '#$?',
        suffix: '?$#'
      }
    };
    const combinedTOpts = {
      ...tOptions,
      context: context || tOptions.context,
      count,
      ...values,
      ...interpolationOverride,
      defaultValue,
      ns: namespaces
    };
    let translation = key ? t(key, combinedTOpts) : defaultValue;
    if (translation === key && defaultValue) translation = defaultValue;
    const generatedComponents = generateComponents(components, translation, i18n, i18nKey);
    let indexedChildren = generatedComponents || children;
    let componentsMap = null;
    if (isComponentsMap(generatedComponents)) {
      componentsMap = generatedComponents;
      indexedChildren = children;
    }
    const content = renderNodes(indexedChildren, componentsMap, translation, i18n, reactI18nextOptions, combinedTOpts, shouldUnescape);
    const useAsParent = parent ?? reactI18nextOptions.defaultTransParent;
    return useAsParent ? /*#__PURE__*/(0, _react.createElement)(useAsParent, additionalProps, content) : content;
  }
},2371,[9,2372,2373,2375,2376,2378],"node_modules/react-i18next/dist/es/TransWithoutContext.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "changeLanguage", {
    enumerable: true,
    get: function () {
      return changeLanguage;
    }
  });
  Object.defineProperty(exports, "createInstance", {
    enumerable: true,
    get: function () {
      return createInstance;
    }
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return instance;
    }
  });
  Object.defineProperty(exports, "dir", {
    enumerable: true,
    get: function () {
      return dir;
    }
  });
  Object.defineProperty(exports, "exists", {
    enumerable: true,
    get: function () {
      return exists;
    }
  });
  Object.defineProperty(exports, "getFixedT", {
    enumerable: true,
    get: function () {
      return getFixedT;
    }
  });
  Object.defineProperty(exports, "hasLoadedNamespace", {
    enumerable: true,
    get: function () {
      return hasLoadedNamespace;
    }
  });
  Object.defineProperty(exports, "init", {
    enumerable: true,
    get: function () {
      return init;
    }
  });
  Object.defineProperty(exports, "keyFromSelector", {
    enumerable: true,
    get: function () {
      return keysFromSelector;
    }
  });
  Object.defineProperty(exports, "loadLanguages", {
    enumerable: true,
    get: function () {
      return loadLanguages;
    }
  });
  Object.defineProperty(exports, "loadNamespaces", {
    enumerable: true,
    get: function () {
      return loadNamespaces;
    }
  });
  Object.defineProperty(exports, "loadResources", {
    enumerable: true,
    get: function () {
      return loadResources;
    }
  });
  Object.defineProperty(exports, "reloadResources", {
    enumerable: true,
    get: function () {
      return reloadResources;
    }
  });
  Object.defineProperty(exports, "setDefaultNamespace", {
    enumerable: true,
    get: function () {
      return setDefaultNamespace;
    }
  });
  Object.defineProperty(exports, "t", {
    enumerable: true,
    get: function () {
      return t;
    }
  });
  Object.defineProperty(exports, "use", {
    enumerable: true,
    get: function () {
      return use;
    }
  });
  const isString = obj => typeof obj === 'string';
  const defer = () => {
    let res;
    let rej;
    const promise = new Promise((resolve, reject) => {
      res = resolve;
      rej = reject;
    });
    promise.resolve = res;
    promise.reject = rej;
    return promise;
  };
  const makeString = object => {
    if (object == null) return '';
    return '' + object;
  };
  const copy = (a, s, t) => {
    a.forEach(m => {
      if (s[m]) t[m] = s[m];
    });
  };
  const lastOfPathSeparatorRegExp = /###/g;
  const cleanKey = key => key && key.indexOf('###') > -1 ? key.replace(lastOfPathSeparatorRegExp, '.') : key;
  const canNotTraverseDeeper = object => !object || isString(object);
  const getLastOfPath = (object, path, Empty) => {
    const stack = !isString(path) ? path : path.split('.');
    let stackIndex = 0;
    while (stackIndex < stack.length - 1) {
      if (canNotTraverseDeeper(object)) return {};
      const key = cleanKey(stack[stackIndex]);
      if (!object[key] && Empty) object[key] = new Empty();
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        object = object[key];
      } else {
        object = {};
      }
      ++stackIndex;
    }
    if (canNotTraverseDeeper(object)) return {};
    return {
      obj: object,
      k: cleanKey(stack[stackIndex])
    };
  };
  const setPath = (object, path, newValue) => {
    const {
      obj,
      k
    } = getLastOfPath(object, path, Object);
    if (obj !== undefined || path.length === 1) {
      obj[k] = newValue;
      return;
    }
    let e = path[path.length - 1];
    let p = path.slice(0, path.length - 1);
    let last = getLastOfPath(object, p, Object);
    while (last.obj === undefined && p.length) {
      e = `${p[p.length - 1]}.${e}`;
      p = p.slice(0, p.length - 1);
      last = getLastOfPath(object, p, Object);
      if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== 'undefined') {
        last.obj = undefined;
      }
    }
    last.obj[`${last.k}.${e}`] = newValue;
  };
  const pushPath = (object, path, newValue, concat) => {
    const {
      obj,
      k
    } = getLastOfPath(object, path, Object);
    obj[k] = obj[k] || [];
    obj[k].push(newValue);
  };
  const getPath = (object, path) => {
    const {
      obj,
      k
    } = getLastOfPath(object, path);
    if (!obj) return undefined;
    if (!Object.prototype.hasOwnProperty.call(obj, k)) return undefined;
    return obj[k];
  };
  const getPathWithDefaults = (data, defaultData, key) => {
    const value = getPath(data, key);
    if (value !== undefined) {
      return value;
    }
    return getPath(defaultData, key);
  };
  const deepExtend = (target, source, overwrite) => {
    for (const prop in source) {
      if (prop !== '__proto__' && prop !== 'constructor') {
        if (prop in target) {
          if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
            if (overwrite) target[prop] = source[prop];
          } else {
            deepExtend(target[prop], source[prop], overwrite);
          }
        } else {
          target[prop] = source[prop];
        }
      }
    }
    return target;
  };
  const regexEscape = str => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
  var _entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;'
  };
  const escape = data => {
    if (isString(data)) {
      return data.replace(/[&<>"'\/]/g, s => _entityMap[s]);
    }
    return data;
  };
  class RegExpCache {
    constructor(capacity) {
      this.capacity = capacity;
      this.regExpMap = new Map();
      this.regExpQueue = [];
    }
    getRegExp(pattern) {
      const regExpFromCache = this.regExpMap.get(pattern);
      if (regExpFromCache !== undefined) {
        return regExpFromCache;
      }
      const regExpNew = new RegExp(pattern);
      if (this.regExpQueue.length === this.capacity) {
        this.regExpMap.delete(this.regExpQueue.shift());
      }
      this.regExpMap.set(pattern, regExpNew);
      this.regExpQueue.push(pattern);
      return regExpNew;
    }
  }
  const chars = [' ', ',', '?', '!', ';'];
  const looksLikeObjectPathRegExpCache = new RegExpCache(20);
  const looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
    nsSeparator = nsSeparator || '';
    keySeparator = keySeparator || '';
    const possibleChars = chars.filter(c => nsSeparator.indexOf(c) < 0 && keySeparator.indexOf(c) < 0);
    if (possibleChars.length === 0) return true;
    const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map(c => c === '?' ? '\\?' : c).join('|')})`);
    let matched = !r.test(key);
    if (!matched) {
      const ki = key.indexOf(keySeparator);
      if (ki > 0 && !r.test(key.substring(0, ki))) {
        matched = true;
      }
    }
    return matched;
  };
  const deepFind = (obj, path, keySeparator = '.') => {
    if (!obj) return undefined;
    if (obj[path]) {
      if (!Object.prototype.hasOwnProperty.call(obj, path)) return undefined;
      return obj[path];
    }
    const tokens = path.split(keySeparator);
    let current = obj;
    for (let i = 0; i < tokens.length;) {
      if (!current || typeof current !== 'object') {
        return undefined;
      }
      let next;
      let nextPath = '';
      for (let j = i; j < tokens.length; ++j) {
        if (j !== i) {
          nextPath += keySeparator;
        }
        nextPath += tokens[j];
        next = current[nextPath];
        if (next !== undefined) {
          if (['string', 'number', 'boolean'].indexOf(typeof next) > -1 && j < tokens.length - 1) {
            continue;
          }
          i += j - i + 1;
          break;
        }
      }
      current = next;
    }
    return current;
  };
  const getCleanedCode = code => code?.replace('_', '-');
  const consoleLogger = {
    type: 'logger',
    log(args) {
      this.output('log', args);
    },
    warn(args) {
      this.output('warn', args);
    },
    error(args) {
      this.output('error', args);
    },
    output(type, args) {
      console?.[type]?.apply?.(console, args);
    }
  };
  class Logger {
    constructor(concreteLogger, options = {}) {
      this.init(concreteLogger, options);
    }
    init(concreteLogger, options = {}) {
      this.prefix = options.prefix || 'i18next:';
      this.logger = concreteLogger || consoleLogger;
      this.options = options;
      this.debug = options.debug;
    }
    log(...args) {
      return this.forward(args, 'log', '', true);
    }
    warn(...args) {
      return this.forward(args, 'warn', '', true);
    }
    error(...args) {
      return this.forward(args, 'error', '');
    }
    deprecate(...args) {
      return this.forward(args, 'warn', 'WARNING DEPRECATED: ', true);
    }
    forward(args, lvl, prefix, debugOnly) {
      if (debugOnly && !this.debug) return null;
      if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
      return this.logger[lvl](args);
    }
    create(moduleName) {
      return new Logger(this.logger, {
        ...{
          prefix: `${this.prefix}:${moduleName}:`
        },
        ...this.options
      });
    }
    clone(options) {
      options = options || this.options;
      options.prefix = options.prefix || this.prefix;
      return new Logger(this.logger, options);
    }
  }
  var baseLogger = new Logger();
  class EventEmitter {
    constructor() {
      this.observers = {};
    }
    on(events, listener) {
      events.split(' ').forEach(event => {
        if (!this.observers[event]) this.observers[event] = new Map();
        const numListeners = this.observers[event].get(listener) || 0;
        this.observers[event].set(listener, numListeners + 1);
      });
      return this;
    }
    off(event, listener) {
      if (!this.observers[event]) return;
      if (!listener) {
        delete this.observers[event];
        return;
      }
      this.observers[event].delete(listener);
    }
    emit(event, ...args) {
      if (this.observers[event]) {
        const cloned = Array.from(this.observers[event].entries());
        cloned.forEach(([observer, numTimesAdded]) => {
          for (let i = 0; i < numTimesAdded; i++) {
            observer(...args);
          }
        });
      }
      if (this.observers['*']) {
        const cloned = Array.from(this.observers['*'].entries());
        cloned.forEach(([observer, numTimesAdded]) => {
          for (let i = 0; i < numTimesAdded; i++) {
            observer.apply(observer, [event, ...args]);
          }
        });
      }
    }
  }
  class ResourceStore extends EventEmitter {
    constructor(data, options = {
      ns: ['translation'],
      defaultNS: 'translation'
    }) {
      super();
      this.data = data || {};
      this.options = options;
      if (this.options.keySeparator === undefined) {
        this.options.keySeparator = '.';
      }
      if (this.options.ignoreJSONStructure === undefined) {
        this.options.ignoreJSONStructure = true;
      }
    }
    addNamespaces(ns) {
      if (this.options.ns.indexOf(ns) < 0) {
        this.options.ns.push(ns);
      }
    }
    removeNamespaces(ns) {
      const index = this.options.ns.indexOf(ns);
      if (index > -1) {
        this.options.ns.splice(index, 1);
      }
    }
    getResource(lng, ns, key, options = {}) {
      const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
      const ignoreJSONStructure = options.ignoreJSONStructure !== undefined ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
      let path;
      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
      } else {
        path = [lng, ns];
        if (key) {
          if (Array.isArray(key)) {
            path.push(...key);
          } else if (isString(key) && keySeparator) {
            path.push(...key.split(keySeparator));
          } else {
            path.push(key);
          }
        }
      }
      const result = getPath(this.data, path);
      if (!result && !ns && !key && lng.indexOf('.') > -1) {
        lng = path[0];
        ns = path[1];
        key = path.slice(2).join('.');
      }
      if (result || !ignoreJSONStructure || !isString(key)) return result;
      return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
    }
    addResource(lng, ns, key, value, options = {
      silent: false
    }) {
      const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
      let path = [lng, ns];
      if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
        value = ns;
        ns = path[1];
      }
      this.addNamespaces(ns);
      setPath(this.data, path, value);
      if (!options.silent) this.emit('added', lng, ns, key, value);
    }
    addResources(lng, ns, resources, options = {
      silent: false
    }) {
      for (const m in resources) {
        if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], {
          silent: true
        });
      }
      if (!options.silent) this.emit('added', lng, ns, resources);
    }
    addResourceBundle(lng, ns, resources, deep, overwrite, options = {
      silent: false,
      skipCopy: false
    }) {
      let path = [lng, ns];
      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
        deep = resources;
        resources = ns;
        ns = path[1];
      }
      this.addNamespaces(ns);
      let pack = getPath(this.data, path) || {};
      if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
      if (deep) {
        deepExtend(pack, resources, overwrite);
      } else {
        pack = {
          ...pack,
          ...resources
        };
      }
      setPath(this.data, path, pack);
      if (!options.silent) this.emit('added', lng, ns, resources);
    }
    removeResourceBundle(lng, ns) {
      if (this.hasResourceBundle(lng, ns)) {
        delete this.data[lng][ns];
      }
      this.removeNamespaces(ns);
      this.emit('removed', lng, ns);
    }
    hasResourceBundle(lng, ns) {
      return this.getResource(lng, ns) !== undefined;
    }
    getResourceBundle(lng, ns) {
      if (!ns) ns = this.options.defaultNS;
      return this.getResource(lng, ns);
    }
    getDataByLanguage(lng) {
      return this.data[lng];
    }
    hasLanguageSomeTranslations(lng) {
      const data = this.getDataByLanguage(lng);
      const n = data && Object.keys(data) || [];
      return !!n.find(v => data[v] && Object.keys(data[v]).length > 0);
    }
    toJSON() {
      return this.data;
    }
  }
  var postProcessor = {
    processors: {},
    addPostProcessor(module) {
      this.processors[module.name] = module;
    },
    handle(processors, value, key, options, translator) {
      processors.forEach(processor => {
        value = this.processors[processor]?.process(value, key, options, translator) ?? value;
      });
      return value;
    }
  };
  const PATH_KEY = Symbol('i18next/PATH_KEY');
  function createProxy() {
    const state = [];
    const handler = Object.create(null);
    let proxy;
    handler.get = (target, key) => {
      proxy?.revoke?.();
      if (key === PATH_KEY) return state;
      state.push(key);
      proxy = Proxy.revocable(target, handler);
      return proxy.proxy;
    };
    return Proxy.revocable(Object.create(null), handler).proxy;
  }
  function keysFromSelector(selector, opts) {
    const {
      [PATH_KEY]: path
    } = selector(createProxy());
    return path.join(opts?.keySeparator ?? '.');
  }
  const checkedLoadedFor = {};
  const shouldHandleAsObject = res => !isString(res) && typeof res !== 'boolean' && typeof res !== 'number';
  class Translator extends EventEmitter {
    constructor(services, options = {}) {
      super();
      copy(['resourceStore', 'languageUtils', 'pluralResolver', 'interpolator', 'backendConnector', 'i18nFormat', 'utils'], services, this);
      this.options = options;
      if (this.options.keySeparator === undefined) {
        this.options.keySeparator = '.';
      }
      this.logger = baseLogger.create('translator');
    }
    changeLanguage(lng) {
      if (lng) this.language = lng;
    }
    exists(key, o = {
      interpolation: {}
    }) {
      const opt = {
        ...o
      };
      if (key == null) return false;
      const resolved = this.resolve(key, opt);
      if (resolved?.res === undefined) return false;
      const isObject = shouldHandleAsObject(resolved.res);
      if (opt.returnObjects === false && isObject) {
        return false;
      }
      return true;
    }
    extractFromKey(key, opt) {
      let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
      if (nsSeparator === undefined) nsSeparator = ':';
      const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
      let namespaces = opt.ns || this.options.defaultNS || [];
      const wouldCheckForNsInKey = nsSeparator && key.indexOf(nsSeparator) > -1;
      const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
      if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
        const m = key.match(this.interpolator.nestingRegexp);
        if (m && m.length > 0) {
          return {
            key,
            namespaces: isString(namespaces) ? [namespaces] : namespaces
          };
        }
        const parts = key.split(nsSeparator);
        if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1) namespaces = parts.shift();
        key = parts.join(keySeparator);
      }
      return {
        key,
        namespaces: isString(namespaces) ? [namespaces] : namespaces
      };
    }
    translate(keys, o, lastKey) {
      let opt = typeof o === 'object' ? {
        ...o
      } : o;
      if (typeof opt !== 'object' && this.options.overloadTranslationOptionHandler) {
        opt = this.options.overloadTranslationOptionHandler(arguments);
      }
      if (typeof opt === 'object') opt = {
        ...opt
      };
      if (!opt) opt = {};
      if (keys == null) return '';
      if (typeof keys === 'function') keys = keysFromSelector(keys, {
        ...this.options,
        ...opt
      });
      if (!Array.isArray(keys)) keys = [String(keys)];
      const returnDetails = opt.returnDetails !== undefined ? opt.returnDetails : this.options.returnDetails;
      const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
      const {
        key,
        namespaces
      } = this.extractFromKey(keys[keys.length - 1], opt);
      const namespace = namespaces[namespaces.length - 1];
      let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
      if (nsSeparator === undefined) nsSeparator = ':';
      const lng = opt.lng || this.language;
      const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
      if (lng?.toLowerCase() === 'cimode') {
        if (appendNamespaceToCIMode) {
          if (returnDetails) {
            return {
              res: `${namespace}${nsSeparator}${key}`,
              usedKey: key,
              exactUsedKey: key,
              usedLng: lng,
              usedNS: namespace,
              usedParams: this.getUsedParamsDetails(opt)
            };
          }
          return `${namespace}${nsSeparator}${key}`;
        }
        if (returnDetails) {
          return {
            res: key,
            usedKey: key,
            exactUsedKey: key,
            usedLng: lng,
            usedNS: namespace,
            usedParams: this.getUsedParamsDetails(opt)
          };
        }
        return key;
      }
      const resolved = this.resolve(keys, opt);
      let res = resolved?.res;
      const resUsedKey = resolved?.usedKey || key;
      const resExactUsedKey = resolved?.exactUsedKey || key;
      const noObject = ['[object Number]', '[object Function]', '[object RegExp]'];
      const joinArrays = opt.joinArrays !== undefined ? opt.joinArrays : this.options.joinArrays;
      const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
      const needsPluralHandling = opt.count !== undefined && !isString(opt.count);
      const hasDefaultValue = Translator.hasDefaultValue(opt);
      const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : '';
      const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, {
        ordinal: false
      }) : '';
      const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
      const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
      let resForObjHndl = res;
      if (handleAsObjectInI18nFormat && !res && hasDefaultValue) {
        resForObjHndl = defaultValue;
      }
      const handleAsObject = shouldHandleAsObject(resForObjHndl);
      const resType = Object.prototype.toString.apply(resForObjHndl);
      if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && noObject.indexOf(resType) < 0 && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
        if (!opt.returnObjects && !this.options.returnObjects) {
          if (!this.options.returnedObjectHandler) {
            this.logger.warn('accessing an object - but returnObjects options is not enabled!');
          }
          const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
            ...opt,
            ns: namespaces
          }) : `key '${key} (${this.language})' returned an object instead of string.`;
          if (returnDetails) {
            resolved.res = r;
            resolved.usedParams = this.getUsedParamsDetails(opt);
            return resolved;
          }
          return r;
        }
        if (keySeparator) {
          const resTypeIsArray = Array.isArray(resForObjHndl);
          const copy = resTypeIsArray ? [] : {};
          const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
          for (const m in resForObjHndl) {
            if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
              const deepKey = `${newKeyToUse}${keySeparator}${m}`;
              if (hasDefaultValue && !res) {
                copy[m] = this.translate(deepKey, {
                  ...opt,
                  defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : undefined,
                  ...{
                    joinArrays: false,
                    ns: namespaces
                  }
                });
              } else {
                copy[m] = this.translate(deepKey, {
                  ...opt,
                  ...{
                    joinArrays: false,
                    ns: namespaces
                  }
                });
              }
              if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
            }
          }
          res = copy;
        }
      } else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
        res = res.join(joinArrays);
        if (res) res = this.extendTranslation(res, keys, opt, lastKey);
      } else {
        let usedDefault = false;
        let usedKey = false;
        if (!this.isValidLookup(res) && hasDefaultValue) {
          usedDefault = true;
          res = defaultValue;
        }
        if (!this.isValidLookup(res)) {
          usedKey = true;
          res = key;
        }
        const missingKeyNoValueFallbackToKey = opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey;
        const resForMissing = missingKeyNoValueFallbackToKey && usedKey ? undefined : res;
        const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
        if (usedKey || usedDefault || updateMissing) {
          this.logger.log(updateMissing ? 'updateKey' : 'missingKey', lng, namespace, key, updateMissing ? defaultValue : res);
          if (keySeparator) {
            const fk = this.resolve(key, {
              ...opt,
              keySeparator: false
            });
            if (fk && fk.res) this.logger.warn('Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.');
          }
          let lngs = [];
          const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
          if (this.options.saveMissingTo === 'fallback' && fallbackLngs && fallbackLngs[0]) {
            for (let i = 0; i < fallbackLngs.length; i++) {
              lngs.push(fallbackLngs[i]);
            }
          } else if (this.options.saveMissingTo === 'all') {
            lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
          } else {
            lngs.push(opt.lng || this.language);
          }
          const send = (l, k, specificDefaultValue) => {
            const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
            if (this.options.missingKeyHandler) {
              this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
            } else if (this.backendConnector?.saveMissing) {
              this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
            }
            this.emit('missingKey', l, namespace, k, res);
          };
          if (this.options.saveMissing) {
            if (this.options.saveMissingPlurals && needsPluralHandling) {
              lngs.forEach(language => {
                const suffixes = this.pluralResolver.getSuffixes(language, opt);
                if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && suffixes.indexOf(`${this.options.pluralSeparator}zero`) < 0) {
                  suffixes.push(`${this.options.pluralSeparator}zero`);
                }
                suffixes.forEach(suffix => {
                  send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
                });
              });
            } else {
              send(lngs, key, defaultValue);
            }
          }
        }
        res = this.extendTranslation(res, keys, opt, resolved, lastKey);
        if (usedKey && res === key && this.options.appendNamespaceToMissingKey) {
          res = `${namespace}${nsSeparator}${key}`;
        }
        if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) {
          res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : undefined, opt);
        }
      }
      if (returnDetails) {
        resolved.res = res;
        resolved.usedParams = this.getUsedParamsDetails(opt);
        return resolved;
      }
      return res;
    }
    extendTranslation(res, key, opt, resolved, lastKey) {
      if (this.i18nFormat?.parse) {
        res = this.i18nFormat.parse(res, {
          ...this.options.interpolation.defaultVariables,
          ...opt
        }, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, {
          resolved
        });
      } else if (!opt.skipInterpolation) {
        if (opt.interpolation) this.interpolator.init({
          ...opt,
          ...{
            interpolation: {
              ...this.options.interpolation,
              ...opt.interpolation
            }
          }
        });
        const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== undefined ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
        let nestBef;
        if (skipOnVariables) {
          const nb = res.match(this.interpolator.nestingRegexp);
          nestBef = nb && nb.length;
        }
        let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
        if (this.options.interpolation.defaultVariables) data = {
          ...this.options.interpolation.defaultVariables,
          ...data
        };
        res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
        if (skipOnVariables) {
          const na = res.match(this.interpolator.nestingRegexp);
          const nestAft = na && na.length;
          if (nestBef < nestAft) opt.nest = false;
        }
        if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
        if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
          if (lastKey?.[0] === args[0] && !opt.context) {
            this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
            return null;
          }
          return this.translate(...args, key);
        }, opt);
        if (opt.interpolation) this.interpolator.reset();
      }
      const postProcess = opt.postProcess || this.options.postProcess;
      const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
      if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) {
        res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
          i18nResolved: {
            ...resolved,
            usedParams: this.getUsedParamsDetails(opt)
          },
          ...opt
        } : opt, this);
      }
      return res;
    }
    resolve(keys, opt = {}) {
      let found;
      let usedKey;
      let exactUsedKey;
      let usedLng;
      let usedNS;
      if (isString(keys)) keys = [keys];
      keys.forEach(k => {
        if (this.isValidLookup(found)) return;
        const extracted = this.extractFromKey(k, opt);
        const key = extracted.key;
        usedKey = key;
        let namespaces = extracted.namespaces;
        if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
        const needsPluralHandling = opt.count !== undefined && !isString(opt.count);
        const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
        const needsContextHandling = opt.context !== undefined && (isString(opt.context) || typeof opt.context === 'number') && opt.context !== '';
        const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
        namespaces.forEach(ns => {
          if (this.isValidLookup(found)) return;
          usedNS = ns;
          if (!checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
            checkedLoadedFor[`${codes[0]}-${ns}`] = true;
            this.logger.warn(`key "${usedKey}" for languages "${codes.join(', ')}" won't get resolved as namespace "${usedNS}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
          }
          codes.forEach(code => {
            if (this.isValidLookup(found)) return;
            usedLng = code;
            const finalKeys = [key];
            if (this.i18nFormat?.addLookupKeys) {
              this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
            } else {
              let pluralSuffix;
              if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
              const zeroSuffix = `${this.options.pluralSeparator}zero`;
              const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
              if (needsPluralHandling) {
                if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                  finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                }
                finalKeys.push(key + pluralSuffix);
                if (needsZeroSuffixLookup) {
                  finalKeys.push(key + zeroSuffix);
                }
              }
              if (needsContextHandling) {
                const contextKey = `${key}${this.options.contextSeparator || '_'}${opt.context}`;
                finalKeys.push(contextKey);
                if (needsPluralHandling) {
                  if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                    finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                  }
                  finalKeys.push(contextKey + pluralSuffix);
                  if (needsZeroSuffixLookup) {
                    finalKeys.push(contextKey + zeroSuffix);
                  }
                }
              }
            }
            let possibleKey;
            while (possibleKey = finalKeys.pop()) {
              if (!this.isValidLookup(found)) {
                exactUsedKey = possibleKey;
                found = this.getResource(code, ns, possibleKey, opt);
              }
            }
          });
        });
      });
      return {
        res: found,
        usedKey,
        exactUsedKey,
        usedLng,
        usedNS
      };
    }
    isValidLookup(res) {
      return res !== undefined && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === '');
    }
    getResource(code, ns, key, options = {}) {
      if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
      return this.resourceStore.getResource(code, ns, key, options);
    }
    getUsedParamsDetails(options = {}) {
      const optionsKeys = ['defaultValue', 'ordinal', 'context', 'replace', 'lng', 'lngs', 'fallbackLng', 'ns', 'keySeparator', 'nsSeparator', 'returnObjects', 'returnDetails', 'joinArrays', 'postProcess', 'interpolation'];
      const useOptionsReplaceForData = options.replace && !isString(options.replace);
      let data = useOptionsReplaceForData ? options.replace : options;
      if (useOptionsReplaceForData && typeof options.count !== 'undefined') {
        data.count = options.count;
      }
      if (this.options.interpolation.defaultVariables) {
        data = {
          ...this.options.interpolation.defaultVariables,
          ...data
        };
      }
      if (!useOptionsReplaceForData) {
        data = {
          ...data
        };
        for (const key of optionsKeys) {
          delete data[key];
        }
      }
      return data;
    }
    static hasDefaultValue(options) {
      const prefix = 'defaultValue';
      for (const option in options) {
        if (Object.prototype.hasOwnProperty.call(options, option) && prefix === option.substring(0, prefix.length) && undefined !== options[option]) {
          return true;
        }
      }
      return false;
    }
  }
  class LanguageUtil {
    constructor(options) {
      this.options = options;
      this.supportedLngs = this.options.supportedLngs || false;
      this.logger = baseLogger.create('languageUtils');
    }
    getScriptPartFromCode(code) {
      code = getCleanedCode(code);
      if (!code || code.indexOf('-') < 0) return null;
      const p = code.split('-');
      if (p.length === 2) return null;
      p.pop();
      if (p[p.length - 1].toLowerCase() === 'x') return null;
      return this.formatLanguageCode(p.join('-'));
    }
    getLanguagePartFromCode(code) {
      code = getCleanedCode(code);
      if (!code || code.indexOf('-') < 0) return code;
      const p = code.split('-');
      return this.formatLanguageCode(p[0]);
    }
    formatLanguageCode(code) {
      if (isString(code) && code.indexOf('-') > -1) {
        let formattedCode;
        try {
          formattedCode = Intl.getCanonicalLocales(code)[0];
        } catch (e) {}
        if (formattedCode && this.options.lowerCaseLng) {
          formattedCode = formattedCode.toLowerCase();
        }
        if (formattedCode) return formattedCode;
        if (this.options.lowerCaseLng) {
          return code.toLowerCase();
        }
        return code;
      }
      return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
    }
    isSupportedCode(code) {
      if (this.options.load === 'languageOnly' || this.options.nonExplicitSupportedLngs) {
        code = this.getLanguagePartFromCode(code);
      }
      return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
    }
    getBestMatchFromCodes(codes) {
      if (!codes) return null;
      let found;
      codes.forEach(code => {
        if (found) return;
        const cleanedLng = this.formatLanguageCode(code);
        if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
      });
      if (!found && this.options.supportedLngs) {
        codes.forEach(code => {
          if (found) return;
          const lngScOnly = this.getScriptPartFromCode(code);
          if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
          const lngOnly = this.getLanguagePartFromCode(code);
          if (this.isSupportedCode(lngOnly)) return found = lngOnly;
          found = this.options.supportedLngs.find(supportedLng => {
            if (supportedLng === lngOnly) return supportedLng;
            if (supportedLng.indexOf('-') < 0 && lngOnly.indexOf('-') < 0) return;
            if (supportedLng.indexOf('-') > 0 && lngOnly.indexOf('-') < 0 && supportedLng.substring(0, supportedLng.indexOf('-')) === lngOnly) return supportedLng;
            if (supportedLng.indexOf(lngOnly) === 0 && lngOnly.length > 1) return supportedLng;
          });
        });
      }
      if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
      return found;
    }
    getFallbackCodes(fallbacks, code) {
      if (!fallbacks) return [];
      if (typeof fallbacks === 'function') fallbacks = fallbacks(code);
      if (isString(fallbacks)) fallbacks = [fallbacks];
      if (Array.isArray(fallbacks)) return fallbacks;
      if (!code) return fallbacks.default || [];
      let found = fallbacks[code];
      if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
      if (!found) found = fallbacks[this.formatLanguageCode(code)];
      if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
      if (!found) found = fallbacks.default;
      return found || [];
    }
    toResolveHierarchy(code, fallbackCode) {
      const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
      const codes = [];
      const addCode = c => {
        if (!c) return;
        if (this.isSupportedCode(c)) {
          codes.push(c);
        } else {
          this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
        }
      };
      if (isString(code) && (code.indexOf('-') > -1 || code.indexOf('_') > -1)) {
        if (this.options.load !== 'languageOnly') addCode(this.formatLanguageCode(code));
        if (this.options.load !== 'languageOnly' && this.options.load !== 'currentOnly') addCode(this.getScriptPartFromCode(code));
        if (this.options.load !== 'currentOnly') addCode(this.getLanguagePartFromCode(code));
      } else if (isString(code)) {
        addCode(this.formatLanguageCode(code));
      }
      fallbackCodes.forEach(fc => {
        if (codes.indexOf(fc) < 0) addCode(this.formatLanguageCode(fc));
      });
      return codes;
    }
  }
  const suffixesOrder = {
    zero: 0,
    one: 1,
    two: 2,
    few: 3,
    many: 4,
    other: 5
  };
  const dummyRule = {
    select: count => count === 1 ? 'one' : 'other',
    resolvedOptions: () => ({
      pluralCategories: ['one', 'other']
    })
  };
  class PluralResolver {
    constructor(languageUtils, options = {}) {
      this.languageUtils = languageUtils;
      this.options = options;
      this.logger = baseLogger.create('pluralResolver');
      this.pluralRulesCache = {};
    }
    addRule(lng, obj) {
      this.rules[lng] = obj;
    }
    clearCache() {
      this.pluralRulesCache = {};
    }
    getRule(code, options = {}) {
      const cleanedCode = getCleanedCode(code === 'dev' ? 'en' : code);
      const type = options.ordinal ? 'ordinal' : 'cardinal';
      const cacheKey = JSON.stringify({
        cleanedCode,
        type
      });
      if (cacheKey in this.pluralRulesCache) {
        return this.pluralRulesCache[cacheKey];
      }
      let rule;
      try {
        rule = new Intl.PluralRules(cleanedCode, {
          type
        });
      } catch (err) {
        if (!Intl) {
          this.logger.error('No Intl support, please use an Intl polyfill!');
          return dummyRule;
        }
        if (!code.match(/-|_/)) return dummyRule;
        const lngPart = this.languageUtils.getLanguagePartFromCode(code);
        rule = this.getRule(lngPart, options);
      }
      this.pluralRulesCache[cacheKey] = rule;
      return rule;
    }
    needsPlural(code, options = {}) {
      let rule = this.getRule(code, options);
      if (!rule) rule = this.getRule('dev', options);
      return rule?.resolvedOptions().pluralCategories.length > 1;
    }
    getPluralFormsOfKey(code, key, options = {}) {
      return this.getSuffixes(code, options).map(suffix => `${key}${suffix}`);
    }
    getSuffixes(code, options = {}) {
      let rule = this.getRule(code, options);
      if (!rule) rule = this.getRule('dev', options);
      if (!rule) return [];
      return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map(pluralCategory => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${pluralCategory}`);
    }
    getSuffix(code, count, options = {}) {
      const rule = this.getRule(code, options);
      if (rule) {
        return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${rule.select(count)}`;
      }
      this.logger.warn(`no plural rule found for: ${code}`);
      return this.getSuffix('dev', count, options);
    }
  }
  const deepFindWithDefaults = (data, defaultData, key, keySeparator = '.', ignoreJSONStructure = true) => {
    let path = getPathWithDefaults(data, defaultData, key);
    if (!path && ignoreJSONStructure && isString(key)) {
      path = deepFind(data, key, keySeparator);
      if (path === undefined) path = deepFind(defaultData, key, keySeparator);
    }
    return path;
  };
  const regexSafe = val => val.replace(/\$/g, '$$$$');
  class Interpolator {
    constructor(options = {}) {
      this.logger = baseLogger.create('interpolator');
      this.options = options;
      this.format = options?.interpolation?.format || (value => value);
      this.init(options);
    }
    init(options = {}) {
      if (!options.interpolation) options.interpolation = {
        escapeValue: true
      };
      const {
        escape: escape$1,
        escapeValue,
        useRawValueToEscape,
        prefix,
        prefixEscaped,
        suffix,
        suffixEscaped,
        formatSeparator,
        unescapeSuffix,
        unescapePrefix,
        nestingPrefix,
        nestingPrefixEscaped,
        nestingSuffix,
        nestingSuffixEscaped,
        nestingOptionsSeparator,
        maxReplaces,
        alwaysFormat
      } = options.interpolation;
      this.escape = escape$1 !== undefined ? escape$1 : escape;
      this.escapeValue = escapeValue !== undefined ? escapeValue : true;
      this.useRawValueToEscape = useRawValueToEscape !== undefined ? useRawValueToEscape : false;
      this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || '{{';
      this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || '}}';
      this.formatSeparator = formatSeparator || ',';
      this.unescapePrefix = unescapeSuffix ? '' : unescapePrefix || '-';
      this.unescapeSuffix = this.unescapePrefix ? '' : unescapeSuffix || '';
      this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape('$t(');
      this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(')');
      this.nestingOptionsSeparator = nestingOptionsSeparator || ',';
      this.maxReplaces = maxReplaces || 1000;
      this.alwaysFormat = alwaysFormat !== undefined ? alwaysFormat : false;
      this.resetRegExp();
    }
    reset() {
      if (this.options) this.init(this.options);
    }
    resetRegExp() {
      const getOrResetRegExp = (existingRegExp, pattern) => {
        if (existingRegExp?.source === pattern) {
          existingRegExp.lastIndex = 0;
          return existingRegExp;
        }
        return new RegExp(pattern, 'g');
      };
      this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
      this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
      this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
    }
    interpolate(str, data, lng, options) {
      let match;
      let value;
      let replaces;
      const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
      const handleFormat = key => {
        if (key.indexOf(this.formatSeparator) < 0) {
          const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
          return this.alwaysFormat ? this.format(path, undefined, lng, {
            ...options,
            ...data,
            interpolationkey: key
          }) : path;
        }
        const p = key.split(this.formatSeparator);
        const k = p.shift().trim();
        const f = p.join(this.formatSeparator).trim();
        return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
          ...options,
          ...data,
          interpolationkey: k
        });
      };
      this.resetRegExp();
      const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
      const skipOnVariables = options?.interpolation?.skipOnVariables !== undefined ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
      const todos = [{
        regex: this.regexpUnescape,
        safeValue: val => regexSafe(val)
      }, {
        regex: this.regexp,
        safeValue: val => this.escapeValue ? regexSafe(this.escape(val)) : regexSafe(val)
      }];
      todos.forEach(todo => {
        replaces = 0;
        while (match = todo.regex.exec(str)) {
          const matchedVar = match[1].trim();
          value = handleFormat(matchedVar);
          if (value === undefined) {
            if (typeof missingInterpolationHandler === 'function') {
              const temp = missingInterpolationHandler(str, match, options);
              value = isString(temp) ? temp : '';
            } else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) {
              value = '';
            } else if (skipOnVariables) {
              value = match[0];
              continue;
            } else {
              this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
              value = '';
            }
          } else if (!isString(value) && !this.useRawValueToEscape) {
            value = makeString(value);
          }
          const safeValue = todo.safeValue(value);
          str = str.replace(match[0], safeValue);
          if (skipOnVariables) {
            todo.regex.lastIndex += value.length;
            todo.regex.lastIndex -= match[0].length;
          } else {
            todo.regex.lastIndex = 0;
          }
          replaces++;
          if (replaces >= this.maxReplaces) {
            break;
          }
        }
      });
      return str;
    }
    nest(str, fc, options = {}) {
      let match;
      let value;
      let clonedOptions;
      const handleHasOptions = (key, inheritedOptions) => {
        const sep = this.nestingOptionsSeparator;
        if (key.indexOf(sep) < 0) return key;
        const c = key.split(new RegExp(`${sep}[ ]*{`));
        let optionsString = `{${c[1]}`;
        key = c[0];
        optionsString = this.interpolate(optionsString, clonedOptions);
        const matchedSingleQuotes = optionsString.match(/'/g);
        const matchedDoubleQuotes = optionsString.match(/"/g);
        if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || matchedDoubleQuotes.length % 2 !== 0) {
          optionsString = optionsString.replace(/'/g, '"');
        }
        try {
          clonedOptions = JSON.parse(optionsString);
          if (inheritedOptions) clonedOptions = {
            ...inheritedOptions,
            ...clonedOptions
          };
        } catch (e) {
          this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
          return `${key}${sep}${optionsString}`;
        }
        if (clonedOptions.defaultValue && clonedOptions.defaultValue.indexOf(this.prefix) > -1) delete clonedOptions.defaultValue;
        return key;
      };
      while (match = this.nestingRegexp.exec(str)) {
        let formatters = [];
        clonedOptions = {
          ...options
        };
        clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
        clonedOptions.applyPostProcessor = false;
        delete clonedOptions.defaultValue;
        const keyEndIndex = /{.*}/.test(match[1]) ? match[1].lastIndexOf('}') + 1 : match[1].indexOf(this.formatSeparator);
        if (keyEndIndex !== -1) {
          formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map(elem => elem.trim()).filter(Boolean);
          match[1] = match[1].slice(0, keyEndIndex);
        }
        value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
        if (value && match[0] === str && !isString(value)) return value;
        if (!isString(value)) value = makeString(value);
        if (!value) {
          this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
          value = '';
        }
        if (formatters.length) {
          value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
            ...options,
            interpolationkey: match[1].trim()
          }), value.trim());
        }
        str = str.replace(match[0], value);
        this.regexp.lastIndex = 0;
      }
      return str;
    }
  }
  const parseFormatStr = formatStr => {
    let formatName = formatStr.toLowerCase().trim();
    const formatOptions = {};
    if (formatStr.indexOf('(') > -1) {
      const p = formatStr.split('(');
      formatName = p[0].toLowerCase().trim();
      const optStr = p[1].substring(0, p[1].length - 1);
      if (formatName === 'currency' && optStr.indexOf(':') < 0) {
        if (!formatOptions.currency) formatOptions.currency = optStr.trim();
      } else if (formatName === 'relativetime' && optStr.indexOf(':') < 0) {
        if (!formatOptions.range) formatOptions.range = optStr.trim();
      } else {
        const opts = optStr.split(';');
        opts.forEach(opt => {
          if (opt) {
            const [key, ...rest] = opt.split(':');
            const val = rest.join(':').trim().replace(/^'+|'+$/g, '');
            const trimmedKey = key.trim();
            if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
            if (val === 'false') formatOptions[trimmedKey] = false;
            if (val === 'true') formatOptions[trimmedKey] = true;
            if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
          }
        });
      }
    }
    return {
      formatName,
      formatOptions
    };
  };
  const createCachedFormatter = fn => {
    const cache = {};
    return (v, l, o) => {
      let optForCache = o;
      if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) {
        optForCache = {
          ...optForCache,
          [o.interpolationkey]: undefined
        };
      }
      const key = l + JSON.stringify(optForCache);
      let frm = cache[key];
      if (!frm) {
        frm = fn(getCleanedCode(l), o);
        cache[key] = frm;
      }
      return frm(v);
    };
  };
  const createNonCachedFormatter = fn => (v, l, o) => fn(getCleanedCode(l), o)(v);
  class Formatter {
    constructor(options = {}) {
      this.logger = baseLogger.create('formatter');
      this.options = options;
      this.init(options);
    }
    init(services, options = {
      interpolation: {}
    }) {
      this.formatSeparator = options.interpolation.formatSeparator || ',';
      const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
      this.formats = {
        number: cf((lng, opt) => {
          const formatter = new Intl.NumberFormat(lng, {
            ...opt
          });
          return val => formatter.format(val);
        }),
        currency: cf((lng, opt) => {
          const formatter = new Intl.NumberFormat(lng, {
            ...opt,
            style: 'currency'
          });
          return val => formatter.format(val);
        }),
        datetime: cf((lng, opt) => {
          const formatter = new Intl.DateTimeFormat(lng, {
            ...opt
          });
          return val => formatter.format(val);
        }),
        relativetime: cf((lng, opt) => {
          const formatter = new Intl.RelativeTimeFormat(lng, {
            ...opt
          });
          return val => formatter.format(val, opt.range || 'day');
        }),
        list: cf((lng, opt) => {
          const formatter = new Intl.ListFormat(lng, {
            ...opt
          });
          return val => formatter.format(val);
        })
      };
    }
    add(name, fc) {
      this.formats[name.toLowerCase().trim()] = fc;
    }
    addCached(name, fc) {
      this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
    }
    format(value, format, lng, options = {}) {
      const formats = format.split(this.formatSeparator);
      if (formats.length > 1 && formats[0].indexOf('(') > 1 && formats[0].indexOf(')') < 0 && formats.find(f => f.indexOf(')') > -1)) {
        const lastIndex = formats.findIndex(f => f.indexOf(')') > -1);
        formats[0] = [formats[0], ...formats.splice(1, lastIndex)].join(this.formatSeparator);
      }
      const result = formats.reduce((mem, f) => {
        const {
          formatName,
          formatOptions
        } = parseFormatStr(f);
        if (this.formats[formatName]) {
          let formatted = mem;
          try {
            const valOptions = options?.formatParams?.[options.interpolationkey] || {};
            const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
            formatted = this.formats[formatName](mem, l, {
              ...formatOptions,
              ...options,
              ...valOptions
            });
          } catch (error) {
            this.logger.warn(error);
          }
          return formatted;
        } else {
          this.logger.warn(`there was no format function for ${formatName}`);
        }
        return mem;
      }, value);
      return result;
    }
  }
  const removePending = (q, name) => {
    if (q.pending[name] !== undefined) {
      delete q.pending[name];
      q.pendingCount--;
    }
  };
  class Connector extends EventEmitter {
    constructor(backend, store, services, options = {}) {
      super();
      this.backend = backend;
      this.store = store;
      this.services = services;
      this.languageUtils = services.languageUtils;
      this.options = options;
      this.logger = baseLogger.create('backendConnector');
      this.waitingReads = [];
      this.maxParallelReads = options.maxParallelReads || 10;
      this.readingCalls = 0;
      this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
      this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
      this.state = {};
      this.queue = [];
      this.backend?.init?.(services, options.backend, options);
    }
    queueLoad(languages, namespaces, options, callback) {
      const toLoad = {};
      const pending = {};
      const toLoadLanguages = {};
      const toLoadNamespaces = {};
      languages.forEach(lng => {
        let hasAllNamespaces = true;
        namespaces.forEach(ns => {
          const name = `${lng}|${ns}`;
          if (!options.reload && this.store.hasResourceBundle(lng, ns)) {
            this.state[name] = 2;
          } else if (this.state[name] < 0) ;else if (this.state[name] === 1) {
            if (pending[name] === undefined) pending[name] = true;
          } else {
            this.state[name] = 1;
            hasAllNamespaces = false;
            if (pending[name] === undefined) pending[name] = true;
            if (toLoad[name] === undefined) toLoad[name] = true;
            if (toLoadNamespaces[ns] === undefined) toLoadNamespaces[ns] = true;
          }
        });
        if (!hasAllNamespaces) toLoadLanguages[lng] = true;
      });
      if (Object.keys(toLoad).length || Object.keys(pending).length) {
        this.queue.push({
          pending,
          pendingCount: Object.keys(pending).length,
          loaded: {},
          errors: [],
          callback
        });
      }
      return {
        toLoad: Object.keys(toLoad),
        pending: Object.keys(pending),
        toLoadLanguages: Object.keys(toLoadLanguages),
        toLoadNamespaces: Object.keys(toLoadNamespaces)
      };
    }
    loaded(name, err, data) {
      const s = name.split('|');
      const lng = s[0];
      const ns = s[1];
      if (err) this.emit('failedLoading', lng, ns, err);
      if (!err && data) {
        this.store.addResourceBundle(lng, ns, data, undefined, undefined, {
          skipCopy: true
        });
      }
      this.state[name] = err ? -1 : 2;
      if (err && data) this.state[name] = 0;
      const loaded = {};
      this.queue.forEach(q => {
        pushPath(q.loaded, [lng], ns);
        removePending(q, name);
        if (err) q.errors.push(err);
        if (q.pendingCount === 0 && !q.done) {
          Object.keys(q.loaded).forEach(l => {
            if (!loaded[l]) loaded[l] = {};
            const loadedKeys = q.loaded[l];
            if (loadedKeys.length) {
              loadedKeys.forEach(n => {
                if (loaded[l][n] === undefined) loaded[l][n] = true;
              });
            }
          });
          q.done = true;
          if (q.errors.length) {
            q.callback(q.errors);
          } else {
            q.callback();
          }
        }
      });
      this.emit('loaded', loaded);
      this.queue = this.queue.filter(q => !q.done);
    }
    read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
      if (!lng.length) return callback(null, {});
      if (this.readingCalls >= this.maxParallelReads) {
        this.waitingReads.push({
          lng,
          ns,
          fcName,
          tried,
          wait,
          callback
        });
        return;
      }
      this.readingCalls++;
      const resolver = (err, data) => {
        this.readingCalls--;
        if (this.waitingReads.length > 0) {
          const next = this.waitingReads.shift();
          this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
        }
        if (err && data && tried < this.maxRetries) {
          setTimeout(() => {
            this.read.call(this, lng, ns, fcName, tried + 1, wait * 2, callback);
          }, wait);
          return;
        }
        callback(err, data);
      };
      const fc = this.backend[fcName].bind(this.backend);
      if (fc.length === 2) {
        try {
          const r = fc(lng, ns);
          if (r && typeof r.then === 'function') {
            r.then(data => resolver(null, data)).catch(resolver);
          } else {
            resolver(null, r);
          }
        } catch (err) {
          resolver(err);
        }
        return;
      }
      return fc(lng, ns, resolver);
    }
    prepareLoading(languages, namespaces, options = {}, callback) {
      if (!this.backend) {
        this.logger.warn('No backend was added via i18next.use. Will not load resources.');
        return callback && callback();
      }
      if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
      if (isString(namespaces)) namespaces = [namespaces];
      const toLoad = this.queueLoad(languages, namespaces, options, callback);
      if (!toLoad.toLoad.length) {
        if (!toLoad.pending.length) callback();
        return null;
      }
      toLoad.toLoad.forEach(name => {
        this.loadOne(name);
      });
    }
    load(languages, namespaces, callback) {
      this.prepareLoading(languages, namespaces, {}, callback);
    }
    reload(languages, namespaces, callback) {
      this.prepareLoading(languages, namespaces, {
        reload: true
      }, callback);
    }
    loadOne(name, prefix = '') {
      const s = name.split('|');
      const lng = s[0];
      const ns = s[1];
      this.read(lng, ns, 'read', undefined, undefined, (err, data) => {
        if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
        if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
        this.loaded(name, err, data);
      });
    }
    saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
      if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
        this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
        return;
      }
      if (key === undefined || key === null || key === '') return;
      if (this.backend?.create) {
        const opts = {
          ...options,
          isUpdate
        };
        const fc = this.backend.create.bind(this.backend);
        if (fc.length < 6) {
          try {
            let r;
            if (fc.length === 5) {
              r = fc(languages, namespace, key, fallbackValue, opts);
            } else {
              r = fc(languages, namespace, key, fallbackValue);
            }
            if (r && typeof r.then === 'function') {
              r.then(data => clb(null, data)).catch(clb);
            } else {
              clb(null, r);
            }
          } catch (err) {
            clb(err);
          }
        } else {
          fc(languages, namespace, key, fallbackValue, clb, opts);
        }
      }
      if (!languages || !languages[0]) return;
      this.store.addResource(languages[0], namespace, key, fallbackValue);
    }
  }
  const get = () => ({
    debug: false,
    initAsync: true,
    ns: ['translation'],
    defaultNS: ['translation'],
    fallbackLng: ['dev'],
    fallbackNS: false,
    supportedLngs: false,
    nonExplicitSupportedLngs: false,
    load: 'all',
    preload: false,
    simplifyPluralSuffix: true,
    keySeparator: '.',
    nsSeparator: ':',
    pluralSeparator: '_',
    contextSeparator: '_',
    partialBundledLanguages: false,
    saveMissing: false,
    updateMissing: false,
    saveMissingTo: 'fallback',
    saveMissingPlurals: true,
    missingKeyHandler: false,
    missingInterpolationHandler: false,
    postProcess: false,
    postProcessPassResolved: false,
    returnNull: false,
    returnEmptyString: true,
    returnObjects: false,
    joinArrays: false,
    returnedObjectHandler: false,
    parseMissingKeyHandler: false,
    appendNamespaceToMissingKey: false,
    appendNamespaceToCIMode: false,
    overloadTranslationOptionHandler: args => {
      let ret = {};
      if (typeof args[1] === 'object') ret = args[1];
      if (isString(args[1])) ret.defaultValue = args[1];
      if (isString(args[2])) ret.tDescription = args[2];
      if (typeof args[2] === 'object' || typeof args[3] === 'object') {
        const options = args[3] || args[2];
        Object.keys(options).forEach(key => {
          ret[key] = options[key];
        });
      }
      return ret;
    },
    interpolation: {
      escapeValue: true,
      format: value => value,
      prefix: '{{',
      suffix: '}}',
      formatSeparator: ',',
      unescapePrefix: '-',
      nestingPrefix: '$t(',
      nestingSuffix: ')',
      nestingOptionsSeparator: ',',
      maxReplaces: 1000,
      skipOnVariables: true
    },
    cacheInBuiltFormats: true
  });
  const transformOptions = options => {
    if (isString(options.ns)) options.ns = [options.ns];
    if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
    if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
    if (options.supportedLngs?.indexOf?.('cimode') < 0) {
      options.supportedLngs = options.supportedLngs.concat(['cimode']);
    }
    if (typeof options.initImmediate === 'boolean') options.initAsync = options.initImmediate;
    return options;
  };
  const noop = () => {};
  const bindMemberFunctions = inst => {
    const mems = Object.getOwnPropertyNames(Object.getPrototypeOf(inst));
    mems.forEach(mem => {
      if (typeof inst[mem] === 'function') {
        inst[mem] = inst[mem].bind(inst);
      }
    });
  };
  class I18n extends EventEmitter {
    constructor(options = {}, callback) {
      super();
      this.options = transformOptions(options);
      this.services = {};
      this.logger = baseLogger;
      this.modules = {
        external: []
      };
      bindMemberFunctions(this);
      if (callback && !this.isInitialized && !options.isClone) {
        if (!this.options.initAsync) {
          this.init(options, callback);
          return this;
        }
        setTimeout(() => {
          this.init(options, callback);
        }, 0);
      }
    }
    init(options = {}, callback) {
      this.isInitializing = true;
      if (typeof options === 'function') {
        callback = options;
        options = {};
      }
      if (options.defaultNS == null && options.ns) {
        if (isString(options.ns)) {
          options.defaultNS = options.ns;
        } else if (options.ns.indexOf('translation') < 0) {
          options.defaultNS = options.ns[0];
        }
      }
      const defOpts = get();
      this.options = {
        ...defOpts,
        ...this.options,
        ...transformOptions(options)
      };
      this.options.interpolation = {
        ...defOpts.interpolation,
        ...this.options.interpolation
      };
      if (options.keySeparator !== undefined) {
        this.options.userDefinedKeySeparator = options.keySeparator;
      }
      if (options.nsSeparator !== undefined) {
        this.options.userDefinedNsSeparator = options.nsSeparator;
      }
      const createClassOnDemand = ClassOrObject => {
        if (!ClassOrObject) return null;
        if (typeof ClassOrObject === 'function') return new ClassOrObject();
        return ClassOrObject;
      };
      if (!this.options.isClone) {
        if (this.modules.logger) {
          baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
        } else {
          baseLogger.init(null, this.options);
        }
        let formatter;
        if (this.modules.formatter) {
          formatter = this.modules.formatter;
        } else {
          formatter = Formatter;
        }
        const lu = new LanguageUtil(this.options);
        this.store = new ResourceStore(this.options.resources, this.options);
        const s = this.services;
        s.logger = baseLogger;
        s.resourceStore = this.store;
        s.languageUtils = lu;
        s.pluralResolver = new PluralResolver(lu, {
          prepend: this.options.pluralSeparator,
          simplifyPluralSuffix: this.options.simplifyPluralSuffix
        });
        const usingLegacyFormatFunction = this.options.interpolation.format && this.options.interpolation.format !== defOpts.interpolation.format;
        if (usingLegacyFormatFunction) {
          this.logger.deprecate(`init: you are still using the legacy format function, please use the new approach: https://www.i18next.com/translation-function/formatting`);
        }
        if (formatter && (!this.options.interpolation.format || this.options.interpolation.format === defOpts.interpolation.format)) {
          s.formatter = createClassOnDemand(formatter);
          if (s.formatter.init) s.formatter.init(s, this.options);
          this.options.interpolation.format = s.formatter.format.bind(s.formatter);
        }
        s.interpolator = new Interpolator(this.options);
        s.utils = {
          hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
        };
        s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
        s.backendConnector.on('*', (event, ...args) => {
          this.emit(event, ...args);
        });
        if (this.modules.languageDetector) {
          s.languageDetector = createClassOnDemand(this.modules.languageDetector);
          if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
        }
        if (this.modules.i18nFormat) {
          s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
          if (s.i18nFormat.init) s.i18nFormat.init(this);
        }
        this.translator = new Translator(this.services, this.options);
        this.translator.on('*', (event, ...args) => {
          this.emit(event, ...args);
        });
        this.modules.external.forEach(m => {
          if (m.init) m.init(this);
        });
      }
      this.format = this.options.interpolation.format;
      if (!callback) callback = noop;
      if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
        const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        if (codes.length > 0 && codes[0] !== 'dev') this.options.lng = codes[0];
      }
      if (!this.services.languageDetector && !this.options.lng) {
        this.logger.warn('init: no languageDetector is used and no lng is defined');
      }
      const storeApi = ['getResource', 'hasResourceBundle', 'getResourceBundle', 'getDataByLanguage'];
      storeApi.forEach(fcName => {
        this[fcName] = (...args) => this.store[fcName](...args);
      });
      const storeApiChained = ['addResource', 'addResources', 'addResourceBundle', 'removeResourceBundle'];
      storeApiChained.forEach(fcName => {
        this[fcName] = (...args) => {
          this.store[fcName](...args);
          return this;
        };
      });
      const deferred = defer();
      const load = () => {
        const finish = (err, t) => {
          this.isInitializing = false;
          if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn('init: i18next is already initialized. You should call init just once!');
          this.isInitialized = true;
          if (!this.options.isClone) this.logger.log('initialized', this.options);
          this.emit('initialized', this.options);
          deferred.resolve(t);
          callback(err, t);
        };
        if (this.languages && !this.isInitialized) return finish(null, this.t.bind(this));
        this.changeLanguage(this.options.lng, finish);
      };
      if (this.options.resources || !this.options.initAsync) {
        load();
      } else {
        setTimeout(load, 0);
      }
      return deferred;
    }
    loadResources(language, callback = noop) {
      let usedCallback = callback;
      const usedLng = isString(language) ? language : this.language;
      if (typeof language === 'function') usedCallback = language;
      if (!this.options.resources || this.options.partialBundledLanguages) {
        if (usedLng?.toLowerCase() === 'cimode' && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
        const toLoad = [];
        const append = lng => {
          if (!lng) return;
          if (lng === 'cimode') return;
          const lngs = this.services.languageUtils.toResolveHierarchy(lng);
          lngs.forEach(l => {
            if (l === 'cimode') return;
            if (toLoad.indexOf(l) < 0) toLoad.push(l);
          });
        };
        if (!usedLng) {
          const fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
          fallbacks.forEach(l => append(l));
        } else {
          append(usedLng);
        }
        this.options.preload?.forEach?.(l => append(l));
        this.services.backendConnector.load(toLoad, this.options.ns, e => {
          if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
          usedCallback(e);
        });
      } else {
        usedCallback(null);
      }
    }
    reloadResources(lngs, ns, callback) {
      const deferred = defer();
      if (typeof lngs === 'function') {
        callback = lngs;
        lngs = undefined;
      }
      if (typeof ns === 'function') {
        callback = ns;
        ns = undefined;
      }
      if (!lngs) lngs = this.languages;
      if (!ns) ns = this.options.ns;
      if (!callback) callback = noop;
      this.services.backendConnector.reload(lngs, ns, err => {
        deferred.resolve();
        callback(err);
      });
      return deferred;
    }
    use(module) {
      if (!module) throw new Error('You are passing an undefined module! Please check the object you are passing to i18next.use()');
      if (!module.type) throw new Error('You are passing a wrong module! Please check the object you are passing to i18next.use()');
      if (module.type === 'backend') {
        this.modules.backend = module;
      }
      if (module.type === 'logger' || module.log && module.warn && module.error) {
        this.modules.logger = module;
      }
      if (module.type === 'languageDetector') {
        this.modules.languageDetector = module;
      }
      if (module.type === 'i18nFormat') {
        this.modules.i18nFormat = module;
      }
      if (module.type === 'postProcessor') {
        postProcessor.addPostProcessor(module);
      }
      if (module.type === 'formatter') {
        this.modules.formatter = module;
      }
      if (module.type === '3rdParty') {
        this.modules.external.push(module);
      }
      return this;
    }
    setResolvedLanguage(l) {
      if (!l || !this.languages) return;
      if (['cimode', 'dev'].indexOf(l) > -1) return;
      for (let li = 0; li < this.languages.length; li++) {
        const lngInLngs = this.languages[li];
        if (['cimode', 'dev'].indexOf(lngInLngs) > -1) continue;
        if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
          this.resolvedLanguage = lngInLngs;
          break;
        }
      }
      if (!this.resolvedLanguage && this.languages.indexOf(l) < 0 && this.store.hasLanguageSomeTranslations(l)) {
        this.resolvedLanguage = l;
        this.languages.unshift(l);
      }
    }
    changeLanguage(lng, callback) {
      this.isLanguageChangingTo = lng;
      const deferred = defer();
      this.emit('languageChanging', lng);
      const setLngProps = l => {
        this.language = l;
        this.languages = this.services.languageUtils.toResolveHierarchy(l);
        this.resolvedLanguage = undefined;
        this.setResolvedLanguage(l);
      };
      const done = (err, l) => {
        if (l) {
          if (this.isLanguageChangingTo === lng) {
            setLngProps(l);
            this.translator.changeLanguage(l);
            this.isLanguageChangingTo = undefined;
            this.emit('languageChanged', l);
            this.logger.log('languageChanged', l);
          }
        } else {
          this.isLanguageChangingTo = undefined;
        }
        deferred.resolve((...args) => this.t(...args));
        if (callback) callback(err, (...args) => this.t(...args));
      };
      const setLng = lngs => {
        if (!lng && !lngs && this.services.languageDetector) lngs = [];
        const fl = isString(lngs) ? lngs : lngs && lngs[0];
        const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
        if (l) {
          if (!this.language) {
            setLngProps(l);
          }
          if (!this.translator.language) this.translator.changeLanguage(l);
          this.services.languageDetector?.cacheUserLanguage?.(l);
        }
        this.loadResources(l, err => {
          done(err, l);
        });
      };
      if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
        setLng(this.services.languageDetector.detect());
      } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
        if (this.services.languageDetector.detect.length === 0) {
          this.services.languageDetector.detect().then(setLng);
        } else {
          this.services.languageDetector.detect(setLng);
        }
      } else {
        setLng(lng);
      }
      return deferred;
    }
    getFixedT(lng, ns, keyPrefix) {
      const fixedT = (key, opts, ...rest) => {
        let o;
        if (typeof opts !== 'object') {
          o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
        } else {
          o = {
            ...opts
          };
        }
        o.lng = o.lng || fixedT.lng;
        o.lngs = o.lngs || fixedT.lngs;
        o.ns = o.ns || fixedT.ns;
        if (o.keyPrefix !== '') o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
        const keySeparator = this.options.keySeparator || '.';
        let resultKey;
        if (o.keyPrefix && Array.isArray(key)) {
          resultKey = key.map(k => {
            if (typeof k === 'function') k = keysFromSelector(k, {
              ...this.options,
              ...opts
            });
            return `${o.keyPrefix}${keySeparator}${k}`;
          });
        } else {
          if (typeof key === 'function') key = keysFromSelector(key, {
            ...this.options,
            ...opts
          });
          resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
        }
        return this.t(resultKey, o);
      };
      if (isString(lng)) {
        fixedT.lng = lng;
      } else {
        fixedT.lngs = lng;
      }
      fixedT.ns = ns;
      fixedT.keyPrefix = keyPrefix;
      return fixedT;
    }
    t(...args) {
      return this.translator?.translate(...args);
    }
    exists(...args) {
      return this.translator?.exists(...args);
    }
    setDefaultNamespace(ns) {
      this.options.defaultNS = ns;
    }
    hasLoadedNamespace(ns, options = {}) {
      if (!this.isInitialized) {
        this.logger.warn('hasLoadedNamespace: i18next was not initialized', this.languages);
        return false;
      }
      if (!this.languages || !this.languages.length) {
        this.logger.warn('hasLoadedNamespace: i18n.languages were undefined or empty', this.languages);
        return false;
      }
      const lng = options.lng || this.resolvedLanguage || this.languages[0];
      const fallbackLng = this.options ? this.options.fallbackLng : false;
      const lastLng = this.languages[this.languages.length - 1];
      if (lng.toLowerCase() === 'cimode') return true;
      const loadNotPending = (l, n) => {
        const loadState = this.services.backendConnector.state[`${l}|${n}`];
        return loadState === -1 || loadState === 0 || loadState === 2;
      };
      if (options.precheck) {
        const preResult = options.precheck(this, loadNotPending);
        if (preResult !== undefined) return preResult;
      }
      if (this.hasResourceBundle(lng, ns)) return true;
      if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
      if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
      return false;
    }
    loadNamespaces(ns, callback) {
      const deferred = defer();
      if (!this.options.ns) {
        if (callback) callback();
        return Promise.resolve();
      }
      if (isString(ns)) ns = [ns];
      ns.forEach(n => {
        if (this.options.ns.indexOf(n) < 0) this.options.ns.push(n);
      });
      this.loadResources(err => {
        deferred.resolve();
        if (callback) callback(err);
      });
      return deferred;
    }
    loadLanguages(lngs, callback) {
      const deferred = defer();
      if (isString(lngs)) lngs = [lngs];
      const preloaded = this.options.preload || [];
      const newLngs = lngs.filter(lng => preloaded.indexOf(lng) < 0 && this.services.languageUtils.isSupportedCode(lng));
      if (!newLngs.length) {
        if (callback) callback();
        return Promise.resolve();
      }
      this.options.preload = preloaded.concat(newLngs);
      this.loadResources(err => {
        deferred.resolve();
        if (callback) callback(err);
      });
      return deferred;
    }
    dir(lng) {
      if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
      if (!lng) return 'rtl';
      try {
        const l = new Intl.Locale(lng);
        if (l && l.getTextInfo) {
          const ti = l.getTextInfo();
          if (ti && ti.direction) return ti.direction;
        }
      } catch (e) {}
      const rtlLngs = ['ar', 'shu', 'sqr', 'ssh', 'xaa', 'yhd', 'yud', 'aao', 'abh', 'abv', 'acm', 'acq', 'acw', 'acx', 'acy', 'adf', 'ads', 'aeb', 'aec', 'afb', 'ajp', 'apc', 'apd', 'arb', 'arq', 'ars', 'ary', 'arz', 'auz', 'avl', 'ayh', 'ayl', 'ayn', 'ayp', 'bbz', 'pga', 'he', 'iw', 'ps', 'pbt', 'pbu', 'pst', 'prp', 'prd', 'ug', 'ur', 'ydd', 'yds', 'yih', 'ji', 'yi', 'hbo', 'men', 'xmn', 'fa', 'jpr', 'peo', 'pes', 'prs', 'dv', 'sam', 'ckb'];
      const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
      if (lng.toLowerCase().indexOf('-latn') > 1) return 'ltr';
      return rtlLngs.indexOf(languageUtils.getLanguagePartFromCode(lng)) > -1 || lng.toLowerCase().indexOf('-arab') > 1 ? 'rtl' : 'ltr';
    }
    static createInstance(options = {}, callback) {
      const instance = new I18n(options, callback);
      instance.createInstance = I18n.createInstance;
      return instance;
    }
    cloneInstance(options = {}, callback = noop) {
      const forkResourceStore = options.forkResourceStore;
      if (forkResourceStore) delete options.forkResourceStore;
      const mergedOptions = {
        ...this.options,
        ...options,
        ...{
          isClone: true
        }
      };
      const clone = new I18n(mergedOptions);
      if (options.debug !== undefined || options.prefix !== undefined) {
        clone.logger = clone.logger.clone(options);
      }
      const membersToCopy = ['store', 'services', 'language'];
      membersToCopy.forEach(m => {
        clone[m] = this[m];
      });
      clone.services = {
        ...this.services
      };
      clone.services.utils = {
        hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
      };
      if (forkResourceStore) {
        const clonedData = Object.keys(this.store.data).reduce((prev, l) => {
          prev[l] = {
            ...this.store.data[l]
          };
          prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
            acc[n] = {
              ...prev[l][n]
            };
            return acc;
          }, prev[l]);
          return prev;
        }, {});
        clone.store = new ResourceStore(clonedData, mergedOptions);
        clone.services.resourceStore = clone.store;
      }
      clone.translator = new Translator(clone.services, mergedOptions);
      clone.translator.on('*', (event, ...args) => {
        clone.emit(event, ...args);
      });
      clone.init(mergedOptions, callback);
      clone.translator.options = mergedOptions;
      clone.translator.backendConnector.services.utils = {
        hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
      };
      return clone;
    }
    toJSON() {
      return {
        options: this.options,
        store: this.store,
        language: this.language,
        languages: this.languages,
        resolvedLanguage: this.resolvedLanguage
      };
    }
  }
  const instance = I18n.createInstance();
  const createInstance = instance.createInstance;
  const dir = instance.dir;
  const init = instance.init;
  const loadResources = instance.loadResources;
  const reloadResources = instance.reloadResources;
  const use = instance.use;
  const changeLanguage = instance.changeLanguage;
  const getFixedT = instance.getFixedT;
  const t = instance.t;
  const exists = instance.exists;
  const setDefaultNamespace = instance.setDefaultNamespace;
  const hasLoadedNamespace = instance.hasLoadedNamespace;
  const loadNamespaces = instance.loadNamespaces;
  const loadLanguages = instance.loadLanguages;
},2372,[],"node_modules/i18next/dist/esm/i18next.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _voidElements = require(_dependencyMap[0], "void-elements");
  var e = _interopDefault(_voidElements);
  var t = /\s([^'"/\s><]+?)[\s/>]|([^\s=]+)=\s?(".*?"|'.*?')/g;
  function n(n) {
    var r = {
        type: "tag",
        name: "",
        voidElement: !1,
        attrs: {},
        children: []
      },
      i = n.match(/<\/?([^\s]+?)[/\s>]/);
    if (i && (r.name = i[1], (e.default[i[1]] || "/" === n.charAt(n.length - 2)) && (r.voidElement = !0), r.name.startsWith("!--"))) {
      var s = n.indexOf("--\x3e");
      return {
        type: "comment",
        comment: -1 !== s ? n.slice(4, s) : ""
      };
    }
    for (var a = new RegExp(t), c = null; null !== (c = a.exec(n));) if (c[0].trim()) if (c[1]) {
      var o = c[1].trim(),
        l = [o, ""];
      o.indexOf("=") > -1 && (l = o.split("=")), r.attrs[l[0]] = l[1], a.lastIndex--;
    } else c[2] && (r.attrs[c[2]] = c[3].trim().substring(1, c[3].length - 1));
    return r;
  }
  var r = /<[a-zA-Z0-9\-\!\/](?:"[^"]*"|'[^']*'|[^'">])*>/g,
    i = /^\s*$/,
    s = Object.create(null);
  function a(e, t) {
    switch (t.type) {
      case "text":
        return e + t.content;
      case "tag":
        return e += "<" + t.name + (t.attrs ? function (e) {
          var t = [];
          for (var n in e) t.push(n + '="' + e[n] + '"');
          return t.length ? " " + t.join(" ") : "";
        }(t.attrs) : "") + (t.voidElement ? "/>" : ">"), t.voidElement ? e : e + t.children.reduce(a, "") + "</" + t.name + ">";
      case "comment":
        return e + "\x3c!--" + t.comment + "--\x3e";
    }
  }
  var c = {
    parse: function (e, t) {
      t || (t = {}), t.components || (t.components = s);
      var a,
        c = [],
        o = [],
        l = -1,
        m = !1;
      if (0 !== e.indexOf("<")) {
        var u = e.indexOf("<");
        c.push({
          type: "text",
          content: -1 === u ? e : e.substring(0, u)
        });
      }
      return e.replace(r, function (r, s) {
        if (m) {
          if (r !== "</" + a.name + ">") return;
          m = !1;
        }
        var u,
          f = "/" !== r.charAt(1),
          h = r.startsWith("\x3c!--"),
          p = s + r.length,
          d = e.charAt(p);
        if (h) {
          var v = n(r);
          return l < 0 ? (c.push(v), c) : ((u = o[l]).children.push(v), c);
        }
        if (f && (l++, "tag" === (a = n(r)).type && t.components[a.name] && (a.type = "component", m = !0), a.voidElement || m || !d || "<" === d || a.children.push({
          type: "text",
          content: e.slice(p, e.indexOf("<", p))
        }), 0 === l && c.push(a), (u = o[l - 1]) && u.children.push(a), o[l] = a), (!f || a.voidElement) && (l > -1 && (a.voidElement || a.name === r.slice(2, -1)) && (l--, a = -1 === l ? c : o[l]), !m && "<" !== d && d)) {
          u = -1 === l ? c : o[l].children;
          var x = e.indexOf("<", p),
            g = e.slice(p, -1 === x ? void 0 : x);
          i.test(g) && (g = " "), (x > -1 && l + u.length >= 0 || " " !== g) && u.push({
            type: "text",
            content: g
          });
        }
      }), c;
    },
    stringify: function (e) {
      return e.reduce(function (e, t) {
        return e + a("", t);
      }, "");
    }
  };
  var _default = c;
},2373,[2374],"node_modules/html-parse-stringify/dist/html-parse-stringify.module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * This file automatically generated from `pre-publish.js`.
   * Do not manually edit.
   */

  module.exports = {
    "area": true,
    "base": true,
    "br": true,
    "col": true,
    "embed": true,
    "hr": true,
    "img": true,
    "input": true,
    "link": true,
    "meta": true,
    "param": true,
    "source": true,
    "track": true,
    "wbr": true
  };
},2374,[],"node_modules/void-elements/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "warn", {
    enumerable: true,
    get: function () {
      return warn;
    }
  });
  Object.defineProperty(exports, "warnOnce", {
    enumerable: true,
    get: function () {
      return warnOnce;
    }
  });
  Object.defineProperty(exports, "loadNamespaces", {
    enumerable: true,
    get: function () {
      return loadNamespaces;
    }
  });
  Object.defineProperty(exports, "loadLanguages", {
    enumerable: true,
    get: function () {
      return loadLanguages;
    }
  });
  Object.defineProperty(exports, "hasLoadedNamespace", {
    enumerable: true,
    get: function () {
      return hasLoadedNamespace;
    }
  });
  Object.defineProperty(exports, "getDisplayName", {
    enumerable: true,
    get: function () {
      return getDisplayName;
    }
  });
  Object.defineProperty(exports, "isString", {
    enumerable: true,
    get: function () {
      return isString;
    }
  });
  Object.defineProperty(exports, "isObject", {
    enumerable: true,
    get: function () {
      return isObject;
    }
  });
  const warn = (i18n, code, msg, rest) => {
    const args = [msg, {
      code,
      ...(rest || {})
    }];
    if (i18n?.services?.logger?.forward) {
      return i18n.services.logger.forward(args, 'warn', 'react-i18next::', true);
    }
    if (isString(args[0])) args[0] = `react-i18next:: ${args[0]}`;
    if (i18n?.services?.logger?.warn) {
      i18n.services.logger.warn(...args);
    } else if (console?.warn) {
      console.warn(...args);
    }
  };
  const alreadyWarned = {};
  const warnOnce = (i18n, code, msg, rest) => {
    if (isString(msg) && alreadyWarned[msg]) return;
    if (isString(msg)) alreadyWarned[msg] = new Date();
    warn(i18n, code, msg, rest);
  };
  const loadedClb = (i18n, cb) => () => {
    if (i18n.isInitialized) {
      cb();
    } else {
      const initialized = () => {
        setTimeout(() => {
          i18n.off('initialized', initialized);
        }, 0);
        cb();
      };
      i18n.on('initialized', initialized);
    }
  };
  const loadNamespaces = (i18n, ns, cb) => {
    i18n.loadNamespaces(ns, loadedClb(i18n, cb));
  };
  const loadLanguages = (i18n, lng, ns, cb) => {
    if (isString(ns)) ns = [ns];
    if (i18n.options.preload && i18n.options.preload.indexOf(lng) > -1) return loadNamespaces(i18n, ns, cb);
    ns.forEach(n => {
      if (i18n.options.ns.indexOf(n) < 0) i18n.options.ns.push(n);
    });
    i18n.loadLanguages(lng, loadedClb(i18n, cb));
  };
  const hasLoadedNamespace = (ns, i18n, options = {}) => {
    if (!i18n.languages || !i18n.languages.length) {
      warnOnce(i18n, 'NO_LANGUAGES', 'i18n.languages were undefined or empty', {
        languages: i18n.languages
      });
      return true;
    }
    return i18n.hasLoadedNamespace(ns, {
      lng: options.lng,
      precheck: (i18nInstance, loadNotPending) => {
        if (options.bindI18n && options.bindI18n.indexOf('languageChanging') > -1 && i18nInstance.services.backendConnector.backend && i18nInstance.isLanguageChangingTo && !loadNotPending(i18nInstance.isLanguageChangingTo, ns)) return false;
      }
    });
  };
  const getDisplayName = Component => Component.displayName || Component.name || (isString(Component) && Component.length > 0 ? Component : 'Unknown');
  const isString = obj => typeof obj === 'string';
  const isObject = obj => typeof obj === 'object' && obj !== null;
},2375,[],"node_modules/react-i18next/dist/es/utils.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "setDefaults", {
    enumerable: true,
    get: function () {
      return setDefaults;
    }
  });
  Object.defineProperty(exports, "getDefaults", {
    enumerable: true,
    get: function () {
      return getDefaults;
    }
  });
  var _unescapeJs = require(_dependencyMap[0], "./unescape.js");
  let defaultOptions = {
    bindI18n: 'languageChanged',
    bindI18nStore: '',
    transEmptyNodeValue: '',
    transSupportBasicHtmlNodes: true,
    transWrapTextNodes: '',
    transKeepBasicHtmlNodesFor: ['br', 'strong', 'i', 'p'],
    useSuspense: true,
    unescape: _unescapeJs.unescape
  };
  const setDefaults = (options = {}) => {
    defaultOptions = {
      ...defaultOptions,
      ...options
    };
  };
  const getDefaults = () => defaultOptions;
},2376,[2377],"node_modules/react-i18next/dist/es/defaults.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "unescape", {
    enumerable: true,
    get: function () {
      return unescape;
    }
  });
  const matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
  const htmlEntities = {
    '&amp;': '&',
    '&#38;': '&',
    '&lt;': '<',
    '&#60;': '<',
    '&gt;': '>',
    '&#62;': '>',
    '&apos;': "'",
    '&#39;': "'",
    '&quot;': '"',
    '&#34;': '"',
    '&nbsp;': ' ',
    '&#160;': ' ',
    '&copy;': '©',
    '&#169;': '©',
    '&reg;': '®',
    '&#174;': '®',
    '&hellip;': '…',
    '&#8230;': '…',
    '&#x2F;': '/',
    '&#47;': '/'
  };
  const unescapeHtmlEntity = m => htmlEntities[m];
  const unescape = text => text.replace(matchHtmlEntity, unescapeHtmlEntity);
},2377,[],"node_modules/react-i18next/dist/es/unescape.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "setI18n", {
    enumerable: true,
    get: function () {
      return setI18n;
    }
  });
  Object.defineProperty(exports, "getI18n", {
    enumerable: true,
    get: function () {
      return getI18n;
    }
  });
  let i18nInstance;
  const setI18n = instance => {
    i18nInstance = instance;
  };
  const getI18n = () => i18nInstance;
},2378,[],"node_modules/react-i18next/dist/es/i18nInstance.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "getDefaults", {
    enumerable: true,
    get: function () {
      return _defaultsJs.getDefaults;
    }
  });
  Object.defineProperty(exports, "setDefaults", {
    enumerable: true,
    get: function () {
      return _defaultsJs.setDefaults;
    }
  });
  Object.defineProperty(exports, "getI18n", {
    enumerable: true,
    get: function () {
      return _i18nInstanceJs.getI18n;
    }
  });
  Object.defineProperty(exports, "setI18n", {
    enumerable: true,
    get: function () {
      return _i18nInstanceJs.setI18n;
    }
  });
  Object.defineProperty(exports, "initReactI18next", {
    enumerable: true,
    get: function () {
      return _initReactI18nextJs.initReactI18next;
    }
  });
  Object.defineProperty(exports, "I18nContext", {
    enumerable: true,
    get: function () {
      return I18nContext;
    }
  });
  Object.defineProperty(exports, "ReportNamespaces", {
    enumerable: true,
    get: function () {
      return ReportNamespaces;
    }
  });
  Object.defineProperty(exports, "composeInitialProps", {
    enumerable: true,
    get: function () {
      return composeInitialProps;
    }
  });
  Object.defineProperty(exports, "getInitialProps", {
    enumerable: true,
    get: function () {
      return getInitialProps;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _defaultsJs = require(_dependencyMap[1], "./defaults.js");
  var _i18nInstanceJs = require(_dependencyMap[2], "./i18nInstance.js");
  var _initReactI18nextJs = require(_dependencyMap[3], "./initReactI18next.js");
  const I18nContext = /*#__PURE__*/(0, _react.createContext)();
  class ReportNamespaces {
    constructor() {
      this.usedNamespaces = {};
    }
    addUsedNamespaces(namespaces) {
      namespaces.forEach(ns => {
        if (!this.usedNamespaces[ns]) this.usedNamespaces[ns] = true;
      });
    }
    getUsedNamespaces() {
      return Object.keys(this.usedNamespaces);
    }
  }
  const composeInitialProps = ForComponent => async ctx => {
    const componentsInitialProps = (await ForComponent.getInitialProps?.(ctx)) ?? {};
    const i18nInitialProps = getInitialProps();
    return {
      ...componentsInitialProps,
      ...i18nInitialProps
    };
  };
  const getInitialProps = () => {
    const i18n = (0, _i18nInstanceJs.getI18n)();
    const namespaces = i18n.reportNamespaces?.getUsedNamespaces() ?? [];
    const ret = {};
    const initialI18nStore = {};
    i18n.languages.forEach(l => {
      initialI18nStore[l] = {};
      namespaces.forEach(ns => {
        initialI18nStore[l][ns] = i18n.getResourceBundle(l, ns) || {};
      });
    });
    ret.initialI18nStore = initialI18nStore;
    ret.initialLanguage = i18n.language;
    return ret;
  };
},2379,[9,2376,2378,2380],"node_modules/react-i18next/dist/es/context.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "initReactI18next", {
    enumerable: true,
    get: function () {
      return initReactI18next;
    }
  });
  var _defaultsJs = require(_dependencyMap[0], "./defaults.js");
  var _i18nInstanceJs = require(_dependencyMap[1], "./i18nInstance.js");
  const initReactI18next = {
    type: '3rdParty',
    init(instance) {
      (0, _defaultsJs.setDefaults)(instance.options.react);
      (0, _i18nInstanceJs.setI18n)(instance);
    }
  };
},2380,[2376,2378],"node_modules/react-i18next/dist/es/initReactI18next.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.IcuTrans = IcuTrans;
  var _react = require(_dependencyMap[0], "react");
  var _IcuTransWithoutContextJs = require(_dependencyMap[1], "./IcuTransWithoutContext.js");
  var _contextJs = require(_dependencyMap[2], "./context.js");
  function IcuTrans({
    i18nKey,
    defaultTranslation,
    content,
    ns,
    values = {},
    i18n: i18nFromProps,
    t: tFromProps
  }) {
    const {
      i18n: i18nFromContext,
      defaultNS: defaultNSFromContext
    } = (0, _react.useContext)(_contextJs.I18nContext) || {};
    const i18n = i18nFromProps || i18nFromContext || (0, _contextJs.getI18n)();
    const t = tFromProps || i18n?.t.bind(i18n);
    return (0, _IcuTransWithoutContextJs.IcuTransWithoutContext)({
      i18nKey,
      defaultTranslation,
      content,
      ns: ns || t?.ns || defaultNSFromContext || i18n?.options?.defaultNS,
      values,
      i18n,
      t: tFromProps
    });
  }
  IcuTrans.displayName = 'IcuTrans';
},2381,[9,2382,2379],"node_modules/react-i18next/dist/es/IcuTrans.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.IcuTransWithoutContext = IcuTransWithoutContext;
  var _react = require(_dependencyMap[0], "react");
  var React = _interopDefault(_react);
  var _utilsJs = require(_dependencyMap[1], "./utils.js");
  var _i18nInstanceJs = require(_dependencyMap[2], "./i18nInstance.js");
  var _IcuTransUtilsIndexJs = require(_dependencyMap[3], "./IcuTransUtils/index.js");
  function IcuTransWithoutContext({
    i18nKey,
    defaultTranslation,
    content,
    ns,
    values = {},
    i18n: i18nFromProps,
    t: tFromProps
  }) {
    const i18n = i18nFromProps || (0, _i18nInstanceJs.getI18n)();
    if (!i18n) {
      (0, _utilsJs.warnOnce)(i18n, 'NO_I18NEXT_INSTANCE', `IcuTrans: You need to pass in an i18next instance using i18nextReactModule`, {
        i18nKey
      });
      return /*#__PURE__*/React.default.createElement(React.default.Fragment, {}, defaultTranslation);
    }
    const t = tFromProps || i18n.t?.bind(i18n) || (k => k);
    let namespaces = ns || t.ns || i18n.options?.defaultNS;
    namespaces = (0, _utilsJs.isString)(namespaces) ? [namespaces] : namespaces || ['translation'];
    let mergedValues = values;
    if (i18n.options?.interpolation?.defaultVariables) {
      mergedValues = values && Object.keys(values).length > 0 ? {
        ...values,
        ...i18n.options.interpolation.defaultVariables
      } : {
        ...i18n.options.interpolation.defaultVariables
      };
    }
    const translation = t(i18nKey, {
      defaultValue: defaultTranslation,
      ...mergedValues,
      ns: namespaces
    });
    try {
      const rendered = (0, _IcuTransUtilsIndexJs.renderTranslation)(translation, content);
      return /*#__PURE__*/React.default.createElement(React.default.Fragment, {}, ...rendered);
    } catch (error) {
      (0, _utilsJs.warn)(i18n, 'ICU_TRANS_RENDER_ERROR', `IcuTrans component error for key "${i18nKey}": ${error.message}`, {
        i18nKey,
        error
      });
      return /*#__PURE__*/React.default.createElement(React.default.Fragment, {}, translation);
    }
  }
  IcuTransWithoutContext.displayName = 'IcuTransWithoutContext';
},2382,[9,2375,2378,2383],"node_modules/react-i18next/dist/es/IcuTransWithoutContext.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  var _TranslationParserErrorJs = require(_dependencyMap[0], "./TranslationParserError.js");
  Object.keys(_TranslationParserErrorJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _TranslationParserErrorJs[k];
        }
      });
    }
  });
  var _htmlEntityDecoderJs = require(_dependencyMap[1], "./htmlEntityDecoder.js");
  Object.keys(_htmlEntityDecoderJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _htmlEntityDecoderJs[k];
        }
      });
    }
  });
  var _tokenizerJs = require(_dependencyMap[2], "./tokenizer.js");
  Object.keys(_tokenizerJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _tokenizerJs[k];
        }
      });
    }
  });
  var _renderTranslationJs = require(_dependencyMap[3], "./renderTranslation.js");
  Object.keys(_renderTranslationJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _renderTranslationJs[k];
        }
      });
    }
  });
},2383,[2384,2385,2386,2387],"node_modules/react-i18next/dist/es/IcuTransUtils/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "TranslationParserError", {
    enumerable: true,
    get: function () {
      return TranslationParserError;
    }
  });
  class TranslationParserError extends Error {
    constructor(message, position, translationString) {
      super(message);
      this.name = 'TranslationParserError';
      this.position = position;
      this.translationString = translationString;
      if (Error.captureStackTrace) {
        Error.captureStackTrace(this, TranslationParserError);
      }
    }
  }
},2384,[],"node_modules/react-i18next/dist/es/IcuTransUtils/TranslationParserError.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "decodeHtmlEntities", {
    enumerable: true,
    get: function () {
      return decodeHtmlEntities;
    }
  });
  const commonEntities = {
    '&nbsp;': '\u00A0',
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&apos;': "'",
    '&copy;': '©',
    '&reg;': '®',
    '&trade;': '™',
    '&hellip;': '…',
    '&ndash;': '–',
    '&mdash;': '—',
    '&lsquo;': '\u2018',
    '&rsquo;': '\u2019',
    '&sbquo;': '\u201A',
    '&ldquo;': '\u201C',
    '&rdquo;': '\u201D',
    '&bdquo;': '\u201E',
    '&dagger;': '†',
    '&Dagger;': '‡',
    '&bull;': '•',
    '&prime;': '′',
    '&Prime;': '″',
    '&lsaquo;': '‹',
    '&rsaquo;': '›',
    '&sect;': '§',
    '&para;': '¶',
    '&middot;': '·',
    '&ensp;': '\u2002',
    '&emsp;': '\u2003',
    '&thinsp;': '\u2009',
    '&euro;': '€',
    '&pound;': '£',
    '&yen;': '¥',
    '&cent;': '¢',
    '&curren;': '¤',
    '&times;': '×',
    '&divide;': '÷',
    '&minus;': '−',
    '&plusmn;': '±',
    '&ne;': '≠',
    '&le;': '≤',
    '&ge;': '≥',
    '&asymp;': '≈',
    '&equiv;': '≡',
    '&infin;': '∞',
    '&int;': '∫',
    '&sum;': '∑',
    '&prod;': '∏',
    '&radic;': '√',
    '&part;': '∂',
    '&permil;': '‰',
    '&deg;': '°',
    '&micro;': 'µ',
    '&larr;': '←',
    '&uarr;': '↑',
    '&rarr;': '→',
    '&darr;': '↓',
    '&harr;': '↔',
    '&crarr;': '↵',
    '&lArr;': '⇐',
    '&uArr;': '⇑',
    '&rArr;': '⇒',
    '&dArr;': '⇓',
    '&hArr;': '⇔',
    '&alpha;': 'α',
    '&beta;': 'β',
    '&gamma;': 'γ',
    '&delta;': 'δ',
    '&epsilon;': 'ε',
    '&zeta;': 'ζ',
    '&eta;': 'η',
    '&theta;': 'θ',
    '&iota;': 'ι',
    '&kappa;': 'κ',
    '&lambda;': 'λ',
    '&mu;': 'μ',
    '&nu;': 'ν',
    '&xi;': 'ξ',
    '&omicron;': 'ο',
    '&pi;': 'π',
    '&rho;': 'ρ',
    '&sigma;': 'σ',
    '&tau;': 'τ',
    '&upsilon;': 'υ',
    '&phi;': 'φ',
    '&chi;': 'χ',
    '&psi;': 'ψ',
    '&omega;': 'ω',
    '&Alpha;': 'Α',
    '&Beta;': 'Β',
    '&Gamma;': 'Γ',
    '&Delta;': 'Δ',
    '&Epsilon;': 'Ε',
    '&Zeta;': 'Ζ',
    '&Eta;': 'Η',
    '&Theta;': 'Θ',
    '&Iota;': 'Ι',
    '&Kappa;': 'Κ',
    '&Lambda;': 'Λ',
    '&Mu;': 'Μ',
    '&Nu;': 'Ν',
    '&Xi;': 'Ξ',
    '&Omicron;': 'Ο',
    '&Pi;': 'Π',
    '&Rho;': 'Ρ',
    '&Sigma;': 'Σ',
    '&Tau;': 'Τ',
    '&Upsilon;': 'Υ',
    '&Phi;': 'Φ',
    '&Chi;': 'Χ',
    '&Psi;': 'Ψ',
    '&Omega;': 'Ω',
    '&Agrave;': 'À',
    '&Aacute;': 'Á',
    '&Acirc;': 'Â',
    '&Atilde;': 'Ã',
    '&Auml;': 'Ä',
    '&Aring;': 'Å',
    '&AElig;': 'Æ',
    '&Ccedil;': 'Ç',
    '&Egrave;': 'È',
    '&Eacute;': 'É',
    '&Ecirc;': 'Ê',
    '&Euml;': 'Ë',
    '&Igrave;': 'Ì',
    '&Iacute;': 'Í',
    '&Icirc;': 'Î',
    '&Iuml;': 'Ï',
    '&ETH;': 'Ð',
    '&Ntilde;': 'Ñ',
    '&Ograve;': 'Ò',
    '&Oacute;': 'Ó',
    '&Ocirc;': 'Ô',
    '&Otilde;': 'Õ',
    '&Ouml;': 'Ö',
    '&Oslash;': 'Ø',
    '&Ugrave;': 'Ù',
    '&Uacute;': 'Ú',
    '&Ucirc;': 'Û',
    '&Uuml;': 'Ü',
    '&Yacute;': 'Ý',
    '&THORN;': 'Þ',
    '&szlig;': 'ß',
    '&agrave;': 'à',
    '&aacute;': 'á',
    '&acirc;': 'â',
    '&atilde;': 'ã',
    '&auml;': 'ä',
    '&aring;': 'å',
    '&aelig;': 'æ',
    '&ccedil;': 'ç',
    '&egrave;': 'è',
    '&eacute;': 'é',
    '&ecirc;': 'ê',
    '&euml;': 'ë',
    '&igrave;': 'ì',
    '&iacute;': 'í',
    '&icirc;': 'î',
    '&iuml;': 'ï',
    '&eth;': 'ð',
    '&ntilde;': 'ñ',
    '&ograve;': 'ò',
    '&oacute;': 'ó',
    '&ocirc;': 'ô',
    '&otilde;': 'õ',
    '&ouml;': 'ö',
    '&oslash;': 'ø',
    '&ugrave;': 'ù',
    '&uacute;': 'ú',
    '&ucirc;': 'û',
    '&uuml;': 'ü',
    '&yacute;': 'ý',
    '&thorn;': 'þ',
    '&yuml;': 'ÿ',
    '&iexcl;': '¡',
    '&iquest;': '¿',
    '&fnof;': 'ƒ',
    '&circ;': 'ˆ',
    '&tilde;': '˜',
    '&OElig;': 'Œ',
    '&oelig;': 'œ',
    '&Scaron;': 'Š',
    '&scaron;': 'š',
    '&Yuml;': 'Ÿ',
    '&ordf;': 'ª',
    '&ordm;': 'º',
    '&macr;': '¯',
    '&acute;': '´',
    '&cedil;': '¸',
    '&sup1;': '¹',
    '&sup2;': '²',
    '&sup3;': '³',
    '&frac14;': '¼',
    '&frac12;': '½',
    '&frac34;': '¾',
    '&spades;': '♠',
    '&clubs;': '♣',
    '&hearts;': '♥',
    '&diams;': '♦',
    '&loz;': '◊',
    '&oline;': '‾',
    '&frasl;': '⁄',
    '&weierp;': '℘',
    '&image;': 'ℑ',
    '&real;': 'ℜ',
    '&alefsym;': 'ℵ'
  };
  const entityPattern = new RegExp(Object.keys(commonEntities).map(entity => entity.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'g');
  const decodeHtmlEntities = text => text.replace(entityPattern, match => commonEntities[match]).replace(/&#(\d+);/g, (_, num) => String.fromCharCode(parseInt(num, 10))).replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
},2385,[],"node_modules/react-i18next/dist/es/IcuTransUtils/htmlEntityDecoder.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "tokenize", {
    enumerable: true,
    get: function () {
      return tokenize;
    }
  });
  const tokenize = translation => {
    const tokens = [];
    let position = 0;
    let currentText = '';
    const flushText = () => {
      if (currentText) {
        tokens.push({
          type: 'Text',
          value: currentText,
          position: position - currentText.length
        });
        currentText = '';
      }
    };
    while (position < translation.length) {
      const char = translation[position];
      if (char === '<') {
        const tagMatch = translation.slice(position).match(/^<(\d+)>/);
        if (tagMatch) {
          flushText();
          tokens.push({
            type: 'TagOpen',
            value: tagMatch[0],
            position,
            tagNumber: parseInt(tagMatch[1], 10)
          });
          position += tagMatch[0].length;
        } else {
          const closeTagMatch = translation.slice(position).match(/^<\/(\d+)>/);
          if (closeTagMatch) {
            flushText();
            tokens.push({
              type: 'TagClose',
              value: closeTagMatch[0],
              position,
              tagNumber: parseInt(closeTagMatch[1], 10)
            });
            position += closeTagMatch[0].length;
          } else {
            currentText += char;
            position += 1;
          }
        }
      } else {
        currentText += char;
        position += 1;
      }
    }
    flushText();
    return tokens;
  };
},2386,[],"node_modules/react-i18next/dist/es/IcuTransUtils/tokenizer.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "renderTranslation", {
    enumerable: true,
    get: function () {
      return renderTranslation;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopDefault(_react);
  var _TranslationParserErrorJs = require(_dependencyMap[1], "./TranslationParserError.js");
  var _tokenizerJs = require(_dependencyMap[2], "./tokenizer.js");
  var _htmlEntityDecoderJs = require(_dependencyMap[3], "./htmlEntityDecoder.js");
  const renderDeclarationNode = (declaration, children, childDeclarations) => {
    const {
      type,
      props = {}
    } = declaration;
    if (props.children && Array.isArray(props.children) && childDeclarations) {
      const {
        children: _childrenToRemove,
        ...propsWithoutChildren
      } = props;
      return /*#__PURE__*/React.default.createElement(type, propsWithoutChildren, ...children);
    }
    if (children.length === 0) {
      return /*#__PURE__*/React.default.createElement(type, props);
    }
    if (children.length === 1) {
      return /*#__PURE__*/React.default.createElement(type, props, children[0]);
    }
    return /*#__PURE__*/React.default.createElement(type, props, ...children);
  };
  const renderTranslation = (translation, declarations = []) => {
    if (!translation) {
      return [];
    }
    const tokens = (0, _tokenizerJs.tokenize)(translation);
    const result = [];
    const stack = [];
    const literalTagNumbers = new Set();
    const getCurrentDeclarations = () => {
      if (stack.length === 0) {
        return declarations;
      }
      const parentFrame = stack[stack.length - 1];
      if (parentFrame.declaration.props?.children && Array.isArray(parentFrame.declaration.props.children)) {
        return parentFrame.declaration.props.children;
      }
      return parentFrame.declarations;
    };
    tokens.forEach(token => {
      switch (token.type) {
        case 'Text':
          {
            const decoded = (0, _htmlEntityDecoderJs.decodeHtmlEntities)(token.value);
            const targetArray = stack.length > 0 ? stack[stack.length - 1].children : result;
            targetArray.push(decoded);
          }
          break;
        case 'TagOpen':
          {
            const {
              tagNumber
            } = token;
            const currentDeclarations = getCurrentDeclarations();
            const declaration = currentDeclarations[tagNumber];
            if (!declaration) {
              literalTagNumbers.add(tagNumber);
              const literalText = `<${tagNumber}>`;
              const targetArray = stack.length > 0 ? stack[stack.length - 1].children : result;
              targetArray.push(literalText);
              break;
            }
            stack.push({
              tagNumber,
              children: [],
              position: token.position,
              declaration,
              declarations: currentDeclarations
            });
          }
          break;
        case 'TagClose':
          {
            const {
              tagNumber
            } = token;
            if (literalTagNumbers.has(tagNumber)) {
              const literalText = `</${tagNumber}>`;
              const literalTargetArray = stack.length > 0 ? stack[stack.length - 1].children : result;
              literalTargetArray.push(literalText);
              literalTagNumbers.delete(tagNumber);
              break;
            }
            if (stack.length === 0) {
              throw new _TranslationParserErrorJs.TranslationParserError(`Unexpected closing tag </${tagNumber}> at position ${token.position}`, token.position, translation);
            }
            const frame = stack.pop();
            if (frame.tagNumber !== tagNumber) {
              throw new _TranslationParserErrorJs.TranslationParserError(`Mismatched tags: expected </${frame.tagNumber}> but got </${tagNumber}> at position ${token.position}`, token.position, translation);
            }
            const element = renderDeclarationNode(frame.declaration, frame.children, frame.declarations);
            const elementTargetArray = stack.length > 0 ? stack[stack.length - 1].children : result;
            elementTargetArray.push(element);
          }
          break;
      }
    });
    if (stack.length > 0) {
      const unclosed = stack[stack.length - 1];
      throw new _TranslationParserErrorJs.TranslationParserError(`Unclosed tag <${unclosed.tagNumber}> at position ${unclosed.position}`, unclosed.position, translation);
    }
    return result;
  };
},2387,[9,2384,2386,2385],"node_modules/react-i18next/dist/es/IcuTransUtils/renderTranslation.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useTranslation", {
    enumerable: true,
    get: function () {
      return useTranslation;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _useSyncExternalStoreShim = require(_dependencyMap[1], "use-sync-external-store/shim");
  var _contextJs = require(_dependencyMap[2], "./context.js");
  var _utilsJs = require(_dependencyMap[3], "./utils.js");
  const notReadyT = (k, optsOrDefaultValue) => {
    if ((0, _utilsJs.isString)(optsOrDefaultValue)) return optsOrDefaultValue;
    if ((0, _utilsJs.isObject)(optsOrDefaultValue) && (0, _utilsJs.isString)(optsOrDefaultValue.defaultValue)) return optsOrDefaultValue.defaultValue;
    return Array.isArray(k) ? k[k.length - 1] : k;
  };
  const notReadySnapshot = {
    t: notReadyT,
    ready: false
  };
  const dummySubscribe = () => () => {};
  const useTranslation = (ns, props = {}) => {
    const {
      i18n: i18nFromProps
    } = props;
    const {
      i18n: i18nFromContext,
      defaultNS: defaultNSFromContext
    } = (0, _react.useContext)(_contextJs.I18nContext) || {};
    const i18n = i18nFromProps || i18nFromContext || (0, _contextJs.getI18n)();
    if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new _contextJs.ReportNamespaces();
    if (!i18n) {
      (0, _utilsJs.warnOnce)(i18n, 'NO_I18NEXT_INSTANCE', 'useTranslation: You will need to pass in an i18next instance by using initReactI18next');
    }
    const i18nOptions = (0, _react.useMemo)(() => ({
      ...(0, _contextJs.getDefaults)(),
      ...i18n?.options?.react,
      ...props
    }), [i18n, props]);
    const {
      useSuspense,
      keyPrefix
    } = i18nOptions;
    const nsOrContext = ns || defaultNSFromContext || i18n?.options?.defaultNS;
    const unstableNamespaces = (0, _utilsJs.isString)(nsOrContext) ? [nsOrContext] : nsOrContext || ['translation'];
    const namespaces = (0, _react.useMemo)(() => unstableNamespaces, unstableNamespaces);
    i18n?.reportNamespaces?.addUsedNamespaces?.(namespaces);
    const revisionRef = (0, _react.useRef)(0);
    const subscribe = (0, _react.useCallback)(callback => {
      if (!i18n) return dummySubscribe;
      const {
        bindI18n,
        bindI18nStore
      } = i18nOptions;
      const wrappedCallback = () => {
        revisionRef.current += 1;
        callback();
      };
      if (bindI18n) i18n.on(bindI18n, wrappedCallback);
      if (bindI18nStore) i18n.store.on(bindI18nStore, wrappedCallback);
      return () => {
        if (bindI18n) bindI18n.split(' ').forEach(e => i18n.off(e, wrappedCallback));
        if (bindI18nStore) bindI18nStore.split(' ').forEach(e => i18n.store.off(e, wrappedCallback));
      };
    }, [i18n, i18nOptions]);
    const snapshotRef = (0, _react.useRef)();
    const getSnapshot = (0, _react.useCallback)(() => {
      if (!i18n) {
        return notReadySnapshot;
      }
      const calculatedReady = !!(i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every(n => (0, _utilsJs.hasLoadedNamespace)(n, i18n, i18nOptions));
      const currentLng = props.lng || i18n.language;
      const currentRevision = revisionRef.current;
      const lastSnapshot = snapshotRef.current;
      if (lastSnapshot && lastSnapshot.ready === calculatedReady && lastSnapshot.lng === currentLng && lastSnapshot.keyPrefix === keyPrefix && lastSnapshot.revision === currentRevision) {
        return lastSnapshot;
      }
      const calculatedT = i18n.getFixedT(currentLng, i18nOptions.nsMode === 'fallback' ? namespaces : namespaces[0], keyPrefix);
      const newSnapshot = {
        t: calculatedT,
        ready: calculatedReady,
        lng: currentLng,
        keyPrefix,
        revision: currentRevision
      };
      snapshotRef.current = newSnapshot;
      return newSnapshot;
    }, [i18n, namespaces, keyPrefix, i18nOptions, props.lng]);
    const [loadCount, setLoadCount] = (0, _react.useState)(0);
    const {
      t,
      ready
    } = (0, _useSyncExternalStoreShim.useSyncExternalStore)(subscribe, getSnapshot, getSnapshot);
    (0, _react.useEffect)(() => {
      if (i18n && !ready && !useSuspense) {
        const onLoaded = () => setLoadCount(c => c + 1);
        if (props.lng) {
          (0, _utilsJs.loadLanguages)(i18n, props.lng, namespaces, onLoaded);
        } else {
          (0, _utilsJs.loadNamespaces)(i18n, namespaces, onLoaded);
        }
      }
    }, [i18n, props.lng, namespaces, ready, useSuspense, loadCount]);
    const finalI18n = i18n || {};
    const wrapperRef = (0, _react.useRef)(null);
    const wrapperLangRef = (0, _react.useRef)();
    const createI18nWrapper = original => {
      const descriptors = Object.getOwnPropertyDescriptors(original);
      if (descriptors.__original) delete descriptors.__original;
      const wrapper = Object.create(Object.getPrototypeOf(original), descriptors);
      if (!Object.prototype.hasOwnProperty.call(wrapper, '__original')) {
        try {
          Object.defineProperty(wrapper, '__original', {
            value: original,
            writable: false,
            enumerable: false,
            configurable: false
          });
        } catch (_) {}
      }
      return wrapper;
    };
    const ret = (0, _react.useMemo)(() => {
      const original = finalI18n;
      const lang = original?.language;
      let i18nWrapper = original;
      if (original) {
        if (wrapperRef.current && wrapperRef.current.__original === original) {
          if (wrapperLangRef.current !== lang) {
            i18nWrapper = createI18nWrapper(original);
            wrapperRef.current = i18nWrapper;
            wrapperLangRef.current = lang;
          } else {
            i18nWrapper = wrapperRef.current;
          }
        } else {
          i18nWrapper = createI18nWrapper(original);
          wrapperRef.current = i18nWrapper;
          wrapperLangRef.current = lang;
        }
      }
      const arr = [t, i18nWrapper, ready];
      arr.t = t;
      arr.i18n = i18nWrapper;
      arr.ready = ready;
      return arr;
    }, [t, finalI18n, ready, finalI18n.resolvedLanguage, finalI18n.language, finalI18n.languages]);
    if (i18n && useSuspense && !ready) {
      throw new Promise(resolve => {
        const onLoaded = () => resolve();
        if (props.lng) {
          (0, _utilsJs.loadLanguages)(i18n, props.lng, namespaces, onLoaded);
        } else {
          (0, _utilsJs.loadNamespaces)(i18n, namespaces, onLoaded);
        }
      });
    }
    return ret;
  };
},2388,[9,2389,2379,2375],"node_modules/react-i18next/dist/es/useTranslation.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "../cjs/use-sync-external-store-shim.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "../cjs/use-sync-external-store-shim.development.js");
  }
},2389,[2390,2391],"node_modules/use-sync-external-store/shim/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * use-sync-external-store-shim.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  var React = require(_dependencyMap[0], "react");
  function is(x, y) {
    return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
  }
  var objectIs = "function" === typeof Object.is ? Object.is : is,
    useState = React.useState,
    useEffect = React.useEffect,
    useLayoutEffect = React.useLayoutEffect,
    useDebugValue = React.useDebugValue;
  function useSyncExternalStore$2(subscribe, getSnapshot) {
    var value = getSnapshot(),
      _useState = useState({
        inst: {
          value: value,
          getSnapshot: getSnapshot
        }
      }),
      inst = _useState[0].inst,
      forceUpdate = _useState[1];
    useLayoutEffect(function () {
      inst.value = value;
      inst.getSnapshot = getSnapshot;
      checkIfSnapshotChanged(inst) && forceUpdate({
        inst: inst
      });
    }, [subscribe, value, getSnapshot]);
    useEffect(function () {
      checkIfSnapshotChanged(inst) && forceUpdate({
        inst: inst
      });
      return subscribe(function () {
        checkIfSnapshotChanged(inst) && forceUpdate({
          inst: inst
        });
      });
    }, [subscribe]);
    useDebugValue(value);
    return value;
  }
  function checkIfSnapshotChanged(inst) {
    var latestGetSnapshot = inst.getSnapshot;
    inst = inst.value;
    try {
      var nextValue = latestGetSnapshot();
      return !objectIs(inst, nextValue);
    } catch (error) {
      return !0;
    }
  }
  function useSyncExternalStore$1(subscribe, getSnapshot) {
    return getSnapshot();
  }
  var shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
  exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
},2390,[9],"node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * use-sync-external-store-shim.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function is(x, y) {
      return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
    }
    function useSyncExternalStore$2(subscribe, getSnapshot) {
      didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
      var value = getSnapshot();
      if (!didWarnUncachedGetSnapshot) {
        var cachedValue = getSnapshot();
        objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
      }
      cachedValue = useState({
        inst: {
          value: value,
          getSnapshot: getSnapshot
        }
      });
      var inst = cachedValue[0].inst,
        forceUpdate = cachedValue[1];
      useLayoutEffect(function () {
        inst.value = value;
        inst.getSnapshot = getSnapshot;
        checkIfSnapshotChanged(inst) && forceUpdate({
          inst: inst
        });
      }, [subscribe, value, getSnapshot]);
      useEffect(function () {
        checkIfSnapshotChanged(inst) && forceUpdate({
          inst: inst
        });
        return subscribe(function () {
          checkIfSnapshotChanged(inst) && forceUpdate({
            inst: inst
          });
        });
      }, [subscribe]);
      useDebugValue(value);
      return value;
    }
    function checkIfSnapshotChanged(inst) {
      var latestGetSnapshot = inst.getSnapshot;
      inst = inst.value;
      try {
        var nextValue = latestGetSnapshot();
        return !objectIs(inst, nextValue);
      } catch (error) {
        return !0;
      }
    }
    function useSyncExternalStore$1(subscribe, getSnapshot) {
      return getSnapshot();
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var React = require(_dependencyMap[0], "react"),
      objectIs = "function" === typeof Object.is ? Object.is : is,
      useState = React.useState,
      useEffect = React.useEffect,
      useLayoutEffect = React.useLayoutEffect,
      useDebugValue = React.useDebugValue,
      didWarnOld18Alpha = !1,
      didWarnUncachedGetSnapshot = !1,
      shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
    exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  }();
},2391,[9],"node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "withTranslation", {
    enumerable: true,
    get: function () {
      return withTranslation;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _useTranslationJs = require(_dependencyMap[1], "./useTranslation.js");
  var _utilsJs = require(_dependencyMap[2], "./utils.js");
  const withTranslation = (ns, options = {}) => function Extend(WrappedComponent) {
    function I18nextWithTranslation({
      forwardedRef,
      ...rest
    }) {
      const [t, i18n, ready] = (0, _useTranslationJs.useTranslation)(ns, {
        ...rest,
        keyPrefix: options.keyPrefix
      });
      const passDownProps = {
        ...rest,
        t,
        i18n,
        tReady: ready
      };
      if (options.withRef && forwardedRef) {
        passDownProps.ref = forwardedRef;
      } else if (!options.withRef && forwardedRef) {
        passDownProps.forwardedRef = forwardedRef;
      }
      return /*#__PURE__*/(0, _react.createElement)(WrappedComponent, passDownProps);
    }
    I18nextWithTranslation.displayName = `withI18nextTranslation(${(0, _utilsJs.getDisplayName)(WrappedComponent)})`;
    I18nextWithTranslation.WrappedComponent = WrappedComponent;
    const forwardRef = (props, ref) => /*#__PURE__*/(0, _react.createElement)(I18nextWithTranslation, Object.assign({}, props, {
      forwardedRef: ref
    }));
    return options.withRef ? /*#__PURE__*/(0, _react.forwardRef)(forwardRef) : I18nextWithTranslation;
  };
},2392,[9,2388,2375],"node_modules/react-i18next/dist/es/withTranslation.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Translation", {
    enumerable: true,
    get: function () {
      return Translation;
    }
  });
  var _useTranslationJs = require(_dependencyMap[0], "./useTranslation.js");
  const Translation = ({
    ns,
    children,
    ...options
  }) => {
    const [t, i18n, ready] = (0, _useTranslationJs.useTranslation)(ns, options);
    return children(t, {
      i18n,
      lng: i18n.language
    }, ready);
  };
},2393,[2388],"node_modules/react-i18next/dist/es/Translation.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.I18nextProvider = I18nextProvider;
  var _react = require(_dependencyMap[0], "react");
  var _contextJs = require(_dependencyMap[1], "./context.js");
  function I18nextProvider({
    i18n,
    defaultNS,
    children
  }) {
    const value = (0, _react.useMemo)(() => ({
      i18n,
      defaultNS
    }), [i18n, defaultNS]);
    return /*#__PURE__*/(0, _react.createElement)(_contextJs.I18nContext.Provider, {
      value
    }, children);
  }
},2394,[9,2379],"node_modules/react-i18next/dist/es/I18nextProvider.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "withSSR", {
    enumerable: true,
    get: function () {
      return withSSR;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _useSSRJs = require(_dependencyMap[1], "./useSSR.js");
  var _contextJs = require(_dependencyMap[2], "./context.js");
  var _utilsJs = require(_dependencyMap[3], "./utils.js");
  const withSSR = () => function Extend(WrappedComponent) {
    function I18nextWithSSR({
      initialI18nStore,
      initialLanguage,
      ...rest
    }) {
      (0, _useSSRJs.useSSR)(initialI18nStore, initialLanguage);
      return /*#__PURE__*/(0, _react.createElement)(WrappedComponent, {
        ...rest
      });
    }
    I18nextWithSSR.getInitialProps = (0, _contextJs.composeInitialProps)(WrappedComponent);
    I18nextWithSSR.displayName = `withI18nextSSR(${(0, _utilsJs.getDisplayName)(WrappedComponent)})`;
    I18nextWithSSR.WrappedComponent = WrappedComponent;
    return I18nextWithSSR;
  };
},2395,[9,2396,2379,2375],"node_modules/react-i18next/dist/es/withSSR.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useSSR", {
    enumerable: true,
    get: function () {
      return useSSR;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _contextJs = require(_dependencyMap[1], "./context.js");
  const useSSR = (initialI18nStore, initialLanguage, props = {}) => {
    const {
      i18n: i18nFromProps
    } = props;
    const {
      i18n: i18nFromContext
    } = (0, _react.useContext)(_contextJs.I18nContext) || {};
    const i18n = i18nFromProps || i18nFromContext || (0, _contextJs.getI18n)();
    if (i18n.options?.isClone) return;
    if (initialI18nStore && !i18n.initializedStoreOnce) {
      i18n.services.resourceStore.data = initialI18nStore;
      i18n.options.ns = Object.values(initialI18nStore).reduce((mem, lngResources) => {
        Object.keys(lngResources).forEach(ns => {
          if (mem.indexOf(ns) < 0) mem.push(ns);
        });
        return mem;
      }, i18n.options.ns);
      i18n.initializedStoreOnce = true;
      i18n.isInitialized = true;
    }
    if (initialLanguage && !i18n.initializedLanguageOnce) {
      i18n.changeLanguage(initialLanguage);
      i18n.initializedLanguageOnce = true;
    }
  };
},2396,[9,2379],"node_modules/react-i18next/dist/es/useSSR.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // WARN: Internal re-export, don't rely on this to be a public API
  module.exports = require(_dependencyMap[0], "../src/async-require/asyncRequireModule");
},2408,[2409],"node_modules/expo/internal/async-require-module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright © 2025 650 Industries.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * This is added as `asyncRequireModulePath` in `@expo/metro-config`
   * Fork of https://github.com/facebook/metro/blob/b8e9e64f1de97a67234e223f5ee21524b160e8a5/packages/metro-runtime/src/modules/asyncRequire.js#L1
   * - Adds worker support.
   */

  function maybeLoadBundle(moduleID, paths) {
    const loadBundle = global[`${__METRO_GLOBAL_PREFIX__}__loadBundleAsync`];
    if (loadBundle != null) {
      const stringModuleID = String(moduleID);
      if (paths != null) {
        const bundlePath = paths[stringModuleID];
        if (bundlePath != null) {
          // NOTE: Errors will be swallowed by asyncRequire.prefetch
          return loadBundle(bundlePath);
        }
      }
    }
    return undefined;
  }
  function asyncRequireImpl(moduleID, paths) {
    const maybeLoadBundlePromise = maybeLoadBundle(moduleID, paths);
    const importAll = () => require.importAll(moduleID);
    if (maybeLoadBundlePromise != null) {
      return maybeLoadBundlePromise.then(importAll);
    }
    return importAll();
  }
  async function asyncRequire(moduleID, paths, moduleName) {
    return asyncRequireImpl(moduleID, paths);
  }

  // Synchronous version of asyncRequire, which can still return a promise
  // if the module is split.
  asyncRequire.unstable_importMaybeSync = function unstable_importMaybeSync(moduleID, paths) {
    return asyncRequireImpl(moduleID, paths);
  };
  asyncRequire.prefetch = function (moduleID, paths, moduleName) {
    maybeLoadBundle(moduleID, paths)?.then(() => {}, () => {});
  };
  asyncRequire.unstable_resolve = function unstable_resolve(moduleID, paths) {
    if (!paths) {
      throw new Error('Bundle splitting is required for Web Worker imports');
    }
    const id = paths[moduleID];
    if (!id) {
      throw new Error('Worker import is missing from split bundle paths: ' + id);
    }
    return id;
  };

  // TODO(@kitten): Missing metro type definitions

  module.exports = asyncRequire;
},2409,[],"node_modules/expo/src/async-require/asyncRequireModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  Object.defineProperty(exports, "availableLanguages", {
    enumerable: true,
    get: function () {
      return availableLanguages;
    }
  });
  Object.defineProperty(exports, "getLanguageByCode", {
    enumerable: true,
    get: function () {
      return getLanguageByCode;
    }
  });
  Object.defineProperty(exports, "getLanguagesByRegion", {
    enumerable: true,
    get: function () {
      return getLanguagesByRegion;
    }
  });
  Object.defineProperty(exports, "detectDeviceLanguage", {
    enumerable: true,
    get: function () {
      return detectDeviceLanguage;
    }
  });
  var _i18next = require(_dependencyMap[0], "i18next");
  var _reactI18next = require(_dependencyMap[1], "react-i18next");
  var _localesRu = require(_dependencyMap[2], "./locales/ru");
  var ru = _interopDefault(_localesRu);
  var _localesEn = require(_dependencyMap[3], "./locales/en");
  var en = _interopDefault(_localesEn);
  var _localesEs = require(_dependencyMap[4], "./locales/es");
  var es = _interopDefault(_localesEs);
  var _localesFr = require(_dependencyMap[5], "./locales/fr");
  var fr = _interopDefault(_localesFr);
  var _localesDe = require(_dependencyMap[6], "./locales/de");
  var de = _interopDefault(_localesDe);
  var _localesZh = require(_dependencyMap[7], "./locales/zh");
  var zh = _interopDefault(_localesZh);
  var _localesIt = require(_dependencyMap[8], "./locales/it");
  var it = _interopDefault(_localesIt);
  var _localesPt = require(_dependencyMap[9], "./locales/pt");
  var pt = _interopDefault(_localesPt);
  var _localesJa = require(_dependencyMap[10], "./locales/ja");
  var ja = _interopDefault(_localesJa);
  var _localesKo = require(_dependencyMap[11], "./locales/ko");
  var ko = _interopDefault(_localesKo);
  // Импорт языков Фазы 2 (будут добавлены позже)
  // import it from './locales/it';
  // import ja from './locales/ja';
  // import ko from './locales/ko';
  // import pt from './locales/pt';

  // Импорт языков Фазы 3-4 (будут добавлены позже)
  // import ar from './locales/ar';
  // import hi from './locales/hi';
  // import tr from './locales/tr';
  // import pl from './locales/pl';

  const resources = {
    ru: {
      translation: ru.default
    },
    en: {
      translation: en.default
    },
    es: {
      translation: es.default
    },
    fr: {
      translation: fr.default
    },
    de: {
      translation: de.default
    },
    zh: {
      translation: zh.default
    },
    it: {
      translation: it.default
    },
    pt: {
      translation: pt.default
    },
    ja: {
      translation: ja.default
    },
    ko: {
      translation: ko.default
    }
    // it: { translation: it },
    // ja: { translation: ja },
    // ko: { translation: ko },
    // pt: { translation: pt },
    // ar: { translation: ar },
    // hi: { translation: hi },
    // tr: { translation: tr },
    // pl: { translation: pl },
  };
  const i18n = (0, _i18next.createInstance)();
  i18n.use(_reactI18next.initReactI18next).init({
    resources,
    lng: 'ru',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    },
    // Поддержка множественного числа
    pluralSeparator: '_',
    contextSeparator: '_'
  });
  var _default = i18n;

  /**
   * Список доступных языков для глобального распространения
   * Приоритет: Северная Америка/Европа -> Азия -> Латинская Америка -> Остальные
   */
  const availableLanguages = [
  // Текущие языки (активные) - Фаза 1 + Фаза 2 ЗАВЕРШЕНЫ!
  {
    code: 'ru',
    name: 'Русский',
    nameNative: 'Русский',
    flag: '🇷🇺',
    region: 'CIS'
  }, {
    code: 'en',
    name: 'English',
    nameNative: 'English',
    flag: '🇬🇧',
    region: 'Global'
  }, {
    code: 'es',
    name: 'Spanish',
    nameNative: 'Español',
    flag: '🇪🇸',
    region: 'Europe/Latin America'
  }, {
    code: 'fr',
    name: 'French',
    nameNative: 'Français',
    flag: '🇫🇷',
    region: 'Europe'
  }, {
    code: 'de',
    name: 'German',
    nameNative: 'Deutsch',
    flag: '🇩🇪',
    region: 'Europe'
  }, {
    code: 'zh',
    name: 'Chinese (Simplified)',
    nameNative: '简体中文',
    flag: '🇨🇳',
    region: 'Asia'
  }, {
    code: 'it',
    name: 'Italian',
    nameNative: 'Italiano',
    flag: '🇮🇹',
    region: 'Europe'
  }, {
    code: 'pt',
    name: 'Portuguese',
    nameNative: 'Português',
    flag: '🇧🇷',
    region: 'Latin America'
  }, {
    code: 'ja',
    name: 'Japanese',
    nameNative: '日本語',
    flag: '🇯🇵',
    region: 'Asia'
  }, {
    code: 'ko',
    name: 'Korean',
    nameNative: '한국어',
    flag: '🇰🇷',
    region: 'Asia'
  },
  // Фаза 3: Остальные языки (в процессе)
  {
    code: 'zh-TW',
    name: 'Chinese (Traditional)',
    nameNative: '繁體中文',
    flag: '🇹🇼',
    region: 'Asia',
    comingSoon: true
  },
  // Фаза 3: Латинская Америка и Восточная Европа (12-18 месяцев)
  {
    code: 'pt',
    name: 'Portuguese',
    nameNative: 'Português',
    flag: '🇧🇷',
    region: 'Latin America',
    comingSoon: true
  }, {
    code: 'pl',
    name: 'Polish',
    nameNative: 'Polski',
    flag: '🇵🇱',
    region: 'Europe',
    comingSoon: true
  }, {
    code: 'tr',
    name: 'Turkish',
    nameNative: 'Türkçe',
    flag: '🇹🇷',
    region: 'Europe/Asia',
    comingSoon: true
  },
  // Фаза 4: Глобальное покрытие (18+ месяцев)
  {
    code: 'ar',
    name: 'Arabic',
    nameNative: 'العربية',
    flag: '🇸🇦',
    region: 'Middle East',
    comingSoon: true
  }, {
    code: 'hi',
    name: 'Hindi',
    nameNative: 'हिन्दी',
    flag: '🇮🇳',
    region: 'Asia',
    comingSoon: true
  }];

  /**
   * Получить язык по коду
   */
  const getLanguageByCode = code => {
    return availableLanguages.find(lang => lang.code === code) || availableLanguages[1]; // Fallback to English
  };

  /**
   * Получить язык по региону
   */
  const getLanguagesByRegion = region => {
    return availableLanguages.filter(lang => lang.region === region || lang.region === 'Global');
  };

  /**
   * Автоматическое определение языка устройства
   * Работает для web и React Native
   */
  const detectDeviceLanguage = async () => {
    try {
      let deviceLang = null;

      // Для React Native используем expo-localization
      if (typeof navigator === 'undefined') {
        try {
          const {
            getLocales
          } = await require(_dependencyMap[13], "expo/internal/async-require-module")(_dependencyMap[12], _dependencyMap.paths, "expo-localization");
          const locales = getLocales();
          if (locales && locales.length > 0) {
            deviceLang = locales[0].languageCode || locales[0].languageTag?.split('-')[0] || null;
          }
        } catch (error) {
          console.warn('[i18n] expo-localization not available, using fallback');
        }
      } else {
        // Для web используем navigator.language
        deviceLang = navigator.language.split('-')[0];
      }
      if (deviceLang) {
        // Ищем точное совпадение
        let supported = availableLanguages.find(lang => lang.code === deviceLang);

        // Если не найдено, ищем по началу кода (например, zh-CN -> zh)
        if (!supported) {
          supported = availableLanguages.find(lang => lang.code.startsWith(deviceLang) || deviceLang.startsWith(lang.code.split('-')[0]));
        }
        if (supported && !supported.comingSoon) {
          return supported.code;
        }
      }
    } catch (error) {
      console.error('[i18n] Error detecting device language:', error);
    }

    // Fallback на английский
    return 'en';
  };
},2580,{"0":2372,"1":2369,"2":2581,"3":2582,"4":2583,"5":2584,"6":2585,"7":2586,"8":2587,"9":2588,"10":2589,"11":2590,"12":2591,"13":2408,"paths":{"2591":"/node_modules/expo-localization/build/Localization.bundle?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false"}},"constants/i18n.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Сохранить',
      cancel: 'Отмена',
      delete: 'Удалить',
      edit: 'Редактировать',
      back: 'Назад',
      loading: 'Загрузка...',
      error: 'Ошибка',
      success: 'Успешно',
      confirm: 'Подтвердить',
      yes: 'Да',
      no: 'Нет',
      errors: {
        networkError: 'Проблема с интернетом. Проверьте соединение.',
        syncFailed: 'Не удалось синхронизировать данные. Попробуйте позже.',
        loadFailed: 'Не удалось загрузить данные. Проверьте соединение.',
        saveFailed: 'Не удалось сохранить данные. Попробуйте еще раз.',
        permissionDenied: 'Недостаточно прав доступа. Проверьте настройки.',
        storageError: 'Ошибка сохранения данных. Попробуйте еще раз.',
        analysisFailed: 'Не удалось проанализировать сообщение. Попробуйте еще раз.',
        sosFailed: 'Не удалось отправить SOS сигнал. Проверьте интернет.',
        authFailed: 'Ошибка аутентификации. Попробуйте войти снова.',
        default: 'Произошла ошибка. Попробуйте еще раз.'
      }
    },
    tabs: {
      home: 'Главная',
      alerts: 'Уведомления',
      statistics: 'Статистика',
      recommendations: 'Рекомендации',
      profile: 'Профиль',
      parentalControls: 'Родительский контроль',
      about: 'О приложении'
    },
    profile: {
      title: 'Редактировать профиль',
      createTitle: 'Создать профиль',
      name: 'Имя',
      email: 'Email',
      role: 'Роль',
      parent: 'Родитель',
      child: 'Ребенок',
      saveChanges: 'Сохранить изменения',
      createProfile: 'Создать профиль',
      logout: 'Выйти из профиля',
      logoutConfirm: 'Вы уверены, что хотите выйти?',
      profileInfo: 'Информация о профиле',
      created: 'Создан',
      device: 'Устройство',
      enterName: 'Введите имя',
      emailPlaceholder: 'example@email.com',
      errors: {
        nameRequired: 'Введите имя',
        saveFailed: 'Не удалось сохранить профиль'
      },
      success: {
        updated: 'Профиль обновлен',
        created: 'Профиль создан'
      },
      language: 'Язык',
      security: {
        title: 'Двухфакторная аутентификация',
        subtitle: 'Добавьте второй шаг подтверждения для чувствительных действий',
        statusEnabled: 'Включена',
        statusDisabled: 'Выключена',
        enabled: 'Двухфакторная аутентификация включена',
        disabled: 'Двухфакторная аутентификация выключена',
        configure: 'Настроить 2FA',
        configureDescription: 'Подключите приложение-аутентификатор или SMS-код, чтобы защитить входы и платежи.'
      },
      payments: {
        title: 'Платёжные предпочтения',
        subtitle: 'Выберите, как опекуны подтверждают покупки и подписки',
        selectedLabel: 'Предпочтительный метод',
        empty: 'Не настроено',
        manage: 'Управлять методами оплаты',
        selectMethod: 'Выберите способ оплаты',
        methodSelected: '{{method}} теперь используется по умолчанию',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Банковская карта'
        },
        descriptions: {
          applePay: 'Мгновенное подтверждение по Face ID или Touch ID.',
          googlePay: 'Безопасное утверждение покупок на Android-устройствах.',
          card: 'Классическая проверка карты с CVV и SMS-кодом.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'Защита переписок с AI',
      search: 'Поиск по участникам...',
      filterAll: 'Все',
      filterSafe: 'Безопасно',
      filterMedium: 'Средний',
      filterHigh: 'Высокий',
      stats: {
        chats: 'Чатов',
        messages: 'Сообщений',
        alerts: 'Тревог'
      },
      lastActivity: 'Последняя активность',
      participants: 'участников',
      message: 'сообщение',
      messages: 'сообщений',
      noResults: 'Ничего не найдено'
    },
    alerts: {
      title: 'Уведомления',
      noAlerts: 'Нет уведомлений',
      high: 'Высокий',
      medium: 'Средний',
      low: 'Низкий',
      resolved: 'Решено',
      active: 'Активно',
      activeAlerts: 'Активные уведомления',
      resolvedAlerts: 'Решенные',
      noActiveAlerts: 'Нет активных уведомлений',
      allChatsAreSafe: 'Все переписки безопасны',
      reasonsTitle: 'Причины тревоги:',
      markAsResolved: 'Отметить решенным',
      unknownChat: 'Неизвестный чат'
    },
    statistics: {
      title: 'Статистика',
      securityTitle: 'Статистика безопасности',
      overview: 'Обзор',
      totalMessages: 'Всего сообщений',
      analyzed: 'Проанализировано',
      activeAlerts: 'Активных тревог',
      resolved: 'Решенных',
      riskDistribution: 'Распределение рисков (сообщения)',
      chatStatus: 'Статус чатов',
      overallProgress: 'Общий прогресс',
      analysisCoverage: 'Охват анализа',
      alertResolution: 'Решение тревог',
      riskyChats: 'Рискованных чатов',
      alertsToday: 'Уведомлений сегодня',
      trends: 'Тренды',
      parent: 'Родитель',
      child: 'Ребенок'
    },
    recommendations: {
      title: 'Рекомендации AI',
      essentialGuidance: {
        title: 'Базовые меры безопасности',
        description: 'Даже при отсутствии тревог держите под контролем приватность аккаунтов и укрепляйте семейные правила общения в сети.',
        highPriority: 'Высокий приоритет',
        footer: 'Даже при отсутствии тревог держите эти практики в ежедневной рутине — это снизит вероятность появления угроз.',
        bullets: ['Просматривайте чаты хотя бы раз в день, чтобы замечать ранние сигналы давления или мошенничества', 'Регулярно напоминайте детям не передавать личные данные и не кликать на незнакомые ссылки', 'Проверьте настройки конфиденциальности аккаунтов детей в мессенджерах и ограничьте доступ к профилю для незнакомцев', 'Установите чёткие семейные правила: с кем можно общаться, какие темы запрещены и что делать при нарушении', 'Обсуждайте сценарии реагирования: к кому обращаться и как блокировать подозрительные контакты']
      },
      generateTitle: 'Получите персональные рекомендации',
      generateDescription: 'AI проанализирует ваши данные и предоставит советы по безопасности',
      generateButton: 'Сгенерировать рекомендации',
      analyzing: 'AI анализирует ваши данные...',
      errorGenerate: 'Не удалось сгенерировать рекомендации',
      tryAgain: 'Попробовать снова',
      refresh: 'Обновить',
      generalRecommendations: 'Общие рекомендации',
      usefulMaterials: 'Полезные материалы',
      chatRecommendations: 'Рекомендации по чатам',
      openLink: 'Открыть',
      priority: {
        high: 'Высокий приоритет',
        medium: 'Средний приоритет',
        low: 'Низкий приоритет'
      }
    },
    parentalControls: {
      title: 'Родительский контроль',
      createProfile: 'Пожалуйста, создайте профиль',
      activeSOS: 'Активные SOS',
      sosSignal: 'SOS сигнал',
      markAsResolved: 'Отметить как решенное',
      settings: {
        title: 'Основные настройки',
        timeRestrictions: 'Временные ограничения',
        imageFiltering: 'Фильтрация изображений',
        blockUnknown: 'Блокировка неизвестных',
        sosNotifications: 'Уведомления SOS',
        dailyLimit: 'Лимит использования (мин/день)',
        save: 'Сохранить'
      },
      timeRestrictions: {
        title: 'Временные ограничения',
        noRestrictions: 'Нет ограничений',
        addRestriction: 'Добавить ограничение',
        selectDay: 'Выберите день недели и время',
        added: 'Ограничение добавлено (пн 22:00-07:00)'
      },
      contacts: {
        title: 'Белый список контактов',
        noContacts: 'Нет контактов',
        addContact: 'Добавить контакт',
        contactName: 'Имя контакта',
        emailOptional: 'Email (опционально)',
        enterName: 'Введите имя контакта',
        contactAdded: 'Контакт добавлен',
        removeContact: 'Удалить контакт?',
        removeConfirm: 'Вы уверены, что хотите удалить',
        errorAdd: 'Не удалось добавить контакт'
      },
      guardianEmails: {
        title: 'Email опекунов',
        addEmail: 'Добавить email',
        emailAdded: 'Email добавлен',
        enterEmail: 'Введите email',
        errorAdd: 'Не удалось добавить email'
      },
      errors: {
        enterName: 'Введите имя',
        enterValue: 'Введите корректное значение',
        enterEmail: 'Введите email',
        updateFailed: 'Не удалось обновить лимит'
      },
      success: {
        limitUpdated: 'Лимит обновлен',
        emailAdded: 'Email добавлен',
        contactAdded: 'Контакт добавлен',
        restrictionAdded: 'Ограничение добавлено'
      },
      days: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']
    },
    chat: {
      notFound: 'Чат не найден',
      inputPlaceholder: 'Введите сообщение...',
      analyzing: '🔍 Анализ сообщения...',
      recording: 'Запись...',
      sosActivated: '🚨 SOS Активирован',
      sosMessage: 'Ваши родители/опекуны были уведомлены. Помощь уже в пути.',
      sosError: 'Не удалось отправить SOS сигнал',
      error: 'Ошибка',
      ok: 'OK',
      reasonsTitle: 'Причины тревоги:',
      emergencyHelp: 'Экстренная помощь из чата'
    },
    riskLevels: {
      safe: 'Безопасно',
      low: 'Низкий',
      medium: 'Средний',
      high: 'Высокий',
      critical: 'Критический'
    },
    settings: {
      title: 'Настройки',
      language: 'Язык приложения',
      selectLanguage: 'Выберите язык'
    },
    about: {
      title: 'О приложении',
      subtitle: 'Защита переписок с AI',
      version: 'Версия 1.0.0',
      currentStatus: 'Текущий статус',
      currentStatusDescription: 'Проект находится на стадии позднего MVP: весь пользовательский функционал и дизайн готовы, проводим стабилизацию и готовим интеграцию с backend и пуш-уведомлениями.',
      stage: 'Стадия',
      aiContent: 'AI & Контент',
      remainingSteps: 'Оставшиеся шаги',
      aboutApp: 'О приложении',
      aboutAppDescription: 'KIDS - это инновационное приложение для мониторинга и защиты безопасности детских чатов с использованием искусственного интеллекта. Мы помогаем родителям защитить своих детей от онлайн-угроз, сохраняя при этом приватность и доверие.',
      publishUrl: 'URL для публикации',
      publishUrlDescription: 'Используйте ссылку ниже при заполнении форм App Store или TestFlight — это стабильный веб-превью проекта в Expo.',
      project: 'Проект',
      clickToOpen: 'Нажмите, чтобы открыть',
      license: 'Лицензия',
      licenseNotFound: 'Файл LICENSE не найден',
      licenseHint1: 'Добавьте LICENSE в корень проекта и заполните поле «license» в package.json, чтобы зафиксировать выбранную лицензию.',
      licenseHint2: 'Проверяйте наличие файла LICENSE и значения «license» в package.json — это основной способ понять, оформлена ли лицензия.',
      mainFeatures: 'Основные функции',
      aiMonitoring: 'AI Мониторинг сообщений',
      aiMonitoringDescription: 'Автоматический анализ текстовых сообщений на предмет угроз, травли, насилия и опасного контента с использованием продвинутых AI моделей',
      imageFiltering: 'Фильтрация изображений',
      imageFilteringDescription: 'AI-анализ изображений для обнаружения неприемлемого контента: насилие, нагота, экстремизм, оружие и наркотики',
      sosButton: 'SOS кнопка',
      sosButtonDescription: 'Экстренная помощь одним нажатием - мгновенное уведомление родителей с геолокацией при опасности',
      timeRestrictions: 'Временные ограничения',
      timeRestrictionsDescription: 'Настраиваемые ограничения по времени использования и расписанию для здорового цифрового баланса',
      contactWhitelist: 'Белый список контактов',
      contactWhitelistDescription: 'Управление разрешенными контактами с возможностью блокировки неизвестных собеседников',
      dataEncryption: 'Шифрование данных',
      dataEncryptionDescription: 'Все данные хранятся локально на устройстве с шифрованием для максимальной приватности',
      coppaCompliance: 'COPPA/GDPR-K соответствие',
      coppaComplianceDescription: 'Полное соответствие международным стандартам защиты данных детей с подробным логированием согласий',
      technologies: 'Технологии',
      techAiModels: 'AI модели для анализа текста и изображений',
      techEncryption: 'End-to-end шифрование сообщений',
      techStorage: 'Локальное хранение данных с AsyncStorage',
      techGeolocation: 'Геолокация для экстренных случаев',
      techVoice: 'Голосовые сообщения с транскрипцией',
      techMonitoring: 'Реал-тайм мониторинг с уведомлениями',
      securityPrivacy: 'Безопасность и приватность',
      securityPrivacyDescription: 'Мы серьезно относимся к безопасности и приватности. Все данные хранятся локально на вашем устройстве. Мы не собираем личную информацию без согласия родителей. AI анализ работает с шифрованными данными, а метаданные о безопасности хранятся отдельно от содержимого сообщений.',
      supportProject: 'Поддержка проекта',
      supportProjectDescription: 'KIDS - это проект с открытым исходным кодом, созданный для защиты детей. Если вам нравится проект, вы можете поддержать его развитие:',
      supportProjectHint: 'Все средства идут на развитие проекта и улучшение безопасности детей',
      support: 'Поддержка',
      supportDescription: 'Если у вас есть вопросы или предложения, свяжитесь с нами:',
      email: 'Email: support@kids-app.com',
      website: 'Сайт: www.kids-app.com',
      footer: '© 2024 KIDS. Все права защищены.',
      footerSubtext: 'Сделано с заботой о безопасности детей',
      releaseReadiness: 'Готовность релиза',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Осталось: подключить push-уведомления, серверную синхронизацию и провести тесты на устройствах.',
      ready: 'Готово'
    }
  };
},2581,[],"constants/locales/ru.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      back: 'Back',
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      confirm: 'Confirm',
      yes: 'Yes',
      no: 'No',
      errors: {
        networkError: 'Network problem. Check your connection.',
        syncFailed: 'Failed to sync data. Please try again later.',
        loadFailed: 'Failed to load data. Check your connection.',
        saveFailed: 'Failed to save data. Please try again.',
        permissionDenied: 'Insufficient access rights. Check your settings.',
        storageError: 'Data storage error. Please try again.',
        analysisFailed: 'Failed to analyze message. Please try again.',
        sosFailed: 'Failed to send SOS signal. Check your internet.',
        authFailed: 'Authentication error. Please try logging in again.',
        default: 'An error occurred. Please try again.'
      }
    },
    tabs: {
      home: 'Home',
      alerts: 'Alerts',
      statistics: 'Statistics',
      recommendations: 'Recommendations',
      profile: 'Profile',
      parentalControls: 'Parental Controls',
      about: 'About'
    },
    profile: {
      title: 'Edit Profile',
      createTitle: 'Create Profile',
      name: 'Name',
      email: 'Email',
      role: 'Role',
      parent: 'Parent',
      child: 'Child',
      saveChanges: 'Save Changes',
      createProfile: 'Create Profile',
      logout: 'Logout',
      logoutConfirm: 'Are you sure you want to logout?',
      profileInfo: 'Profile Information',
      created: 'Created',
      device: 'Device',
      enterName: 'Enter name',
      emailPlaceholder: 'example@email.com',
      errors: {
        nameRequired: 'Enter name',
        saveFailed: 'Failed to save profile'
      },
      success: {
        updated: 'Profile updated',
        created: 'Profile created'
      },
      language: 'Language',
      security: {
        title: 'Two-factor authentication',
        subtitle: 'Add a second approval step before sensitive actions',
        statusEnabled: 'Enabled',
        statusDisabled: 'Disabled',
        enabled: 'Two-factor authentication enabled',
        disabled: 'Two-factor authentication disabled',
        configure: 'Configure 2FA',
        configureDescription: 'Connect an authenticator app or SMS code to secure logins and payouts.'
      },
      payments: {
        title: 'Payment preferences',
        subtitle: 'Choose how guardians approve purchases or subscriptions',
        selectedLabel: 'Preferred method',
        empty: 'Not configured',
        manage: 'Manage payment methods',
        selectMethod: 'Select a payment method',
        methodSelected: '{{method}} is now your default payment method',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Bank card'
        },
        descriptions: {
          applePay: 'Instant biometric confirmation on Apple devices.',
          googlePay: 'Securely approve payments from Android devices.',
          card: 'Classic card verification with CVV and SMS codes.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'AI Chat Protection',
      search: 'Search participants...',
      filterAll: 'All',
      filterSafe: 'Safe',
      filterMedium: 'Medium',
      filterHigh: 'High',
      stats: {
        chats: 'Chats',
        messages: 'Messages',
        alerts: 'Alerts'
      },
      lastActivity: 'Last activity',
      participants: 'participants',
      message: 'message',
      messages: 'messages',
      noResults: 'Nothing found'
    },
    alerts: {
      title: 'Alerts',
      noAlerts: 'No alerts',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
      resolved: 'Resolved',
      active: 'Active',
      activeAlerts: 'Active Alerts',
      resolvedAlerts: 'Resolved',
      noActiveAlerts: 'No active alerts',
      allChatsAreSafe: 'All chats are safe',
      reasonsTitle: 'Alert reasons:',
      markAsResolved: 'Mark as resolved',
      unknownChat: 'Unknown chat'
    },
    statistics: {
      title: 'Statistics',
      securityTitle: 'Security Statistics',
      overview: 'Overview',
      totalMessages: 'Total Messages',
      analyzed: 'Analyzed',
      activeAlerts: 'Active Alerts',
      resolved: 'Resolved',
      riskDistribution: 'Risk Distribution (messages)',
      chatStatus: 'Chat Status',
      overallProgress: 'Overall Progress',
      analysisCoverage: 'Analysis Coverage',
      alertResolution: 'Alert Resolution',
      riskyChats: 'Risky Chats',
      alertsToday: 'Alerts Today',
      trends: 'Trends',
      parent: 'Parent',
      child: 'Child'
    },
    recommendations: {
      title: 'AI Recommendations',
      essentialGuidance: {
        title: 'Basic Security Measures',
        description: 'Even without alerts, keep account privacy under control and strengthen family rules for online communication.',
        highPriority: 'High Priority',
        footer: 'Even without alerts, keep these practices in your daily routine - this will reduce the likelihood of threats.',
        bullets: ['Review chats at least once a day to notice early signs of pressure or fraud', 'Regularly remind children not to share personal information and not to click on unfamiliar links', 'Check privacy settings in children\'s messenger accounts and restrict profile access for strangers', 'Set clear family rules: who you can communicate with, what topics are forbidden and what to do in case of violation', 'Discuss response scenarios: who to contact and how to block suspicious contacts']
      },
      generateTitle: 'Get personalized recommendations',
      generateDescription: 'AI will analyze your data and provide security tips',
      generateButton: 'Generate recommendations',
      analyzing: 'AI is analyzing your data...',
      errorGenerate: 'Failed to generate recommendations',
      tryAgain: 'Try again',
      refresh: 'Refresh',
      generalRecommendations: 'General Recommendations',
      usefulMaterials: 'Useful Materials',
      chatRecommendations: 'Chat Recommendations',
      openLink: 'Open',
      priority: {
        high: 'High Priority',
        medium: 'Medium Priority',
        low: 'Low Priority'
      }
    },
    parentalControls: {
      title: 'Parental Controls',
      createProfile: 'Please create a profile',
      activeSOS: 'Active SOS',
      sosSignal: 'SOS signal',
      markAsResolved: 'Mark as resolved',
      settings: {
        title: 'Main Settings',
        timeRestrictions: 'Time Restrictions',
        imageFiltering: 'Image Filtering',
        blockUnknown: 'Block Unknown',
        sosNotifications: 'SOS Notifications',
        dailyLimit: 'Usage Limit (min/day)',
        save: 'Save'
      },
      timeRestrictions: {
        title: 'Time Restrictions',
        noRestrictions: 'No restrictions',
        addRestriction: 'Add restriction',
        selectDay: 'Select day of week and time',
        added: 'Restriction added (Mon 22:00-07:00)'
      },
      contacts: {
        title: 'Contact Whitelist',
        noContacts: 'No contacts',
        addContact: 'Add contact',
        contactName: 'Contact name',
        emailOptional: 'Email (optional)',
        enterName: 'Enter contact name',
        contactAdded: 'Contact added',
        removeContact: 'Remove contact?',
        removeConfirm: 'Are you sure you want to remove',
        errorAdd: 'Failed to add contact'
      },
      guardianEmails: {
        title: 'Guardian Emails',
        addEmail: 'Add email',
        emailAdded: 'Email added',
        enterEmail: 'Enter email',
        errorAdd: 'Failed to add email'
      },
      errors: {
        enterName: 'Enter name',
        enterValue: 'Enter valid value',
        enterEmail: 'Enter email',
        updateFailed: 'Failed to update limit'
      },
      success: {
        limitUpdated: 'Limit updated',
        emailAdded: 'Email added',
        contactAdded: 'Contact added',
        restrictionAdded: 'Restriction added'
      },
      days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    },
    chat: {
      notFound: 'Chat not found',
      inputPlaceholder: 'Type a message...',
      analyzing: '🔍 Analyzing message...',
      recording: 'Recording...',
      sosActivated: '🚨 SOS Activated',
      sosMessage: 'Your parents/guardians have been notified. Help is on the way.',
      sosError: 'Failed to send SOS signal',
      error: 'Error',
      ok: 'OK',
      reasonsTitle: 'Alert reasons:',
      emergencyHelp: 'Emergency help from chat'
    },
    riskLevels: {
      safe: 'Safe',
      low: 'Low',
      medium: 'Medium',
      high: 'High',
      critical: 'Critical'
    },
    settings: {
      title: 'Settings',
      language: 'App Language',
      selectLanguage: 'Select Language'
    },
    about: {
      title: 'About',
      subtitle: 'AI Chat Protection',
      version: 'Version 1.0.0',
      currentStatus: 'Current Status',
      currentStatusDescription: 'The project is in late MVP stage: all user functionality and design are ready, we are stabilizing and preparing backend integration and push notifications.',
      stage: 'Stage',
      aiContent: 'AI & Content',
      remainingSteps: 'Remaining Steps',
      aboutApp: 'About the App',
      aboutAppDescription: 'KIDS is an innovative app for monitoring and protecting children\'s chats using artificial intelligence. We help parents protect their children from online threats while maintaining privacy and trust.',
      publishUrl: 'Publication URL',
      publishUrlDescription: 'Use the link below when filling out App Store or TestFlight forms — this is a stable web preview of the Expo project.',
      project: 'Project',
      clickToOpen: 'Click to open',
      license: 'License',
      licenseNotFound: 'LICENSE file not found',
      licenseHint1: 'Add LICENSE to the project root and fill the "license" field in package.json to record the chosen license.',
      licenseHint2: 'Check for LICENSE file and "license" value in package.json — this is the main way to understand if a license is registered.',
      mainFeatures: 'Main Features',
      aiMonitoring: 'AI Message Monitoring',
      aiMonitoringDescription: 'Automatic analysis of text messages for threats, bullying, violence and dangerous content using advanced AI models',
      imageFiltering: 'Image Filtering',
      imageFilteringDescription: 'AI analysis of images to detect inappropriate content: violence, nudity, extremism, weapons and drugs',
      sosButton: 'SOS Button',
      sosButtonDescription: 'Emergency help with one tap - instant notification to parents with geolocation in case of danger',
      timeRestrictions: 'Time Restrictions',
      timeRestrictionsDescription: 'Customizable time usage limits and schedules for healthy digital balance',
      contactWhitelist: 'Contact Whitelist',
      contactWhitelistDescription: 'Manage allowed contacts with ability to block unknown interlocutors',
      dataEncryption: 'Data Encryption',
      dataEncryptionDescription: 'All data is stored locally on device with encryption for maximum privacy',
      coppaCompliance: 'COPPA/GDPR-K Compliance',
      coppaComplianceDescription: 'Full compliance with international child data protection standards with detailed consent logging',
      technologies: 'Technologies',
      techAiModels: 'AI models for text and image analysis',
      techEncryption: 'End-to-end message encryption',
      techStorage: 'Local data storage with AsyncStorage',
      techGeolocation: 'Geolocation for emergency cases',
      techVoice: 'Voice messages with transcription',
      techMonitoring: 'Real-time monitoring with notifications',
      securityPrivacy: 'Security and Privacy',
      securityPrivacyDescription: 'We take security and privacy seriously. All data is stored locally on your device. We do not collect personal information without parental consent. AI analysis works with encrypted data, and security metadata is stored separately from message content.',
      supportProject: 'Support the Project',
      supportProjectDescription: 'KIDS is an open source project created to protect children. If you like the project, you can support its development:',
      supportProjectHint: 'All funds go to project development and improving children\'s safety',
      support: 'Support',
      supportDescription: 'If you have questions or suggestions, contact us:',
      email: 'Email: support@kids-app.com',
      website: 'Website: www.kids-app.com',
      footer: '© 2024 KIDS. All rights reserved.',
      footerSubtext: 'Made with care for children\'s safety',
      releaseReadiness: 'Release Readiness',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Remaining: connect push notifications, server synchronization and test on devices.',
      ready: 'Ready'
    }
  };
},2582,[],"constants/locales/en.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Guardar',
      cancel: 'Cancelar',
      delete: 'Eliminar',
      edit: 'Editar',
      back: 'Atrás',
      loading: 'Cargando...',
      error: 'Error',
      success: 'Éxito',
      confirm: 'Confirmar',
      yes: 'Sí',
      no: 'No'
    },
    tabs: {
      home: 'Inicio',
      alerts: 'Alertas',
      statistics: 'Estadísticas',
      recommendations: 'Recomendaciones',
      profile: 'Perfil',
      parentalControls: 'Control Parental',
      about: 'Acerca de'
    },
    profile: {
      title: 'Editar Perfil',
      createTitle: 'Crear Perfil',
      name: 'Nombre',
      email: 'Correo electrónico',
      role: 'Rol',
      parent: 'Padre',
      child: 'Niño',
      saveChanges: 'Guardar cambios',
      createProfile: 'Crear perfil',
      logout: 'Cerrar sesión',
      logoutConfirm: '¿Estás seguro de que quieres cerrar sesión?',
      profileInfo: 'Información del perfil',
      created: 'Creado',
      device: 'Dispositivo',
      enterName: 'Ingrese el nombre',
      emailPlaceholder: 'ejemplo@email.com',
      errors: {
        nameRequired: 'Ingrese el nombre',
        saveFailed: 'No se pudo guardar el perfil'
      },
      success: {
        updated: 'Perfil actualizado',
        created: 'Perfil creado'
      },
      language: 'Idioma',
      security: {
        title: 'Autenticación de dos factores',
        subtitle: 'Agregue un segundo paso de aprobación antes de acciones sensibles',
        statusEnabled: 'Habilitado',
        statusDisabled: 'Deshabilitado',
        enabled: 'Autenticación de dos factores habilitada',
        disabled: 'Autenticación de dos factores deshabilitada',
        configure: 'Configurar 2FA',
        configureDescription: 'Conecte una aplicación de autenticación o código SMS para proteger inicios de sesión y pagos.'
      },
      payments: {
        title: 'Preferencias de pago',
        subtitle: 'Elija cómo los tutores aprueban compras o suscripciones',
        selectedLabel: 'Método preferido',
        empty: 'No configurado',
        manage: 'Administrar métodos de pago',
        selectMethod: 'Seleccione un método de pago',
        methodSelected: '{{method}} es ahora su método de pago predeterminado',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Tarjeta bancaria'
        },
        descriptions: {
          applePay: 'Confirmación biométrica instantánea en dispositivos Apple.',
          googlePay: 'Apruebe pagos de forma segura desde dispositivos Android.',
          card: 'Verificación de tarjeta clásica con CVV y códigos SMS.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'Protección de Chat con IA',
      search: 'Buscar participantes...',
      filterAll: 'Todos',
      filterSafe: 'Seguro',
      filterMedium: 'Medio',
      filterHigh: 'Alto',
      stats: {
        chats: 'Chats',
        messages: 'Mensajes',
        alerts: 'Alertas'
      },
      lastActivity: 'Última actividad',
      participants: 'participantes',
      message: 'mensaje',
      messages: 'mensajes',
      noResults: 'No se encontró nada'
    },
    alerts: {
      title: 'Alertas',
      noAlerts: 'No hay alertas',
      high: 'Alto',
      medium: 'Medio',
      low: 'Bajo',
      resolved: 'Resuelto',
      active: 'Activo',
      activeAlerts: 'Alertas Activas',
      resolvedAlerts: 'Resueltas',
      noActiveAlerts: 'No hay alertas activas',
      allChatsAreSafe: 'Todos los chats son seguros',
      reasonsTitle: 'Razones de alerta:',
      markAsResolved: 'Marcar como resuelto',
      unknownChat: 'Chat desconocido'
    },
    statistics: {
      title: 'Estadísticas',
      securityTitle: 'Estadísticas de Seguridad',
      overview: 'Resumen',
      totalMessages: 'Total de Mensajes',
      analyzed: 'Analizado',
      activeAlerts: 'Alertas Activas',
      resolved: 'Resuelto',
      riskDistribution: 'Distribución de Riesgo (mensajes)',
      chatStatus: 'Estado del Chat',
      overallProgress: 'Progreso General',
      analysisCoverage: 'Cobertura de Análisis',
      alertResolution: 'Resolución de Alertas',
      riskyChats: 'Chats de Riesgo',
      alertsToday: 'Alertas Hoy',
      trends: 'Tendencias',
      parent: 'Padre',
      child: 'Niño'
    },
    recommendations: {
      title: 'Recomendaciones de IA',
      essentialGuidance: {
        title: 'Medidas Básicas de Seguridad',
        description: 'Incluso sin alertas, mantenga la privacidad de la cuenta bajo control y fortalezca las reglas familiares para la comunicación en línea.',
        highPriority: 'Alta Prioridad',
        footer: 'Incluso sin alertas, mantenga estas prácticas en su rutina diaria: esto reducirá la probabilidad de amenazas.',
        bullets: ['Revise los chats al menos una vez al día para notar signos tempranos de presión o fraude', 'Recuerde regularmente a los niños que no compartan información personal y que no hagan clic en enlaces desconocidos', 'Verifique la configuración de privacidad en las cuentas de mensajería de los niños y restrinja el acceso al perfil para extraños', 'Establezca reglas familiares claras: con quién se puede comunicar, qué temas están prohibidos y qué hacer en caso de violación', 'Discuta escenarios de respuesta: a quién contactar y cómo bloquear contactos sospechosos']
      },
      generateTitle: 'Obtener recomendaciones personalizadas',
      generateDescription: 'La IA analizará sus datos y proporcionará consejos de seguridad',
      generateButton: 'Generar recomendaciones',
      analyzing: 'La IA está analizando sus datos...',
      errorGenerate: 'No se pudieron generar recomendaciones',
      tryAgain: 'Intentar de nuevo',
      refresh: 'Actualizar',
      generalRecommendations: 'Recomendaciones Generales',
      usefulMaterials: 'Materiales Útiles',
      chatRecommendations: 'Recomendaciones de Chat',
      openLink: 'Abrir',
      priority: {
        high: 'Alta Prioridad',
        medium: 'Prioridad Media',
        low: 'Baja Prioridad'
      }
    },
    parentalControls: {
      title: 'Control Parental',
      createProfile: 'Por favor, cree un perfil',
      activeSOS: 'SOS Activo',
      sosSignal: 'Señal SOS',
      markAsResolved: 'Marcar como resuelto',
      settings: {
        title: 'Configuración Principal',
        timeRestrictions: 'Restricciones de Tiempo',
        imageFiltering: 'Filtrado de Imágenes',
        blockUnknown: 'Bloquear Desconocidos',
        sosNotifications: 'Notificaciones SOS',
        dailyLimit: 'Límite de Uso (min/día)',
        save: 'Guardar'
      },
      timeRestrictions: {
        title: 'Restricciones de Tiempo',
        noRestrictions: 'Sin restricciones',
        addRestriction: 'Agregar restricción',
        selectDay: 'Seleccione el día de la semana y la hora',
        added: 'Restricción agregada (Lun 22:00-07:00)'
      },
      contacts: {
        title: 'Lista Blanca de Contactos',
        noContacts: 'No hay contactos',
        addContact: 'Agregar contacto',
        contactName: 'Nombre del contacto',
        emailOptional: 'Correo electrónico (opcional)',
        enterName: 'Ingrese el nombre del contacto',
        contactAdded: 'Contacto agregado',
        removeContact: '¿Eliminar contacto?',
        removeConfirm: '¿Está seguro de que desea eliminar',
        errorAdd: 'No se pudo agregar el contacto'
      },
      guardianEmails: {
        title: 'Correos Electrónicos del Tutor',
        addEmail: 'Agregar correo electrónico',
        emailAdded: 'Correo electrónico agregado',
        enterEmail: 'Ingrese el correo electrónico',
        errorAdd: 'No se pudo agregar el correo electrónico'
      },
      errors: {
        enterName: 'Ingrese el nombre',
        enterValue: 'Ingrese un valor válido',
        enterEmail: 'Ingrese el correo electrónico',
        updateFailed: 'No se pudo actualizar el límite'
      },
      success: {
        limitUpdated: 'Límite actualizado',
        emailAdded: 'Correo electrónico agregado',
        contactAdded: 'Contacto agregado',
        restrictionAdded: 'Restricción agregada'
      },
      days: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb']
    },
    chat: {
      notFound: 'Chat no encontrado',
      inputPlaceholder: 'Escribe un mensaje...',
      analyzing: '🔍 Analizando mensaje...',
      recording: 'Grabando...',
      sosActivated: '🚨 SOS Activado',
      sosMessage: 'Sus padres/tutores han sido notificados. La ayuda está en camino.',
      sosError: 'No se pudo enviar la señal SOS',
      error: 'Error',
      ok: 'OK',
      reasonsTitle: 'Razones de alerta:',
      emergencyHelp: 'Ayuda de emergencia desde el chat'
    },
    riskLevels: {
      safe: 'Seguro',
      low: 'Bajo',
      medium: 'Medio',
      high: 'Alto',
      critical: 'Crítico'
    },
    settings: {
      title: 'Configuración',
      language: 'Idioma de la Aplicación',
      selectLanguage: 'Seleccionar Idioma'
    },
    about: {
      title: 'Acerca de',
      subtitle: 'Protección de Chat con IA',
      version: 'Versión 1.0.0',
      currentStatus: 'Estado Actual',
      currentStatusDescription: 'El proyecto está en la etapa final de MVP: toda la funcionalidad y el diseño del usuario están listos, estamos estabilizando y preparando la integración del backend y las notificaciones push.',
      stage: 'Etapa',
      aiContent: 'IA y Contenido',
      remainingSteps: 'Pasos Restantes',
      aboutApp: 'Acerca de la Aplicación',
      aboutAppDescription: 'KIDS es una aplicación innovadora para monitorear y proteger los chats de los niños usando inteligencia artificial. Ayudamos a los padres a proteger a sus hijos de las amenazas en línea mientras mantenemos la privacidad y la confianza.',
      publishUrl: 'URL de Publicación',
      publishUrlDescription: 'Use el enlace a continuación al completar los formularios de App Store o TestFlight: esta es una vista previa web estable del proyecto Expo.',
      project: 'Proyecto',
      clickToOpen: 'Haga clic para abrir',
      license: 'Licencia',
      licenseNotFound: 'Archivo LICENSE no encontrado',
      licenseHint1: 'Agregue LICENSE a la raíz del proyecto y complete el campo "license" en package.json para registrar la licencia elegida.',
      licenseHint2: 'Verifique la presencia del archivo LICENSE y el valor "license" en package.json: esta es la forma principal de entender si una licencia está registrada.',
      mainFeatures: 'Características Principales',
      aiMonitoring: 'Monitoreo de Mensajes con IA',
      aiMonitoringDescription: 'Análisis automático de mensajes de texto para detectar amenazas, acoso, violencia y contenido peligroso usando modelos avanzados de IA',
      imageFiltering: 'Filtrado de Imágenes',
      imageFilteringDescription: 'Análisis de IA de imágenes para detectar contenido inapropiado: violencia, desnudez, extremismo, armas y drogas',
      sosButton: 'Botón SOS',
      sosButtonDescription: 'Ayuda de emergencia con un toque: notificación instantánea a los padres con geolocalización en caso de peligro',
      timeRestrictions: 'Restricciones de Tiempo',
      timeRestrictionsDescription: 'Límites de tiempo de uso personalizables y horarios para un equilibrio digital saludable',
      contactWhitelist: 'Lista Blanca de Contactos',
      contactWhitelistDescription: 'Administre contactos permitidos con la capacidad de bloquear interlocutores desconocidos',
      dataEncryption: 'Cifrado de Datos',
      dataEncryptionDescription: 'Todos los datos se almacenan localmente en el dispositivo con cifrado para máxima privacidad',
      coppaCompliance: 'Cumplimiento COPPA/GDPR-K',
      coppaComplianceDescription: 'Cumplimiento total con los estándares internacionales de protección de datos de niños con registro detallado de consentimientos',
      technologies: 'Tecnologías',
      techAiModels: 'Modelos de IA para análisis de texto e imágenes',
      techEncryption: 'Cifrado de extremo a extremo de mensajes',
      techStorage: 'Almacenamiento local de datos con AsyncStorage',
      techGeolocation: 'Geolocalización para casos de emergencia',
      techVoice: 'Mensajes de voz con transcripción',
      techMonitoring: 'Monitoreo en tiempo real con notificaciones',
      securityPrivacy: 'Seguridad y Privacidad',
      securityPrivacyDescription: 'Nos tomamos en serio la seguridad y la privacidad. Todos los datos se almacenan localmente en su dispositivo. No recopilamos información personal sin el consentimiento de los padres. El análisis de IA funciona con datos cifrados, y los metadatos de seguridad se almacenan por separado del contenido de los mensajes.',
      supportProject: 'Apoyar el Proyecto',
      supportProjectDescription: 'KIDS es un proyecto de código abierto creado para proteger a los niños. Si te gusta el proyecto, puedes apoyar su desarrollo:',
      supportProjectHint: 'Todos los fondos van al desarrollo del proyecto y a mejorar la seguridad de los niños',
      support: 'Soporte',
      supportDescription: 'Si tiene preguntas o sugerencias, contáctenos:',
      email: 'Correo electrónico: support@kids-app.com',
      website: 'Sitio web: www.kids-app.com',
      footer: '© 2024 KIDS. Todos los derechos reservados.',
      footerSubtext: 'Hecho con cuidado por la seguridad de los niños',
      releaseReadiness: 'Preparación para el Lanzamiento',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Restante: conectar notificaciones push, sincronización del servidor y probar en dispositivos.',
      ready: 'Listo'
    }
  };
},2583,[],"constants/locales/es.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Enregistrer',
      cancel: 'Annuler',
      delete: 'Supprimer',
      edit: 'Modifier',
      back: 'Retour',
      loading: 'Chargement...',
      error: 'Erreur',
      success: 'Succès',
      confirm: 'Confirmer',
      yes: 'Oui',
      no: 'Non'
    },
    tabs: {
      home: 'Accueil',
      alerts: 'Alertes',
      statistics: 'Statistiques',
      recommendations: 'Recommandations',
      profile: 'Profil',
      parentalControls: 'Contrôle Parental',
      about: 'À propos'
    },
    profile: {
      title: 'Modifier le Profil',
      createTitle: 'Créer un Profil',
      name: 'Nom',
      email: 'Email',
      role: 'Rôle',
      parent: 'Parent',
      child: 'Enfant',
      saveChanges: 'Enregistrer les modifications',
      createProfile: 'Créer un profil',
      logout: 'Déconnexion',
      logoutConfirm: 'Êtes-vous sûr de vouloir vous déconnecter ?',
      profileInfo: 'Informations du profil',
      created: 'Créé',
      device: 'Appareil',
      enterName: 'Entrez le nom',
      emailPlaceholder: 'exemple@email.com',
      errors: {
        nameRequired: 'Entrez le nom',
        saveFailed: 'Échec de l\'enregistrement du profil'
      },
      success: {
        updated: 'Profil mis à jour',
        created: 'Profil créé'
      },
      language: 'Langue',
      security: {
        title: 'Authentification à deux facteurs',
        subtitle: 'Ajoutez une deuxième étape d\'approbation avant les actions sensibles',
        statusEnabled: 'Activé',
        statusDisabled: 'Désactivé',
        enabled: 'Authentification à deux facteurs activée',
        disabled: 'Authentification à deux facteurs désactivée',
        configure: 'Configurer 2FA',
        configureDescription: 'Connectez une application d\'authentification ou un code SMS pour sécuriser les connexions et les paiements.'
      },
      payments: {
        title: 'Préférences de paiement',
        subtitle: 'Choisissez comment les tuteurs approuvent les achats ou abonnements',
        selectedLabel: 'Méthode préférée',
        empty: 'Non configuré',
        manage: 'Gérer les méthodes de paiement',
        selectMethod: 'Sélectionnez une méthode de paiement',
        methodSelected: '{{method}} est maintenant votre méthode de paiement par défaut',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Carte bancaire'
        },
        descriptions: {
          applePay: 'Confirmation biométrique instantanée sur les appareils Apple.',
          googlePay: 'Approuvez les paiements en toute sécurité depuis les appareils Android.',
          card: 'Vérification de carte classique avec CVV et codes SMS.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'Protection de Chat IA',
      search: 'Rechercher des participants...',
      filterAll: 'Tous',
      filterSafe: 'Sûr',
      filterMedium: 'Moyen',
      filterHigh: 'Élevé',
      stats: {
        chats: 'Chats',
        messages: 'Messages',
        alerts: 'Alertes'
      },
      lastActivity: 'Dernière activité',
      participants: 'participants',
      message: 'message',
      messages: 'messages',
      noResults: 'Rien trouvé'
    },
    alerts: {
      title: 'Alertes',
      noAlerts: 'Aucune alerte',
      high: 'Élevé',
      medium: 'Moyen',
      low: 'Faible',
      resolved: 'Résolu',
      active: 'Actif',
      activeAlerts: 'Alertes Actives',
      resolvedAlerts: 'Résolues',
      noActiveAlerts: 'Aucune alerte active',
      allChatsAreSafe: 'Tous les chats sont sûrs',
      reasonsTitle: 'Raisons de l\'alerte :',
      markAsResolved: 'Marquer comme résolu',
      unknownChat: 'Chat inconnu'
    },
    statistics: {
      title: 'Statistiques',
      securityTitle: 'Statistiques de Sécurité',
      overview: 'Vue d\'ensemble',
      totalMessages: 'Total des Messages',
      analyzed: 'Analysé',
      activeAlerts: 'Alertes Actives',
      resolved: 'Résolu',
      riskDistribution: 'Distribution des Risques (messages)',
      chatStatus: 'Statut du Chat',
      overallProgress: 'Progrès Global',
      analysisCoverage: 'Couverture de l\'Analyse',
      alertResolution: 'Résolution des Alertes',
      riskyChats: 'Chats à Risque',
      alertsToday: 'Alertes Aujourd\'hui',
      trends: 'Tendances',
      parent: 'Parent',
      child: 'Enfant'
    },
    recommendations: {
      title: 'Recommandations IA',
      essentialGuidance: {
        title: 'Mesures de Sécurité de Base',
        description: 'Même sans alertes, gardez la confidentialité du compte sous contrôle et renforcez les règles familiales pour la communication en ligne.',
        highPriority: 'Haute Priorité',
        footer: 'Même sans alertes, gardez ces pratiques dans votre routine quotidienne - cela réduira la probabilité de menaces.',
        bullets: ['Examinez les chats au moins une fois par jour pour remarquer les signes précoces de pression ou de fraude', 'Rappelez régulièrement aux enfants de ne pas partager d\'informations personnelles et de ne pas cliquer sur des liens inconnus', 'Vérifiez les paramètres de confidentialité dans les comptes de messagerie des enfants et restreignez l\'accès au profil pour les étrangers', 'Établissez des règles familiales claires : avec qui communiquer, quels sujets sont interdits et que faire en cas de violation', 'Discutez des scénarios de réponse : qui contacter et comment bloquer les contacts suspects']
      },
      generateTitle: 'Obtenir des recommandations personnalisées',
      generateDescription: 'L\'IA analysera vos données et fournira des conseils de sécurité',
      generateButton: 'Générer des recommandations',
      analyzing: 'L\'IA analyse vos données...',
      errorGenerate: 'Échec de la génération de recommandations',
      tryAgain: 'Réessayer',
      refresh: 'Actualiser',
      generalRecommendations: 'Recommandations Générales',
      usefulMaterials: 'Matériaux Utiles',
      chatRecommendations: 'Recommandations de Chat',
      openLink: 'Ouvrir',
      priority: {
        high: 'Haute Priorité',
        medium: 'Priorité Moyenne',
        low: 'Basse Priorité'
      }
    },
    parentalControls: {
      title: 'Contrôle Parental',
      createProfile: 'Veuillez créer un profil',
      activeSOS: 'SOS Actif',
      sosSignal: 'Signal SOS',
      markAsResolved: 'Marquer comme résolu',
      settings: {
        title: 'Paramètres Principaux',
        timeRestrictions: 'Restrictions Temporelles',
        imageFiltering: 'Filtrage d\'Images',
        blockUnknown: 'Bloquer les Inconnus',
        sosNotifications: 'Notifications SOS',
        dailyLimit: 'Limite d\'Utilisation (min/jour)',
        save: 'Enregistrer'
      },
      timeRestrictions: {
        title: 'Restrictions Temporelles',
        noRestrictions: 'Aucune restriction',
        addRestriction: 'Ajouter une restriction',
        selectDay: 'Sélectionnez le jour de la semaine et l\'heure',
        added: 'Restriction ajoutée (Lun 22:00-07:00)'
      },
      contacts: {
        title: 'Liste Blanche de Contacts',
        noContacts: 'Aucun contact',
        addContact: 'Ajouter un contact',
        contactName: 'Nom du contact',
        emailOptional: 'Email (optionnel)',
        enterName: 'Entrez le nom du contact',
        contactAdded: 'Contact ajouté',
        removeContact: 'Supprimer le contact ?',
        removeConfirm: 'Êtes-vous sûr de vouloir supprimer',
        errorAdd: 'Échec de l\'ajout du contact'
      },
      guardianEmails: {
        title: 'Emails des Tuteurs',
        addEmail: 'Ajouter un email',
        emailAdded: 'Email ajouté',
        enterEmail: 'Entrez l\'email',
        errorAdd: 'Échec de l\'ajout de l\'email'
      },
      errors: {
        enterName: 'Entrez le nom',
        enterValue: 'Entrez une valeur valide',
        enterEmail: 'Entrez l\'email',
        updateFailed: 'Échec de la mise à jour de la limite'
      },
      success: {
        limitUpdated: 'Limite mise à jour',
        emailAdded: 'Email ajouté',
        contactAdded: 'Contact ajouté',
        restrictionAdded: 'Restriction ajoutée'
      },
      days: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
    },
    chat: {
      notFound: 'Chat introuvable',
      inputPlaceholder: 'Tapez un message...',
      analyzing: '🔍 Analyse du message...',
      recording: 'Enregistrement...',
      sosActivated: '🚨 SOS Activé',
      sosMessage: 'Vos parents/tuteurs ont été notifiés. L\'aide est en chemin.',
      sosError: 'Échec de l\'envoi du signal SOS',
      error: 'Erreur',
      ok: 'OK',
      reasonsTitle: 'Raisons de l\'alerte :',
      emergencyHelp: 'Aide d\'urgence depuis le chat'
    },
    riskLevels: {
      safe: 'Sûr',
      low: 'Faible',
      medium: 'Moyen',
      high: 'Élevé',
      critical: 'Critique'
    },
    settings: {
      title: 'Paramètres',
      language: 'Langue de l\'Application',
      selectLanguage: 'Sélectionner la Langue'
    },
    about: {
      title: 'À propos',
      subtitle: 'Protection de Chat IA',
      version: 'Version 1.0.0',
      currentStatus: 'Statut Actuel',
      currentStatusDescription: 'Le projet est en phase MVP avancée : toutes les fonctionnalités utilisateur et le design sont prêts, nous stabilisons et préparons l\'intégration backend et les notifications push.',
      stage: 'Étape',
      aiContent: 'IA et Contenu',
      remainingSteps: 'Étapes Restantes',
      aboutApp: 'À propos de l\'Application',
      aboutAppDescription: 'KIDS est une application innovante pour surveiller et protéger les chats d\'enfants en utilisant l\'intelligence artificielle. Nous aidons les parents à protéger leurs enfants des menaces en ligne tout en maintenant la confidentialité et la confiance.',
      publishUrl: 'URL de Publication',
      publishUrlDescription: 'Utilisez le lien ci-dessous lors du remplissage des formulaires App Store ou TestFlight — il s\'agit d\'un aperçu web stable du projet Expo.',
      project: 'Projet',
      clickToOpen: 'Cliquez pour ouvrir',
      license: 'Licence',
      licenseNotFound: 'Fichier LICENSE introuvable',
      licenseHint1: 'Ajoutez LICENSE à la racine du projet et remplissez le champ "license" dans package.json pour enregistrer la licence choisie.',
      licenseHint2: 'Vérifiez la présence du fichier LICENSE et la valeur "license" dans package.json — c\'est le principal moyen de comprendre si une licence est enregistrée.',
      mainFeatures: 'Caractéristiques Principales',
      aiMonitoring: 'Surveillance des Messages IA',
      aiMonitoringDescription: 'Analyse automatique des messages texte pour détecter les menaces, l\'intimidation, la violence et le contenu dangereux en utilisant des modèles IA avancés',
      imageFiltering: 'Filtrage d\'Images',
      imageFilteringDescription: 'Analyse IA des images pour détecter le contenu inapproprié : violence, nudité, extrémisme, armes et drogues',
      sosButton: 'Bouton SOS',
      sosButtonDescription: 'Aide d\'urgence en un seul tap — notification instantanée aux parents avec géolocalisation en cas de danger',
      timeRestrictions: 'Restrictions Temporelles',
      timeRestrictionsDescription: 'Limites d\'utilisation du temps personnalisables et horaires pour un équilibre numérique sain',
      contactWhitelist: 'Liste Blanche de Contacts',
      contactWhitelistDescription: 'Gérez les contacts autorisés avec la possibilité de bloquer les interlocuteurs inconnus',
      dataEncryption: 'Chiffrement des Données',
      dataEncryptionDescription: 'Toutes les données sont stockées localement sur l\'appareil avec chiffrement pour une confidentialité maximale',
      coppaCompliance: 'Conformité COPPA/GDPR-K',
      coppaComplianceDescription: 'Conformité totale aux normes internationales de protection des données des enfants avec journalisation détaillée des consentements',
      technologies: 'Technologies',
      techAiModels: 'Modèles IA pour l\'analyse de texte et d\'images',
      techEncryption: 'Chiffrement de bout en bout des messages',
      techStorage: 'Stockage local des données avec AsyncStorage',
      techGeolocation: 'Géolocalisation pour les cas d\'urgence',
      techVoice: 'Messages vocaux avec transcription',
      techMonitoring: 'Surveillance en temps réel avec notifications',
      securityPrivacy: 'Sécurité et Confidentialité',
      securityPrivacyDescription: 'Nous prenons la sécurité et la confidentialité au sérieux. Toutes les données sont stockées localement sur votre appareil. Nous ne collectons pas d\'informations personnelles sans le consentement des parents. L\'analyse IA fonctionne avec des données chiffrées, et les métadonnées de sécurité sont stockées séparément du contenu des messages.',
      supportProject: 'Soutenir le Projet',
      supportProjectDescription: 'KIDS est un projet open source créé pour protéger les enfants. Si vous aimez le projet, vous pouvez soutenir son développement :',
      supportProjectHint: 'Tous les fonds vont au développement du projet et à l\'amélioration de la sécurité des enfants',
      support: 'Support',
      supportDescription: 'Si vous avez des questions ou des suggestions, contactez-nous :',
      email: 'Email : support@kids-app.com',
      website: 'Site web : www.kids-app.com',
      footer: '© 2024 KIDS. Tous droits réservés.',
      footerSubtext: 'Fait avec soin pour la sécurité des enfants',
      releaseReadiness: 'Préparation au Lancement',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Restant : connecter les notifications push, la synchronisation serveur et tester sur les appareils.',
      ready: 'Prêt'
    }
  };
},2584,[],"constants/locales/fr.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Speichern',
      cancel: 'Abbrechen',
      delete: 'Löschen',
      edit: 'Bearbeiten',
      back: 'Zurück',
      loading: 'Lädt...',
      error: 'Fehler',
      success: 'Erfolg',
      confirm: 'Bestätigen',
      yes: 'Ja',
      no: 'Nein'
    },
    tabs: {
      home: 'Startseite',
      alerts: 'Warnungen',
      statistics: 'Statistiken',
      recommendations: 'Empfehlungen',
      profile: 'Profil',
      parentalControls: 'Kindersicherung',
      about: 'Über'
    },
    profile: {
      title: 'Profil Bearbeiten',
      createTitle: 'Profil Erstellen',
      name: 'Name',
      email: 'E-Mail',
      role: 'Rolle',
      parent: 'Elternteil',
      child: 'Kind',
      saveChanges: 'Änderungen speichern',
      createProfile: 'Profil erstellen',
      logout: 'Abmelden',
      logoutConfirm: 'Sind Sie sicher, dass Sie sich abmelden möchten?',
      profileInfo: 'Profilinformationen',
      created: 'Erstellt',
      device: 'Gerät',
      enterName: 'Namen eingeben',
      emailPlaceholder: 'beispiel@email.com',
      errors: {
        nameRequired: 'Namen eingeben',
        saveFailed: 'Profil konnte nicht gespeichert werden'
      },
      success: {
        updated: 'Profil aktualisiert',
        created: 'Profil erstellt'
      },
      language: 'Sprache',
      security: {
        title: 'Zwei-Faktor-Authentifizierung',
        subtitle: 'Fügen Sie einen zweiten Bestätigungsschritt vor sensiblen Aktionen hinzu',
        statusEnabled: 'Aktiviert',
        statusDisabled: 'Deaktiviert',
        enabled: 'Zwei-Faktor-Authentifizierung aktiviert',
        disabled: 'Zwei-Faktor-Authentifizierung deaktiviert',
        configure: '2FA konfigurieren',
        configureDescription: 'Verbinden Sie eine Authenticator-App oder SMS-Code, um Anmeldungen und Auszahlungen zu sichern.'
      },
      payments: {
        title: 'Zahlungseinstellungen',
        subtitle: 'Wählen Sie, wie Erziehungsberechtigte Käufe oder Abonnements genehmigen',
        selectedLabel: 'Bevorzugte Methode',
        empty: 'Nicht konfiguriert',
        manage: 'Zahlungsmethoden verwalten',
        selectMethod: 'Wählen Sie eine Zahlungsmethode',
        methodSelected: '{{method}} ist jetzt Ihre Standard-Zahlungsmethode',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Bankkarte'
        },
        descriptions: {
          applePay: 'Sofortige biometrische Bestätigung auf Apple-Geräten.',
          googlePay: 'Genehmigen Sie Zahlungen sicher von Android-Geräten.',
          card: 'Klassische Kartenprüfung mit CVV und SMS-Codes.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'KI-Chat-Schutz',
      search: 'Teilnehmer suchen...',
      filterAll: 'Alle',
      filterSafe: 'Sicher',
      filterMedium: 'Mittel',
      filterHigh: 'Hoch',
      stats: {
        chats: 'Chats',
        messages: 'Nachrichten',
        alerts: 'Warnungen'
      },
      lastActivity: 'Letzte Aktivität',
      participants: 'Teilnehmer',
      message: 'Nachricht',
      messages: 'Nachrichten',
      noResults: 'Nichts gefunden'
    },
    alerts: {
      title: 'Warnungen',
      noAlerts: 'Keine Warnungen',
      high: 'Hoch',
      medium: 'Mittel',
      low: 'Niedrig',
      resolved: 'Gelöst',
      active: 'Aktiv',
      activeAlerts: 'Aktive Warnungen',
      resolvedAlerts: 'Gelöst',
      noActiveAlerts: 'Keine aktiven Warnungen',
      allChatsAreSafe: 'Alle Chats sind sicher',
      reasonsTitle: 'Warnungsgründe:',
      markAsResolved: 'Als gelöst markieren',
      unknownChat: 'Unbekannter Chat'
    },
    statistics: {
      title: 'Statistiken',
      securityTitle: 'Sicherheitsstatistiken',
      overview: 'Übersicht',
      totalMessages: 'Gesamtnachrichten',
      analyzed: 'Analysiert',
      activeAlerts: 'Aktive Warnungen',
      resolved: 'Gelöst',
      riskDistribution: 'Risikoverteilung (Nachrichten)',
      chatStatus: 'Chat-Status',
      overallProgress: 'Gesamtfortschritt',
      analysisCoverage: 'Analyseabdeckung',
      alertResolution: 'Warnungsauflösung',
      riskyChats: 'Risikochats',
      alertsToday: 'Warnungen Heute',
      trends: 'Trends',
      parent: 'Elternteil',
      child: 'Kind'
    },
    recommendations: {
      title: 'KI-Empfehlungen',
      essentialGuidance: {
        title: 'Grundlegende Sicherheitsmaßnahmen',
        description: 'Auch ohne Warnungen sollten Sie die Kontoprivatsphäre unter Kontrolle halten und die Familienregeln für die Online-Kommunikation stärken.',
        highPriority: 'Hohe Priorität',
        footer: 'Auch ohne Warnungen sollten Sie diese Praktiken in Ihrer täglichen Routine beibehalten - dies verringert die Wahrscheinlichkeit von Bedrohungen.',
        bullets: ['Überprüfen Sie Chats mindestens einmal täglich, um frühe Anzeichen von Druck oder Betrug zu bemerken', 'Erinnern Sie Kinder regelmäßig daran, keine persönlichen Informationen zu teilen und nicht auf unbekannte Links zu klicken', 'Überprüfen Sie die Datenschutzeinstellungen in den Messenger-Konten der Kinder und beschränken Sie den Profilzugang für Fremde', 'Legen Sie klare Familienregeln fest: mit wem kommuniziert werden darf, welche Themen verboten sind und was bei Verstößen zu tun ist', 'Besprechen Sie Reaktionsszenarien: wen zu kontaktieren und wie verdächtige Kontakte zu blockieren sind']
      },
      generateTitle: 'Personalisierte Empfehlungen erhalten',
      generateDescription: 'Die KI analysiert Ihre Daten und gibt Sicherheitstipps',
      generateButton: 'Empfehlungen generieren',
      analyzing: 'Die KI analysiert Ihre Daten...',
      errorGenerate: 'Empfehlungen konnten nicht generiert werden',
      tryAgain: 'Erneut versuchen',
      refresh: 'Aktualisieren',
      generalRecommendations: 'Allgemeine Empfehlungen',
      usefulMaterials: 'Nützliche Materialien',
      chatRecommendations: 'Chat-Empfehlungen',
      openLink: 'Öffnen',
      priority: {
        high: 'Hohe Priorität',
        medium: 'Mittlere Priorität',
        low: 'Niedrige Priorität'
      }
    },
    parentalControls: {
      title: 'Kindersicherung',
      createProfile: 'Bitte erstellen Sie ein Profil',
      activeSOS: 'Aktives SOS',
      sosSignal: 'SOS-Signal',
      markAsResolved: 'Als gelöst markieren',
      settings: {
        title: 'Haupteinstellungen',
        timeRestrictions: 'Zeitbeschränkungen',
        imageFiltering: 'Bildfilterung',
        blockUnknown: 'Unbekannte blockieren',
        sosNotifications: 'SOS-Benachrichtigungen',
        dailyLimit: 'Nutzungslimit (Min/Tag)',
        save: 'Speichern'
      },
      timeRestrictions: {
        title: 'Zeitbeschränkungen',
        noRestrictions: 'Keine Beschränkungen',
        addRestriction: 'Beschränkung hinzufügen',
        selectDay: 'Wochentag und Uhrzeit auswählen',
        added: 'Beschränkung hinzugefügt (Mo 22:00-07:00)'
      },
      contacts: {
        title: 'Kontakt-Whitelist',
        noContacts: 'Keine Kontakte',
        addContact: 'Kontakt hinzufügen',
        contactName: 'Kontaktname',
        emailOptional: 'E-Mail (optional)',
        enterName: 'Kontaktnamen eingeben',
        contactAdded: 'Kontakt hinzugefügt',
        removeContact: 'Kontakt entfernen?',
        removeConfirm: 'Sind Sie sicher, dass Sie entfernen möchten',
        errorAdd: 'Kontakt konnte nicht hinzugefügt werden'
      },
      guardianEmails: {
        title: 'E-Mails der Erziehungsberechtigten',
        addEmail: 'E-Mail hinzufügen',
        emailAdded: 'E-Mail hinzugefügt',
        enterEmail: 'E-Mail eingeben',
        errorAdd: 'E-Mail konnte nicht hinzugefügt werden'
      },
      errors: {
        enterName: 'Namen eingeben',
        enterValue: 'Gültigen Wert eingeben',
        enterEmail: 'E-Mail eingeben',
        updateFailed: 'Limit konnte nicht aktualisiert werden'
      },
      success: {
        limitUpdated: 'Limit aktualisiert',
        emailAdded: 'E-Mail hinzugefügt',
        contactAdded: 'Kontakt hinzugefügt',
        restrictionAdded: 'Beschränkung hinzugefügt'
      },
      days: ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa']
    },
    chat: {
      notFound: 'Chat nicht gefunden',
      inputPlaceholder: 'Nachricht eingeben...',
      analyzing: '🔍 Nachricht wird analysiert...',
      recording: 'Aufnahme...',
      sosActivated: '🚨 SOS Aktiviert',
      sosMessage: 'Ihre Eltern/Erziehungsberechtigten wurden benachrichtigt. Hilfe ist unterwegs.',
      sosError: 'SOS-Signal konnte nicht gesendet werden',
      error: 'Fehler',
      ok: 'OK',
      reasonsTitle: 'Warnungsgründe:',
      emergencyHelp: 'Notfallhilfe aus dem Chat'
    },
    riskLevels: {
      safe: 'Sicher',
      low: 'Niedrig',
      medium: 'Mittel',
      high: 'Hoch',
      critical: 'Kritisch'
    },
    settings: {
      title: 'Einstellungen',
      language: 'App-Sprache',
      selectLanguage: 'Sprache auswählen'
    },
    about: {
      title: 'Über',
      subtitle: 'KI-Chat-Schutz',
      version: 'Version 1.0.0',
      currentStatus: 'Aktueller Status',
      currentStatusDescription: 'Das Projekt befindet sich in der späten MVP-Phase: Alle Benutzerfunktionen und das Design sind fertig, wir stabilisieren und bereiten die Backend-Integration und Push-Benachrichtigungen vor.',
      stage: 'Phase',
      aiContent: 'KI & Inhalt',
      remainingSteps: 'Verbleibende Schritte',
      aboutApp: 'Über die App',
      aboutAppDescription: 'KIDS ist eine innovative App zur Überwachung und zum Schutz von Kinder-Chats mit künstlicher Intelligenz. Wir helfen Eltern, ihre Kinder vor Online-Bedrohungen zu schützen und gleichzeitig Privatsphäre und Vertrauen zu wahren.',
      publishUrl: 'Veröffentlichungs-URL',
      publishUrlDescription: 'Verwenden Sie den folgenden Link beim Ausfüllen von App Store- oder TestFlight-Formularen — dies ist eine stabile Web-Vorschau des Expo-Projekts.',
      project: 'Projekt',
      clickToOpen: 'Zum Öffnen klicken',
      license: 'Lizenz',
      licenseNotFound: 'LICENSE-Datei nicht gefunden',
      licenseHint1: 'Fügen Sie LICENSE zum Projektstamm hinzu und füllen Sie das Feld "license" in package.json aus, um die gewählte Lizenz zu registrieren.',
      licenseHint2: 'Überprüfen Sie das Vorhandensein der LICENSE-Datei und den Wert "license" in package.json — dies ist der Hauptweg, um zu verstehen, ob eine Lizenz registriert ist.',
      mainFeatures: 'Hauptfunktionen',
      aiMonitoring: 'KI-Nachrichtenüberwachung',
      aiMonitoringDescription: 'Automatische Analyse von Textnachrichten auf Bedrohungen, Mobbing, Gewalt und gefährliche Inhalte mit fortgeschrittenen KI-Modellen',
      imageFiltering: 'Bildfilterung',
      imageFilteringDescription: 'KI-Analyse von Bildern zur Erkennung unangemessener Inhalte: Gewalt, Nacktheit, Extremismus, Waffen und Drogen',
      sosButton: 'SOS-Taste',
      sosButtonDescription: 'Notfallhilfe mit einem Tippen — sofortige Benachrichtigung der Eltern mit Geolokalisierung bei Gefahr',
      timeRestrictions: 'Zeitbeschränkungen',
      timeRestrictionsDescription: 'Anpassbare Nutzungszeitlimits und Zeitpläne für ein gesundes digitales Gleichgewicht',
      contactWhitelist: 'Kontakt-Whitelist',
      contactWhitelistDescription: 'Verwalten Sie erlaubte Kontakte mit der Möglichkeit, unbekannte Gesprächspartner zu blockieren',
      dataEncryption: 'Datenverschlüsselung',
      dataEncryptionDescription: 'Alle Daten werden lokal auf dem Gerät mit Verschlüsselung für maximale Privatsphäre gespeichert',
      coppaCompliance: 'COPPA/GDPR-K Konformität',
      coppaComplianceDescription: 'Vollständige Konformität mit internationalen Standards zum Schutz von Kinderdaten mit detaillierter Protokollierung von Einverständnissen',
      technologies: 'Technologien',
      techAiModels: 'KI-Modelle zur Analyse von Text und Bildern',
      techEncryption: 'Ende-zu-Ende-Verschlüsselung von Nachrichten',
      techStorage: 'Lokale Datenspeicherung mit AsyncStorage',
      techGeolocation: 'Geolokalisierung für Notfälle',
      techVoice: 'Sprachnachrichten mit Transkription',
      techMonitoring: 'Echtzeitüberwachung mit Benachrichtigungen',
      securityPrivacy: 'Sicherheit und Privatsphäre',
      securityPrivacyDescription: 'Wir nehmen Sicherheit und Privatsphäre ernst. Alle Daten werden lokal auf Ihrem Gerät gespeichert. Wir sammeln keine persönlichen Informationen ohne Zustimmung der Eltern. Die KI-Analyse arbeitet mit verschlüsselten Daten, und Sicherheitsmetadaten werden getrennt vom Nachrichteninhalt gespeichert.',
      supportProject: 'Projekt Unterstützen',
      supportProjectDescription: 'KIDS ist ein Open-Source-Projekt zur Kinderschutz. Wenn Ihnen das Projekt gefällt, können Sie seine Entwicklung unterstützen:',
      supportProjectHint: 'Alle Mittel fließen in die Projektentwicklung und Verbesserung der Kindersicherheit',
      support: 'Support',
      supportDescription: 'Wenn Sie Fragen oder Vorschläge haben, kontaktieren Sie uns:',
      email: 'E-Mail: support@kids-app.com',
      website: 'Website: www.kids-app.com',
      footer: '© 2024 KIDS. Alle Rechte vorbehalten.',
      footerSubtext: 'Mit Sorgfalt für die Sicherheit von Kindern gemacht',
      releaseReadiness: 'Veröffentlichungsbereitschaft',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Verbleibend: Push-Benachrichtigungen verbinden, Server-Synchronisierung und Tests auf Geräten.',
      ready: 'Bereit'
    }
  };
},2585,[],"constants/locales/de.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: '保存',
      cancel: '取消',
      delete: '删除',
      edit: '编辑',
      back: '返回',
      loading: '加载中...',
      error: '错误',
      success: '成功',
      confirm: '确认',
      yes: '是',
      no: '否'
    },
    tabs: {
      home: '首页',
      alerts: '警报',
      statistics: '统计',
      recommendations: '推荐',
      profile: '个人资料',
      parentalControls: '家长控制',
      about: '关于'
    },
    profile: {
      title: '编辑个人资料',
      createTitle: '创建个人资料',
      name: '姓名',
      email: '电子邮件',
      role: '角色',
      parent: '家长',
      child: '儿童',
      saveChanges: '保存更改',
      createProfile: '创建个人资料',
      logout: '退出登录',
      logoutConfirm: '您确定要退出登录吗？',
      profileInfo: '个人资料信息',
      created: '创建时间',
      device: '设备',
      enterName: '请输入姓名',
      emailPlaceholder: 'example@email.com',
      errors: {
        nameRequired: '请输入姓名',
        saveFailed: '保存个人资料失败'
      },
      success: {
        updated: '个人资料已更新',
        created: '个人资料已创建'
      },
      language: '语言',
      security: {
        title: '双因素认证',
        subtitle: '在敏感操作前添加第二个批准步骤',
        statusEnabled: '已启用',
        statusDisabled: '已禁用',
        enabled: '双因素认证已启用',
        disabled: '双因素认证已禁用',
        configure: '配置2FA',
        configureDescription: '连接身份验证器应用或短信代码以保护登录和付款。'
      },
      payments: {
        title: '付款偏好',
        subtitle: '选择监护人如何批准购买或订阅',
        selectedLabel: '首选方法',
        empty: '未配置',
        manage: '管理付款方式',
        selectMethod: '选择付款方式',
        methodSelected: '{{method}}现在是您的默认付款方式',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: '银行卡'
        },
        descriptions: {
          applePay: '在Apple设备上即时生物识别确认。',
          googlePay: '从Android设备安全批准付款。',
          card: '使用CVV和短信代码的经典卡片验证。'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'AI聊天保护',
      search: '搜索参与者...',
      filterAll: '全部',
      filterSafe: '安全',
      filterMedium: '中等',
      filterHigh: '高',
      stats: {
        chats: '聊天',
        messages: '消息',
        alerts: '警报'
      },
      lastActivity: '最后活动',
      participants: '参与者',
      message: '消息',
      messages: '消息',
      noResults: '未找到'
    },
    alerts: {
      title: '警报',
      noAlerts: '无警报',
      high: '高',
      medium: '中等',
      low: '低',
      resolved: '已解决',
      active: '活跃',
      activeAlerts: '活跃警报',
      resolvedAlerts: '已解决',
      noActiveAlerts: '无活跃警报',
      allChatsAreSafe: '所有聊天都是安全的',
      reasonsTitle: '警报原因：',
      markAsResolved: '标记为已解决',
      unknownChat: '未知聊天'
    },
    statistics: {
      title: '统计',
      securityTitle: '安全统计',
      overview: '概览',
      totalMessages: '总消息数',
      analyzed: '已分析',
      activeAlerts: '活跃警报',
      resolved: '已解决',
      riskDistribution: '风险分布（消息）',
      chatStatus: '聊天状态',
      overallProgress: '总体进度',
      analysisCoverage: '分析覆盖率',
      alertResolution: '警报解决',
      riskyChats: '风险聊天',
      alertsToday: '今日警报',
      trends: '趋势',
      parent: '家长',
      child: '儿童'
    },
    recommendations: {
      title: 'AI推荐',
      essentialGuidance: {
        title: '基本安全措施',
        description: '即使没有警报，也要保持账户隐私控制并加强在线沟通的家庭规则。',
        highPriority: '高优先级',
        footer: '即使没有警报，也要在日常例行公事中保持这些做法 - 这将降低威胁的可能性。',
        bullets: ['每天至少检查一次聊天，以注意压力或欺诈的早期迹象', '定期提醒儿童不要分享个人信息，不要点击不熟悉的链接', '检查儿童信使账户中的隐私设置，并限制陌生人对个人资料的访问', '制定明确的家庭规则：可以与谁交流，哪些话题被禁止，以及违反时该怎么做', '讨论响应场景：联系谁以及如何阻止可疑联系人']
      },
      generateTitle: '获取个性化推荐',
      generateDescription: 'AI将分析您的数据并提供安全提示',
      generateButton: '生成推荐',
      analyzing: 'AI正在分析您的数据...',
      errorGenerate: '生成推荐失败',
      tryAgain: '重试',
      refresh: '刷新',
      generalRecommendations: '一般推荐',
      usefulMaterials: '有用材料',
      chatRecommendations: '聊天推荐',
      openLink: '打开',
      priority: {
        high: '高优先级',
        medium: '中等优先级',
        low: '低优先级'
      }
    },
    parentalControls: {
      title: '家长控制',
      createProfile: '请创建个人资料',
      activeSOS: '活跃SOS',
      sosSignal: 'SOS信号',
      markAsResolved: '标记为已解决',
      settings: {
        title: '主要设置',
        timeRestrictions: '时间限制',
        imageFiltering: '图像过滤',
        blockUnknown: '阻止未知',
        sosNotifications: 'SOS通知',
        dailyLimit: '使用限制（分钟/天）',
        save: '保存'
      },
      timeRestrictions: {
        title: '时间限制',
        noRestrictions: '无限制',
        addRestriction: '添加限制',
        selectDay: '选择星期几和时间',
        added: '已添加限制（周一 22:00-07:00）'
      },
      contacts: {
        title: '联系人白名单',
        noContacts: '无联系人',
        addContact: '添加联系人',
        contactName: '联系人姓名',
        emailOptional: '电子邮件（可选）',
        enterName: '请输入联系人姓名',
        contactAdded: '已添加联系人',
        removeContact: '删除联系人？',
        removeConfirm: '您确定要删除',
        errorAdd: '添加联系人失败'
      },
      guardianEmails: {
        title: '监护人电子邮件',
        addEmail: '添加电子邮件',
        emailAdded: '已添加电子邮件',
        enterEmail: '请输入电子邮件',
        errorAdd: '添加电子邮件失败'
      },
      errors: {
        enterName: '请输入姓名',
        enterValue: '请输入有效值',
        enterEmail: '请输入电子邮件',
        updateFailed: '更新限制失败'
      },
      success: {
        limitUpdated: '限制已更新',
        emailAdded: '已添加电子邮件',
        contactAdded: '已添加联系人',
        restrictionAdded: '已添加限制'
      },
      days: ['日', '一', '二', '三', '四', '五', '六']
    },
    chat: {
      notFound: '未找到聊天',
      inputPlaceholder: '输入消息...',
      analyzing: '🔍 正在分析消息...',
      recording: '正在录音...',
      sosActivated: '🚨 SOS已激活',
      sosMessage: '您的父母/监护人已收到通知。帮助正在路上。',
      sosError: '发送SOS信号失败',
      error: '错误',
      ok: '确定',
      reasonsTitle: '警报原因：',
      emergencyHelp: '从聊天获取紧急帮助'
    },
    riskLevels: {
      safe: '安全',
      low: '低',
      medium: '中等',
      high: '高',
      critical: '严重'
    },
    settings: {
      title: '设置',
      language: '应用语言',
      selectLanguage: '选择语言'
    },
    about: {
      title: '关于',
      subtitle: 'AI聊天保护',
      version: '版本 1.0.0',
      currentStatus: '当前状态',
      currentStatusDescription: '项目处于后期MVP阶段：所有用户功能和设计都已准备就绪，我们正在稳定并准备后端集成和推送通知。',
      stage: '阶段',
      aiContent: 'AI和内容',
      remainingSteps: '剩余步骤',
      aboutApp: '关于应用',
      aboutAppDescription: 'KIDS是一款使用人工智能监控和保护儿童聊天的创新应用。我们帮助父母保护孩子免受在线威胁，同时保持隐私和信任。',
      publishUrl: '发布URL',
      publishUrlDescription: '在填写App Store或TestFlight表单时使用下面的链接 - 这是Expo项目的稳定网络预览。',
      project: '项目',
      clickToOpen: '点击打开',
      license: '许可证',
      licenseNotFound: '未找到LICENSE文件',
      licenseHint1: '将LICENSE添加到项目根目录，并在package.json中填写"license"字段以记录所选许可证。',
      licenseHint2: '检查package.json中是否存在LICENSE文件和"license"值 - 这是了解是否注册许可证的主要方式。',
      mainFeatures: '主要功能',
      aiMonitoring: 'AI消息监控',
      aiMonitoringDescription: '使用先进的AI模型自动分析文本消息中的威胁、欺凌、暴力和危险内容',
      imageFiltering: '图像过滤',
      imageFilteringDescription: 'AI分析图像以检测不当内容：暴力、裸体、极端主义、武器和毒品',
      sosButton: 'SOS按钮',
      sosButtonDescription: '一键紧急帮助 - 在危险情况下立即通知父母并提供地理位置',
      timeRestrictions: '时间限制',
      timeRestrictionsDescription: '可自定义的使用时间限制和时间表，以实现健康的数字平衡',
      contactWhitelist: '联系人白名单',
      contactWhitelistDescription: '管理允许的联系人，并能够阻止未知对话者',
      dataEncryption: '数据加密',
      dataEncryptionDescription: '所有数据都使用加密本地存储在设备上，以实现最大隐私',
      coppaCompliance: 'COPPA/GDPR-K合规性',
      coppaComplianceDescription: '完全符合国际儿童数据保护标准，并详细记录同意情况',
      technologies: '技术',
      techAiModels: '用于文本和图像分析的AI模型',
      techEncryption: '端到端消息加密',
      techStorage: '使用AsyncStorage的本地数据存储',
      techGeolocation: '紧急情况的地理位置',
      techVoice: '带转录的语音消息',
      techMonitoring: '实时监控和通知',
      securityPrivacy: '安全和隐私',
      securityPrivacyDescription: '我们认真对待安全和隐私。所有数据都本地存储在您的设备上。未经父母同意，我们不会收集个人信息。AI分析使用加密数据，安全元数据与消息内容分开存储。',
      supportProject: '支持项目',
      supportProjectDescription: 'KIDS是一个为保护儿童而创建的开源项目。如果您喜欢这个项目，可以支持其发展：',
      supportProjectHint: '所有资金都用于项目开发和改善儿童安全',
      support: '支持',
      supportDescription: '如果您有疑问或建议，请联系我们：',
      email: '电子邮件：support@kids-app.com',
      website: '网站：www.kids-app.com',
      footer: '© 2024 KIDS。保留所有权利。',
      footerSubtext: '用心为儿童安全而制作',
      releaseReadiness: '发布准备',
      releaseReadinessValue: '80%',
      releaseReadinessHint: '剩余：连接推送通知、服务器同步并在设备上测试。',
      ready: '就绪'
    }
  };
},2586,[],"constants/locales/zh.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Salva',
      cancel: 'Annulla',
      delete: 'Elimina',
      edit: 'Modifica',
      back: 'Indietro',
      loading: 'Caricamento...',
      error: 'Errore',
      success: 'Successo',
      confirm: 'Conferma',
      yes: 'Sì',
      no: 'No'
    },
    tabs: {
      home: 'Home',
      alerts: 'Avvisi',
      statistics: 'Statistiche',
      recommendations: 'Raccomandazioni',
      profile: 'Profilo',
      parentalControls: 'Controllo Parentale',
      about: 'Informazioni'
    },
    profile: {
      title: 'Modifica Profilo',
      createTitle: 'Crea Profilo',
      name: 'Nome',
      email: 'Email',
      role: 'Ruolo',
      parent: 'Genitore',
      child: 'Bambino',
      saveChanges: 'Salva modifiche',
      createProfile: 'Crea profilo',
      logout: 'Esci',
      logoutConfirm: 'Sei sicuro di voler uscire?',
      profileInfo: 'Informazioni del profilo',
      created: 'Creato',
      device: 'Dispositivo',
      enterName: 'Inserisci il nome',
      emailPlaceholder: 'esempio@email.com',
      errors: {
        nameRequired: 'Inserisci il nome',
        saveFailed: 'Impossibile salvare il profilo'
      },
      success: {
        updated: 'Profilo aggiornato',
        created: 'Profilo creato'
      },
      language: 'Lingua',
      security: {
        title: 'Autenticazione a due fattori',
        subtitle: 'Aggiungi un secondo passaggio di approvazione prima di azioni sensibili',
        statusEnabled: 'Abilitato',
        statusDisabled: 'Disabilitato',
        enabled: 'Autenticazione a due fattori abilitata',
        disabled: 'Autenticazione a due fattori disabilitata',
        configure: 'Configura 2FA',
        configureDescription: 'Collega un\'app di autenticazione o codice SMS per proteggere accessi e pagamenti.'
      },
      payments: {
        title: 'Preferenze di pagamento',
        subtitle: 'Scegli come i tutori approvano acquisti o abbonamenti',
        selectedLabel: 'Metodo preferito',
        empty: 'Non configurato',
        manage: 'Gestisci metodi di pagamento',
        selectMethod: 'Seleziona un metodo di pagamento',
        methodSelected: '{{method}} è ora il tuo metodo di pagamento predefinito',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Carta bancaria'
        },
        descriptions: {
          applePay: 'Conferma biometrica istantanea su dispositivi Apple.',
          googlePay: 'Approva pagamenti in modo sicuro da dispositivi Android.',
          card: 'Verifica carta classica con CVV e codici SMS.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'Protezione Chat IA',
      search: 'Cerca partecipanti...',
      filterAll: 'Tutti',
      filterSafe: 'Sicuro',
      filterMedium: 'Medio',
      filterHigh: 'Alto',
      stats: {
        chats: 'Chat',
        messages: 'Messaggi',
        alerts: 'Avvisi'
      },
      lastActivity: 'Ultima attività',
      participants: 'partecipanti',
      message: 'messaggio',
      messages: 'messaggi',
      noResults: 'Nessun risultato'
    },
    alerts: {
      title: 'Avvisi',
      noAlerts: 'Nessun avviso',
      high: 'Alto',
      medium: 'Medio',
      low: 'Basso',
      resolved: 'Risolto',
      active: 'Attivo',
      activeAlerts: 'Avvisi Attivi',
      resolvedAlerts: 'Risolti',
      noActiveAlerts: 'Nessun avviso attivo',
      allChatsAreSafe: 'Tutte le chat sono sicure',
      reasonsTitle: 'Motivi dell\'avviso:',
      markAsResolved: 'Segna come risolto',
      unknownChat: 'Chat sconosciuta'
    },
    statistics: {
      title: 'Statistiche',
      securityTitle: 'Statistiche di Sicurezza',
      overview: 'Panoramica',
      totalMessages: 'Messaggi Totali',
      analyzed: 'Analizzato',
      activeAlerts: 'Avvisi Attivi',
      resolved: 'Risolto',
      riskDistribution: 'Distribuzione del Rischio (messaggi)',
      chatStatus: 'Stato della Chat',
      overallProgress: 'Progresso Generale',
      analysisCoverage: 'Copertura dell\'Analisi',
      alertResolution: 'Risoluzione Avvisi',
      riskyChats: 'Chat a Rischio',
      alertsToday: 'Avvisi Oggi',
      trends: 'Tendenze',
      parent: 'Genitore',
      child: 'Bambino'
    },
    recommendations: {
      title: 'Raccomandazioni IA',
      essentialGuidance: {
        title: 'Misure di Sicurezza di Base',
        description: 'Anche senza avvisi, mantieni la privacy dell\'account sotto controllo e rafforza le regole familiari per la comunicazione online.',
        highPriority: 'Alta Priorità',
        footer: 'Anche senza avvisi, mantieni queste pratiche nella tua routine quotidiana - questo ridurrà la probabilità di minacce.',
        bullets: ['Rivedi le chat almeno una volta al giorno per notare i primi segni di pressione o frode', 'Ricorda regolarmente ai bambini di non condividere informazioni personali e di non cliccare su link sconosciuti', 'Controlla le impostazioni di privacy negli account messenger dei bambini e limita l\'accesso al profilo per estranei', 'Stabilisci regole familiari chiare: con chi si può comunicare, quali argomenti sono vietati e cosa fare in caso di violazione', 'Discuti scenari di risposta: chi contattare e come bloccare contatti sospetti']
      },
      generateTitle: 'Ottieni raccomandazioni personalizzate',
      generateDescription: 'L\'IA analizzerà i tuoi dati e fornirà consigli di sicurezza',
      generateButton: 'Genera raccomandazioni',
      analyzing: 'L\'IA sta analizzando i tuoi dati...',
      errorGenerate: 'Impossibile generare raccomandazioni',
      tryAgain: 'Riprova',
      refresh: 'Aggiorna',
      generalRecommendations: 'Raccomandazioni Generali',
      usefulMaterials: 'Materiali Utili',
      chatRecommendations: 'Raccomandazioni Chat',
      openLink: 'Apri',
      priority: {
        high: 'Alta Priorità',
        medium: 'Priorità Media',
        low: 'Bassa Priorità'
      }
    },
    parentalControls: {
      title: 'Controllo Parentale',
      createProfile: 'Si prega di creare un profilo',
      activeSOS: 'SOS Attivo',
      sosSignal: 'Segnale SOS',
      markAsResolved: 'Segna come risolto',
      settings: {
        title: 'Impostazioni Principali',
        timeRestrictions: 'Restrizioni Temporali',
        imageFiltering: 'Filtraggio Immagini',
        blockUnknown: 'Blocca Sconosciuti',
        sosNotifications: 'Notifiche SOS',
        dailyLimit: 'Limite di Utilizzo (min/giorno)',
        save: 'Salva'
      },
      timeRestrictions: {
        title: 'Restrizioni Temporali',
        noRestrictions: 'Nessuna restrizione',
        addRestriction: 'Aggiungi restrizione',
        selectDay: 'Seleziona il giorno della settimana e l\'ora',
        added: 'Restrizione aggiunta (Lun 22:00-07:00)'
      },
      contacts: {
        title: 'Lista Bianca Contatti',
        noContacts: 'Nessun contatto',
        addContact: 'Aggiungi contatto',
        contactName: 'Nome contatto',
        emailOptional: 'Email (opzionale)',
        enterName: 'Inserisci il nome del contatto',
        contactAdded: 'Contatto aggiunto',
        removeContact: 'Rimuovere contatto?',
        removeConfirm: 'Sei sicuro di voler rimuovere',
        errorAdd: 'Impossibile aggiungere il contatto'
      },
      guardianEmails: {
        title: 'Email dei Tutori',
        addEmail: 'Aggiungi email',
        emailAdded: 'Email aggiunta',
        enterEmail: 'Inserisci l\'email',
        errorAdd: 'Impossibile aggiungere l\'email'
      },
      errors: {
        enterName: 'Inserisci il nome',
        enterValue: 'Inserisci un valore valido',
        enterEmail: 'Inserisci l\'email',
        updateFailed: 'Impossibile aggiornare il limite'
      },
      success: {
        limitUpdated: 'Limite aggiornato',
        emailAdded: 'Email aggiunta',
        contactAdded: 'Contatto aggiunto',
        restrictionAdded: 'Restrizione aggiunta'
      },
      days: ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab']
    },
    chat: {
      notFound: 'Chat non trovata',
      inputPlaceholder: 'Scrivi un messaggio...',
      analyzing: '🔍 Analisi del messaggio...',
      recording: 'Registrazione...',
      sosActivated: '🚨 SOS Attivato',
      sosMessage: 'I tuoi genitori/tutori sono stati notificati. L\'aiuto è in arrivo.',
      sosError: 'Impossibile inviare il segnale SOS',
      error: 'Errore',
      ok: 'OK',
      reasonsTitle: 'Motivi dell\'avviso:',
      emergencyHelp: 'Aiuto di emergenza dalla chat'
    },
    riskLevels: {
      safe: 'Sicuro',
      low: 'Basso',
      medium: 'Medio',
      high: 'Alto',
      critical: 'Critico'
    },
    settings: {
      title: 'Impostazioni',
      language: 'Lingua dell\'App',
      selectLanguage: 'Seleziona Lingua'
    },
    about: {
      title: 'Informazioni',
      subtitle: 'Protezione Chat IA',
      version: 'Versione 1.0.0',
      currentStatus: 'Stato Attuale',
      currentStatusDescription: 'Il progetto è in fase MVP avanzata: tutte le funzionalità utente e il design sono pronti, stiamo stabilizzando e preparando l\'integrazione backend e le notifiche push.',
      stage: 'Fase',
      aiContent: 'IA e Contenuto',
      remainingSteps: 'Passi Rimanenti',
      aboutApp: 'Informazioni sull\'App',
      aboutAppDescription: 'KIDS è un\'app innovativa per monitorare e proteggere le chat dei bambini utilizzando l\'intelligenza artificiale. Aiutiamo i genitori a proteggere i propri figli dalle minacce online mantenendo la privacy e la fiducia.',
      publishUrl: 'URL di Pubblicazione',
      publishUrlDescription: 'Usa il link qui sotto quando compili i moduli App Store o TestFlight — questa è un\'anteprima web stabile del progetto Expo.',
      project: 'Progetto',
      clickToOpen: 'Clicca per aprire',
      license: 'Licenza',
      licenseNotFound: 'File LICENSE non trovato',
      licenseHint1: 'Aggiungi LICENSE alla radice del progetto e compila il campo "license" in package.json per registrare la licenza scelta.',
      licenseHint2: 'Verifica la presenza del file LICENSE e il valore "license" in package.json — questo è il modo principale per capire se una licenza è registrata.',
      mainFeatures: 'Caratteristiche Principali',
      aiMonitoring: 'Monitoraggio Messaggi IA',
      aiMonitoringDescription: 'Analisi automatica dei messaggi di testo per rilevare minacce, bullismo, violenza e contenuti pericolosi utilizzando modelli IA avanzati',
      imageFiltering: 'Filtraggio Immagini',
      imageFilteringDescription: 'Analisi IA delle immagini per rilevare contenuti inappropriati: violenza, nudità, estremismo, armi e droghe',
      sosButton: 'Pulsante SOS',
      sosButtonDescription: 'Aiuto di emergenza con un tocco — notifica istantanea ai genitori con geolocalizzazione in caso di pericolo',
      timeRestrictions: 'Restrizioni Temporali',
      timeRestrictionsDescription: 'Limiti di utilizzo del tempo personalizzabili e orari per un equilibrio digitale sano',
      contactWhitelist: 'Lista Bianca Contatti',
      contactWhitelistDescription: 'Gestisci i contatti consentiti con la possibilità di bloccare interlocutori sconosciuti',
      dataEncryption: 'Crittografia Dati',
      dataEncryptionDescription: 'Tutti i dati sono memorizzati localmente sul dispositivo con crittografia per la massima privacy',
      coppaCompliance: 'Conformità COPPA/GDPR-K',
      coppaComplianceDescription: 'Piena conformità agli standard internazionali di protezione dei dati dei bambini con registrazione dettagliata dei consensi',
      technologies: 'Tecnologie',
      techAiModels: 'Modelli IA per l\'analisi di testo e immagini',
      techEncryption: 'Crittografia end-to-end dei messaggi',
      techStorage: 'Archiviazione dati locale con AsyncStorage',
      techGeolocation: 'Geolocalizzazione per casi di emergenza',
      techVoice: 'Messaggi vocali con trascrizione',
      techMonitoring: 'Monitoraggio in tempo reale con notifiche',
      securityPrivacy: 'Sicurezza e Privacy',
      securityPrivacyDescription: 'Prendiamo sul serio sicurezza e privacy. Tutti i dati sono memorizzati localmente sul tuo dispositivo. Non raccogliamo informazioni personali senza il consenso dei genitori. L\'analisi IA funziona con dati crittografati e i metadati di sicurezza sono memorizzati separatamente dal contenuto dei messaggi.',
      supportProject: 'Supporta il Progetto',
      supportProjectDescription: 'KIDS è un progetto open source creato per proteggere i bambini. Se ti piace il progetto, puoi supportarne lo sviluppo:',
      supportProjectHint: 'Tutti i fondi vanno allo sviluppo del progetto e al miglioramento della sicurezza dei bambini',
      support: 'Supporto',
      supportDescription: 'Se hai domande o suggerimenti, contattaci:',
      email: 'Email: support@kids-app.com',
      website: 'Sito web: www.kids-app.com',
      footer: '© 2024 KIDS. Tutti i diritti riservati.',
      footerSubtext: 'Fatto con cura per la sicurezza dei bambini',
      releaseReadiness: 'Preparazione al Lancio',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Rimanente: connetti notifiche push, sincronizzazione server e test sui dispositivi.',
      ready: 'Pronto'
    }
  };
},2587,[],"constants/locales/it.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: 'Salvar',
      cancel: 'Cancelar',
      delete: 'Excluir',
      edit: 'Editar',
      back: 'Voltar',
      loading: 'Carregando...',
      error: 'Erro',
      success: 'Sucesso',
      confirm: 'Confirmar',
      yes: 'Sim',
      no: 'Não'
    },
    tabs: {
      home: 'Início',
      alerts: 'Alertas',
      statistics: 'Estatísticas',
      recommendations: 'Recomendações',
      profile: 'Perfil',
      parentalControls: 'Controle Parental',
      about: 'Sobre'
    },
    profile: {
      title: 'Editar Perfil',
      createTitle: 'Criar Perfil',
      name: 'Nome',
      email: 'Email',
      role: 'Função',
      parent: 'Pai',
      child: 'Criança',
      saveChanges: 'Salvar alterações',
      createProfile: 'Criar perfil',
      logout: 'Sair',
      logoutConfirm: 'Tem certeza de que deseja sair?',
      profileInfo: 'Informações do perfil',
      created: 'Criado',
      device: 'Dispositivo',
      enterName: 'Digite o nome',
      emailPlaceholder: 'exemplo@email.com',
      errors: {
        nameRequired: 'Digite o nome',
        saveFailed: 'Falha ao salvar o perfil'
      },
      success: {
        updated: 'Perfil atualizado',
        created: 'Perfil criado'
      },
      language: 'Idioma',
      security: {
        title: 'Autenticação de dois fatores',
        subtitle: 'Adicione uma segunda etapa de aprovação antes de ações sensíveis',
        statusEnabled: 'Habilitado',
        statusDisabled: 'Desabilitado',
        enabled: 'Autenticação de dois fatores habilitada',
        disabled: 'Autenticação de dois fatores desabilitada',
        configure: 'Configurar 2FA',
        configureDescription: 'Conecte um aplicativo autenticador ou código SMS para proteger logins e pagamentos.'
      },
      payments: {
        title: 'Preferências de pagamento',
        subtitle: 'Escolha como os tutores aprovam compras ou assinaturas',
        selectedLabel: 'Método preferido',
        empty: 'Não configurado',
        manage: 'Gerenciar métodos de pagamento',
        selectMethod: 'Selecione um método de pagamento',
        methodSelected: '{{method}} é agora seu método de pagamento padrão',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: 'Cartão bancário'
        },
        descriptions: {
          applePay: 'Confirmação biométrica instantânea em dispositivos Apple.',
          googlePay: 'Aprove pagamentos com segurança em dispositivos Android.',
          card: 'Verificação de cartão clássica com CVV e códigos SMS.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'Proteção de Chat com IA',
      search: 'Buscar participantes...',
      filterAll: 'Todos',
      filterSafe: 'Seguro',
      filterMedium: 'Médio',
      filterHigh: 'Alto',
      stats: {
        chats: 'Chats',
        messages: 'Mensagens',
        alerts: 'Alertas'
      },
      lastActivity: 'Última atividade',
      participants: 'participantes',
      message: 'mensagem',
      messages: 'mensagens',
      noResults: 'Nada encontrado'
    },
    alerts: {
      title: 'Alertas',
      noAlerts: 'Sem alertas',
      high: 'Alto',
      medium: 'Médio',
      low: 'Baixo',
      resolved: 'Resolvido',
      active: 'Ativo',
      activeAlerts: 'Alertas Ativos',
      resolvedAlerts: 'Resolvidos',
      noActiveAlerts: 'Sem alertas ativos',
      allChatsAreSafe: 'Todos os chats estão seguros',
      reasonsTitle: 'Motivos do alerta:',
      markAsResolved: 'Marcar como resolvido',
      unknownChat: 'Chat desconhecido'
    },
    statistics: {
      title: 'Estatísticas',
      securityTitle: 'Estatísticas de Segurança',
      overview: 'Visão Geral',
      totalMessages: 'Total de Mensagens',
      analyzed: 'Analisado',
      activeAlerts: 'Alertas Ativos',
      resolved: 'Resolvido',
      riskDistribution: 'Distribuição de Risco (mensagens)',
      chatStatus: 'Status do Chat',
      overallProgress: 'Progresso Geral',
      analysisCoverage: 'Cobertura da Análise',
      alertResolution: 'Resolução de Alertas',
      riskyChats: 'Chats de Risco',
      alertsToday: 'Alertas Hoje',
      trends: 'Tendências',
      parent: 'Pai',
      child: 'Criança'
    },
    recommendations: {
      title: 'Recomendações de IA',
      essentialGuidance: {
        title: 'Medidas Básicas de Segurança',
        description: 'Mesmo sem alertas, mantenha a privacidade da conta sob controle e fortaleça as regras familiares para comunicação online.',
        highPriority: 'Alta Prioridade',
        footer: 'Mesmo sem alertas, mantenha essas práticas em sua rotina diária - isso reduzirá a probabilidade de ameaças.',
        bullets: ['Revise os chats pelo menos uma vez por dia para notar sinais precoces de pressão ou fraude', 'Lembre regularmente as crianças de não compartilhar informações pessoais e não clicar em links desconhecidos', 'Verifique as configurações de privacidade nas contas de mensagens das crianças e restrinja o acesso ao perfil para estranhos', 'Estabeleça regras familiares claras: com quem se pode comunicar, quais tópicos são proibidos e o que fazer em caso de violação', 'Discuta cenários de resposta: quem contatar e como bloquear contatos suspeitos']
      },
      generateTitle: 'Obter recomendações personalizadas',
      generateDescription: 'A IA analisará seus dados e fornecerá dicas de segurança',
      generateButton: 'Gerar recomendações',
      analyzing: 'A IA está analisando seus dados...',
      errorGenerate: 'Falha ao gerar recomendações',
      tryAgain: 'Tentar novamente',
      refresh: 'Atualizar',
      generalRecommendations: 'Recomendações Gerais',
      usefulMaterials: 'Materiais Úteis',
      chatRecommendations: 'Recomendações de Chat',
      openLink: 'Abrir',
      priority: {
        high: 'Alta Prioridade',
        medium: 'Prioridade Média',
        low: 'Baixa Prioridade'
      }
    },
    parentalControls: {
      title: 'Controle Parental',
      createProfile: 'Por favor, crie um perfil',
      activeSOS: 'SOS Ativo',
      sosSignal: 'Sinal SOS',
      markAsResolved: 'Marcar como resolvido',
      settings: {
        title: 'Configurações Principais',
        timeRestrictions: 'Restrições de Tempo',
        imageFiltering: 'Filtragem de Imagens',
        blockUnknown: 'Bloquear Desconhecidos',
        sosNotifications: 'Notificações SOS',
        dailyLimit: 'Limite de Uso (min/dia)',
        save: 'Salvar'
      },
      timeRestrictions: {
        title: 'Restrições de Tempo',
        noRestrictions: 'Sem restrições',
        addRestriction: 'Adicionar restrição',
        selectDay: 'Selecione o dia da semana e a hora',
        added: 'Restrição adicionada (Seg 22:00-07:00)'
      },
      contacts: {
        title: 'Lista Branca de Contatos',
        noContacts: 'Sem contatos',
        addContact: 'Adicionar contato',
        contactName: 'Nome do contato',
        emailOptional: 'Email (opcional)',
        enterName: 'Digite o nome do contato',
        contactAdded: 'Contato adicionado',
        removeContact: 'Remover contato?',
        removeConfirm: 'Tem certeza de que deseja remover',
        errorAdd: 'Falha ao adicionar contato'
      },
      guardianEmails: {
        title: 'Emails dos Tutores',
        addEmail: 'Adicionar email',
        emailAdded: 'Email adicionado',
        enterEmail: 'Digite o email',
        errorAdd: 'Falha ao adicionar email'
      },
      errors: {
        enterName: 'Digite o nome',
        enterValue: 'Digite um valor válido',
        enterEmail: 'Digite o email',
        updateFailed: 'Falha ao atualizar o limite'
      },
      success: {
        limitUpdated: 'Limite atualizado',
        emailAdded: 'Email adicionado',
        contactAdded: 'Contato adicionado',
        restrictionAdded: 'Restrição adicionada'
      },
      days: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']
    },
    chat: {
      notFound: 'Chat não encontrado',
      inputPlaceholder: 'Digite uma mensagem...',
      analyzing: '🔍 Analisando mensagem...',
      recording: 'Gravando...',
      sosActivated: '🚨 SOS Ativado',
      sosMessage: 'Seus pais/tutores foram notificados. A ajuda está a caminho.',
      sosError: 'Falha ao enviar sinal SOS',
      error: 'Erro',
      ok: 'OK',
      reasonsTitle: 'Motivos do alerta:',
      emergencyHelp: 'Ajuda de emergência do chat'
    },
    riskLevels: {
      safe: 'Seguro',
      low: 'Baixo',
      medium: 'Médio',
      high: 'Alto',
      critical: 'Crítico'
    },
    settings: {
      title: 'Configurações',
      language: 'Idioma do Aplicativo',
      selectLanguage: 'Selecionar Idioma'
    },
    about: {
      title: 'Sobre',
      subtitle: 'Proteção de Chat com IA',
      version: 'Versão 1.0.0',
      currentStatus: 'Status Atual',
      currentStatusDescription: 'O projeto está em fase MVP avançada: todas as funcionalidades do usuário e o design estão prontos, estamos estabilizando e preparando a integração do backend e notificações push.',
      stage: 'Fase',
      aiContent: 'IA e Conteúdo',
      remainingSteps: 'Passos Restantes',
      aboutApp: 'Sobre o Aplicativo',
      aboutAppDescription: 'KIDS é um aplicativo inovador para monitorar e proteger chats de crianças usando inteligência artificial. Ajudamos os pais a proteger seus filhos de ameaças online, mantendo a privacidade e a confiança.',
      publishUrl: 'URL de Publicação',
      publishUrlDescription: 'Use o link abaixo ao preencher formulários da App Store ou TestFlight — esta é uma prévia web estável do projeto Expo.',
      project: 'Projeto',
      clickToOpen: 'Clique para abrir',
      license: 'Licença',
      licenseNotFound: 'Arquivo LICENSE não encontrado',
      licenseHint1: 'Adicione LICENSE à raiz do projeto e preencha o campo "license" em package.json para registrar a licença escolhida.',
      licenseHint2: 'Verifique a presença do arquivo LICENSE e o valor "license" em package.json — esta é a principal forma de entender se uma licença está registrada.',
      mainFeatures: 'Recursos Principais',
      aiMonitoring: 'Monitoramento de Mensagens com IA',
      aiMonitoringDescription: 'Análise automática de mensagens de texto para detectar ameaças, bullying, violência e conteúdo perigoso usando modelos avançados de IA',
      imageFiltering: 'Filtragem de Imagens',
      imageFilteringDescription: 'Análise de IA de imagens para detectar conteúdo inadequado: violência, nudez, extremismo, armas e drogas',
      sosButton: 'Botão SOS',
      sosButtonDescription: 'Ajuda de emergência com um toque — notificação instantânea aos pais com geolocalização em caso de perigo',
      timeRestrictions: 'Restrições de Tempo',
      timeRestrictionsDescription: 'Limites de tempo de uso personalizáveis e horários para um equilíbrio digital saudável',
      contactWhitelist: 'Lista Branca de Contatos',
      contactWhitelistDescription: 'Gerencie contatos permitidos com a capacidade de bloquear interlocutores desconhecidos',
      dataEncryption: 'Criptografia de Dados',
      dataEncryptionDescription: 'Todos os dados são armazenados localmente no dispositivo com criptografia para máxima privacidade',
      coppaCompliance: 'Conformidade COPPA/GDPR-K',
      coppaComplianceDescription: 'Conformidade total com os padrões internacionais de proteção de dados de crianças com registro detalhado de consentimentos',
      technologies: 'Tecnologias',
      techAiModels: 'Modelos de IA para análise de texto e imagens',
      techEncryption: 'Criptografia de ponta a ponta de mensagens',
      techStorage: 'Armazenamento local de dados com AsyncStorage',
      techGeolocation: 'Geolocalização para casos de emergência',
      techVoice: 'Mensagens de voz com transcrição',
      techMonitoring: 'Monitoramento em tempo real com notificações',
      securityPrivacy: 'Segurança e Privacidade',
      securityPrivacyDescription: 'Levamos segurança e privacidade a sério. Todos os dados são armazenados localmente em seu dispositivo. Não coletamos informações pessoais sem o consentimento dos pais. A análise de IA funciona com dados criptografados e os metadados de segurança são armazenados separadamente do conteúdo das mensagens.',
      supportProject: 'Apoiar o Projeto',
      supportProjectDescription: 'KIDS é um projeto de código aberto criado para proteger crianças. Se você gosta do projeto, pode apoiar seu desenvolvimento:',
      supportProjectHint: 'Todos os fundos vão para o desenvolvimento do projeto e melhoria da segurança das crianças',
      support: 'Suporte',
      supportDescription: 'Se você tiver perguntas ou sugestões, entre em contato conosco:',
      email: 'Email: support@kids-app.com',
      website: 'Site: www.kids-app.com',
      footer: '© 2024 KIDS. Todos os direitos reservados.',
      footerSubtext: 'Feito com cuidado para a segurança das crianças',
      releaseReadiness: 'Preparação para Lançamento',
      releaseReadinessValue: '80%',
      releaseReadinessHint: 'Restante: conectar notificações push, sincronização do servidor e testar em dispositivos.',
      ready: 'Pronto'
    }
  };
},2588,[],"constants/locales/pt.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: '保存',
      cancel: 'キャンセル',
      delete: '削除',
      edit: '編集',
      back: '戻る',
      loading: '読み込み中...',
      error: 'エラー',
      success: '成功',
      confirm: '確認',
      yes: 'はい',
      no: 'いいえ'
    },
    tabs: {
      home: 'ホーム',
      alerts: 'アラート',
      statistics: '統計',
      recommendations: '推奨事項',
      profile: 'プロフィール',
      parentalControls: 'ペアレンタルコントロール',
      about: 'について'
    },
    profile: {
      title: 'プロフィールを編集',
      createTitle: 'プロフィールを作成',
      name: '名前',
      email: 'メール',
      role: '役割',
      parent: '保護者',
      child: '子供',
      saveChanges: '変更を保存',
      createProfile: 'プロフィールを作成',
      logout: 'ログアウト',
      logoutConfirm: 'ログアウトしてもよろしいですか？',
      profileInfo: 'プロフィール情報',
      created: '作成日',
      device: 'デバイス',
      enterName: '名前を入力',
      emailPlaceholder: 'example@email.com',
      errors: {
        nameRequired: '名前を入力してください',
        saveFailed: 'プロフィールの保存に失敗しました'
      },
      success: {
        updated: 'プロフィールが更新されました',
        created: 'プロフィールが作成されました'
      },
      language: '言語',
      security: {
        title: '二要素認証',
        subtitle: '機密性の高い操作の前に2番目の承認ステップを追加',
        statusEnabled: '有効',
        statusDisabled: '無効',
        enabled: '二要素認証が有効です',
        disabled: '二要素認証が無効です',
        configure: '2FAを設定',
        configureDescription: '認証アプリまたはSMSコードを接続して、ログインと支払いを保護します。'
      },
      payments: {
        title: '支払い設定',
        subtitle: '保護者が購入またはサブスクリプションを承認する方法を選択',
        selectedLabel: '優先方法',
        empty: '未設定',
        manage: '支払い方法を管理',
        selectMethod: '支払い方法を選択',
        methodSelected: '{{method}}がデフォルトの支払い方法になりました',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: '銀行カード'
        },
        descriptions: {
          applePay: 'Appleデバイスでの即座の生体認証確認。',
          googlePay: 'Androidデバイスから安全に支払いを承認。',
          card: 'CVVとSMSコードを使用した従来のカード確認。'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'AIチャット保護',
      search: '参加者を検索...',
      filterAll: 'すべて',
      filterSafe: '安全',
      filterMedium: '中',
      filterHigh: '高',
      stats: {
        chats: 'チャット',
        messages: 'メッセージ',
        alerts: 'アラート'
      },
      lastActivity: '最終アクティビティ',
      participants: '参加者',
      message: 'メッセージ',
      messages: 'メッセージ',
      noResults: '見つかりませんでした'
    },
    alerts: {
      title: 'アラート',
      noAlerts: 'アラートなし',
      high: '高',
      medium: '中',
      low: '低',
      resolved: '解決済み',
      active: 'アクティブ',
      activeAlerts: 'アクティブなアラート',
      resolvedAlerts: '解決済み',
      noActiveAlerts: 'アクティブなアラートなし',
      allChatsAreSafe: 'すべてのチャットは安全です',
      reasonsTitle: 'アラートの理由：',
      markAsResolved: '解決済みとしてマーク',
      unknownChat: '不明なチャット'
    },
    statistics: {
      title: '統計',
      securityTitle: 'セキュリティ統計',
      overview: '概要',
      totalMessages: '総メッセージ数',
      analyzed: '分析済み',
      activeAlerts: 'アクティブなアラート',
      resolved: '解決済み',
      riskDistribution: 'リスク分布（メッセージ）',
      chatStatus: 'チャットステータス',
      overallProgress: '全体的な進捗',
      analysisCoverage: '分析カバレッジ',
      alertResolution: 'アラート解決',
      riskyChats: 'リスクのあるチャット',
      alertsToday: '今日のアラート',
      trends: 'トレンド',
      parent: '保護者',
      child: '子供'
    },
    recommendations: {
      title: 'AI推奨事項',
      essentialGuidance: {
        title: '基本的なセキュリティ対策',
        description: 'アラートがなくても、アカウントのプライバシーを管理し、オンライン通信の家族ルールを強化してください。',
        highPriority: '高優先度',
        footer: 'アラートがなくても、これらの実践を日常のルーチンに保つことで、脅威の可能性を減らします。',
        bullets: ['圧力や詐欺の早期兆候に気づくために、少なくとも1日1回チャットを確認する', '子供に定期的に個人情報を共有しないこと、見知らぬリンクをクリックしないことを思い出させる', '子供のメッセンジャーアカウントのプライバシー設定を確認し、見知らぬ人へのプロフィールアクセスを制限する', '明確な家族ルールを設定：誰とコミュニケーションできるか、どのトピックが禁止されているか、違反の場合に何をするか', '対応シナリオを議論：連絡先と疑わしい連絡先をブロックする方法']
      },
      generateTitle: 'パーソナライズされた推奨事項を取得',
      generateDescription: 'AIがデータを分析し、セキュリティのヒントを提供します',
      generateButton: '推奨事項を生成',
      analyzing: 'AIがデータを分析しています...',
      errorGenerate: '推奨事項の生成に失敗しました',
      tryAgain: '再試行',
      refresh: '更新',
      generalRecommendations: '一般的な推奨事項',
      usefulMaterials: '有用な資料',
      chatRecommendations: 'チャット推奨事項',
      openLink: '開く',
      priority: {
        high: '高優先度',
        medium: '中優先度',
        low: '低優先度'
      }
    },
    parentalControls: {
      title: 'ペアレンタルコントロール',
      createProfile: 'プロフィールを作成してください',
      activeSOS: 'アクティブなSOS',
      sosSignal: 'SOS信号',
      markAsResolved: '解決済みとしてマーク',
      settings: {
        title: 'メイン設定',
        timeRestrictions: '時間制限',
        imageFiltering: '画像フィルタリング',
        blockUnknown: '不明なものをブロック',
        sosNotifications: 'SOS通知',
        dailyLimit: '使用制限（分/日）',
        save: '保存'
      },
      timeRestrictions: {
        title: '時間制限',
        noRestrictions: '制限なし',
        addRestriction: '制限を追加',
        selectDay: '曜日と時間を選択',
        added: '制限が追加されました（月 22:00-07:00）'
      },
      contacts: {
        title: '連絡先ホワイトリスト',
        noContacts: '連絡先なし',
        addContact: '連絡先を追加',
        contactName: '連絡先名',
        emailOptional: 'メール（オプション）',
        enterName: '連絡先名を入力',
        contactAdded: '連絡先が追加されました',
        removeContact: '連絡先を削除しますか？',
        removeConfirm: '削除してもよろしいですか',
        errorAdd: '連絡先の追加に失敗しました'
      },
      guardianEmails: {
        title: '保護者のメール',
        addEmail: 'メールを追加',
        emailAdded: 'メールが追加されました',
        enterEmail: 'メールを入力',
        errorAdd: 'メールの追加に失敗しました'
      },
      errors: {
        enterName: '名前を入力してください',
        enterValue: '有効な値を入力してください',
        enterEmail: 'メールを入力してください',
        updateFailed: '制限の更新に失敗しました'
      },
      success: {
        limitUpdated: '制限が更新されました',
        emailAdded: 'メールが追加されました',
        contactAdded: '連絡先が追加されました',
        restrictionAdded: '制限が追加されました'
      },
      days: ['日', '月', '火', '水', '木', '金', '土']
    },
    chat: {
      notFound: 'チャットが見つかりません',
      inputPlaceholder: 'メッセージを入力...',
      analyzing: '🔍 メッセージを分析中...',
      recording: '録音中...',
      sosActivated: '🚨 SOSが有効化されました',
      sosMessage: '保護者に通知されました。助けが向かっています。',
      sosError: 'SOS信号の送信に失敗しました',
      error: 'エラー',
      ok: 'OK',
      reasonsTitle: 'アラートの理由：',
      emergencyHelp: 'チャットからの緊急支援'
    },
    riskLevels: {
      safe: '安全',
      low: '低',
      medium: '中',
      high: '高',
      critical: '重大'
    },
    settings: {
      title: '設定',
      language: 'アプリの言語',
      selectLanguage: '言語を選択'
    },
    about: {
      title: 'について',
      subtitle: 'AIチャット保護',
      version: 'バージョン 1.0.0',
      currentStatus: '現在のステータス',
      currentStatusDescription: 'プロジェクトは後期MVP段階にあります：すべてのユーザー機能とデザインが準備できており、バックエンド統合とプッシュ通知の準備を安定化しています。',
      stage: '段階',
      aiContent: 'AIとコンテンツ',
      remainingSteps: '残りのステップ',
      aboutApp: 'アプリについて',
      aboutAppDescription: 'KIDSは、人工知能を使用して子供のチャットを監視および保護する革新的なアプリです。プライバシーと信頼を維持しながら、親が子供をオンラインの脅威から保護するのを支援します。',
      publishUrl: '公開URL',
      publishUrlDescription: 'App StoreまたはTestFlightフォームに記入する際に、以下のリンクを使用してください — これはExpoプロジェクトの安定したWebプレビューです。',
      project: 'プロジェクト',
      clickToOpen: 'クリックして開く',
      license: 'ライセンス',
      licenseNotFound: 'LICENSEファイルが見つかりません',
      licenseHint1: 'プロジェクトのルートにLICENSEを追加し、package.jsonの「license」フィールドに記入して、選択したライセンスを記録します。',
      licenseHint2: 'package.jsonにLICENSEファイルと「license」値の存在を確認してください — これはライセンスが登録されているかどうかを理解する主な方法です。',
      mainFeatures: '主な機能',
      aiMonitoring: 'AIメッセージ監視',
      aiMonitoringDescription: '高度なAIモデルを使用して、テキストメッセージの脅威、いじめ、暴力、危険なコンテンツを自動分析',
      imageFiltering: '画像フィルタリング',
      imageFilteringDescription: '不適切なコンテンツを検出するための画像のAI分析：暴力、ヌード、過激主義、武器、薬物',
      sosButton: 'SOSボタン',
      sosButtonDescription: 'ワンタップで緊急支援 — 危険な場合の保護者への即座の通知と位置情報',
      timeRestrictions: '時間制限',
      timeRestrictionsDescription: '健康的なデジタルバランスのためのカスタマイズ可能な使用時間制限とスケジュール',
      contactWhitelist: '連絡先ホワイトリスト',
      contactWhitelistDescription: '不明な対話者をブロックする機能を備えた許可された連絡先を管理',
      dataEncryption: 'データ暗号化',
      dataEncryptionDescription: 'すべてのデータは、最大のプライバシーのために暗号化を使用してデバイスにローカルに保存されます',
      coppaCompliance: 'COPPA/GDPR-K準拠',
      coppaComplianceDescription: '詳細な同意ログ記録を備えた国際的な児童データ保護基準への完全な準拠',
      technologies: 'テクノロジー',
      techAiModels: 'テキストと画像分析のためのAIモデル',
      techEncryption: 'エンドツーエンドメッセージ暗号化',
      techStorage: 'AsyncStorageを使用したローカルデータストレージ',
      techGeolocation: '緊急事態の位置情報',
      techVoice: '転写付き音声メッセージ',
      techMonitoring: '通知付きリアルタイム監視',
      securityPrivacy: 'セキュリティとプライバシー',
      securityPrivacyDescription: 'セキュリティとプライバシーを真剣に受け止めています。すべてのデータはデバイスにローカルに保存されます。保護者の同意なしに個人情報を収集することはありません。AI分析は暗号化されたデータで動作し、セキュリティメタデータはメッセージコンテンツとは別に保存されます。',
      supportProject: 'プロジェクトをサポート',
      supportProjectDescription: 'KIDSは、子供を保護するために作成されたオープンソースプロジェクトです。プロジェクトが気に入った場合は、その開発をサポートできます：',
      supportProjectHint: 'すべての資金はプロジェクト開発と子供の安全性向上に使われます',
      support: 'サポート',
      supportDescription: 'ご質問やご提案がございましたら、お問い合わせください：',
      email: 'メール：support@kids-app.com',
      website: 'ウェブサイト：www.kids-app.com',
      footer: '© 2024 KIDS。全著作権所有。',
      footerSubtext: '子供の安全のために心を込めて作られました',
      releaseReadiness: 'リリース準備',
      releaseReadinessValue: '80%',
      releaseReadinessHint: '残り：プッシュ通知の接続、サーバー同期、デバイスでのテスト。',
      ready: '準備完了'
    }
  };
},2589,[],"constants/locales/ja.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    common: {
      save: '저장',
      cancel: '취소',
      delete: '삭제',
      edit: '편집',
      back: '뒤로',
      loading: '로딩 중...',
      error: '오류',
      success: '성공',
      confirm: '확인',
      yes: '예',
      no: '아니오'
    },
    tabs: {
      home: '홈',
      alerts: '알림',
      statistics: '통계',
      recommendations: '추천',
      profile: '프로필',
      parentalControls: '부모 제어',
      about: '정보'
    },
    profile: {
      title: '프로필 편집',
      createTitle: '프로필 만들기',
      name: '이름',
      email: '이메일',
      role: '역할',
      parent: '부모',
      child: '자녀',
      saveChanges: '변경 사항 저장',
      createProfile: '프로필 만들기',
      logout: '로그아웃',
      logoutConfirm: '로그아웃하시겠습니까?',
      profileInfo: '프로필 정보',
      created: '생성일',
      device: '기기',
      enterName: '이름을 입력하세요',
      emailPlaceholder: 'example@email.com',
      errors: {
        nameRequired: '이름을 입력하세요',
        saveFailed: '프로필 저장 실패'
      },
      success: {
        updated: '프로필이 업데이트되었습니다',
        created: '프로필이 생성되었습니다'
      },
      language: '언어',
      security: {
        title: '이중 인증',
        subtitle: '민감한 작업 전에 두 번째 승인 단계 추가',
        statusEnabled: '활성화됨',
        statusDisabled: '비활성화됨',
        enabled: '이중 인증이 활성화되었습니다',
        disabled: '이중 인증이 비활성화되었습니다',
        configure: '2FA 설정',
        configureDescription: '인증 앱 또는 SMS 코드를 연결하여 로그인 및 결제를 보호합니다.'
      },
      payments: {
        title: '결제 기본 설정',
        subtitle: '보호자가 구매 또는 구독을 승인하는 방법 선택',
        selectedLabel: '기본 방법',
        empty: '설정되지 않음',
        manage: '결제 방법 관리',
        selectMethod: '결제 방법 선택',
        methodSelected: '{{method}}이(가) 기본 결제 방법으로 설정되었습니다',
        methods: {
          applePay: 'Apple Pay',
          googlePay: 'Google Pay',
          card: '은행 카드'
        },
        descriptions: {
          applePay: 'Apple 기기에서 즉시 생체 인증 확인.',
          googlePay: 'Android 기기에서 안전하게 결제 승인.',
          card: 'CVV 및 SMS 코드를 사용한 클래식 카드 확인.'
        }
      }
    },
    home: {
      title: 'KIDS',
      subtitle: 'AI 채팅 보호',
      search: '참가자 검색...',
      filterAll: '전체',
      filterSafe: '안전',
      filterMedium: '보통',
      filterHigh: '높음',
      stats: {
        chats: '채팅',
        messages: '메시지',
        alerts: '알림'
      },
      lastActivity: '마지막 활동',
      participants: '참가자',
      message: '메시지',
      messages: '메시지',
      noResults: '결과 없음'
    },
    alerts: {
      title: '알림',
      noAlerts: '알림 없음',
      high: '높음',
      medium: '보통',
      low: '낮음',
      resolved: '해결됨',
      active: '활성',
      activeAlerts: '활성 알림',
      resolvedAlerts: '해결됨',
      noActiveAlerts: '활성 알림 없음',
      allChatsAreSafe: '모든 채팅이 안전합니다',
      reasonsTitle: '알림 이유:',
      markAsResolved: '해결됨으로 표시',
      unknownChat: '알 수 없는 채팅'
    },
    statistics: {
      title: '통계',
      securityTitle: '보안 통계',
      overview: '개요',
      totalMessages: '총 메시지',
      analyzed: '분석됨',
      activeAlerts: '활성 알림',
      resolved: '해결됨',
      riskDistribution: '위험 분포 (메시지)',
      chatStatus: '채팅 상태',
      overallProgress: '전체 진행률',
      analysisCoverage: '분석 범위',
      alertResolution: '알림 해결',
      riskyChats: '위험한 채팅',
      alertsToday: '오늘의 알림',
      trends: '트렌드',
      parent: '부모',
      child: '자녀'
    },
    recommendations: {
      title: 'AI 추천',
      essentialGuidance: {
        title: '기본 보안 조치',
        description: '알림이 없어도 계정 개인정보를 제어하고 온라인 커뮤니케이션을 위한 가족 규칙을 강화하세요.',
        highPriority: '높은 우선순위',
        footer: '알림이 없어도 이러한 관행을 일상 루틴에 유지하면 위협 가능성을 줄일 수 있습니다.',
        bullets: ['압박이나 사기의 조기 징후를 발견하기 위해 하루에 최소 한 번 채팅을 검토하세요', '자녀에게 정기적으로 개인 정보를 공유하지 말고 익숙하지 않은 링크를 클릭하지 말라고 상기시키세요', '자녀의 메신저 계정의 개인정보 설정을 확인하고 낯선 사람의 프로필 액세스를 제한하세요', '명확한 가족 규칙을 설정하세요: 누구와 소통할 수 있는지, 어떤 주제가 금지되어 있는지, 위반 시 어떻게 할지', '대응 시나리오를 논의하세요: 누구에게 연락하고 의심스러운 연락처를 차단하는 방법']
      },
      generateTitle: '맞춤 추천 받기',
      generateDescription: 'AI가 데이터를 분석하고 보안 팁을 제공합니다',
      generateButton: '추천 생성',
      analyzing: 'AI가 데이터를 분석 중입니다...',
      errorGenerate: '추천 생성 실패',
      tryAgain: '다시 시도',
      refresh: '새로고침',
      generalRecommendations: '일반 추천',
      usefulMaterials: '유용한 자료',
      chatRecommendations: '채팅 추천',
      openLink: '열기',
      priority: {
        high: '높은 우선순위',
        medium: '보통 우선순위',
        low: '낮은 우선순위'
      }
    },
    parentalControls: {
      title: '부모 제어',
      createProfile: '프로필을 만드세요',
      activeSOS: '활성 SOS',
      sosSignal: 'SOS 신호',
      markAsResolved: '해결됨으로 표시',
      settings: {
        title: '주요 설정',
        timeRestrictions: '시간 제한',
        imageFiltering: '이미지 필터링',
        blockUnknown: '알 수 없는 사용자 차단',
        sosNotifications: 'SOS 알림',
        dailyLimit: '사용 제한 (분/일)',
        save: '저장'
      },
      timeRestrictions: {
        title: '시간 제한',
        noRestrictions: '제한 없음',
        addRestriction: '제한 추가',
        selectDay: '요일과 시간 선택',
        added: '제한이 추가되었습니다 (월 22:00-07:00)'
      },
      contacts: {
        title: '연락처 화이트리스트',
        noContacts: '연락처 없음',
        addContact: '연락처 추가',
        contactName: '연락처 이름',
        emailOptional: '이메일 (선택사항)',
        enterName: '연락처 이름을 입력하세요',
        contactAdded: '연락처가 추가되었습니다',
        removeContact: '연락처를 제거하시겠습니까?',
        removeConfirm: '제거하시겠습니까',
        errorAdd: '연락처 추가 실패'
      },
      guardianEmails: {
        title: '보호자 이메일',
        addEmail: '이메일 추가',
        emailAdded: '이메일이 추가되었습니다',
        enterEmail: '이메일을 입력하세요',
        errorAdd: '이메일 추가 실패'
      },
      errors: {
        enterName: '이름을 입력하세요',
        enterValue: '유효한 값을 입력하세요',
        enterEmail: '이메일을 입력하세요',
        updateFailed: '제한 업데이트 실패'
      },
      success: {
        limitUpdated: '제한이 업데이트되었습니다',
        emailAdded: '이메일이 추가되었습니다',
        contactAdded: '연락처가 추가되었습니다',
        restrictionAdded: '제한이 추가되었습니다'
      },
      days: ['일', '월', '화', '수', '목', '금', '토']
    },
    chat: {
      notFound: '채팅을 찾을 수 없습니다',
      inputPlaceholder: '메시지 입력...',
      analyzing: '🔍 메시지 분석 중...',
      recording: '녹음 중...',
      sosActivated: '🚨 SOS 활성화됨',
      sosMessage: '부모/보호자에게 알림이 전송되었습니다. 도움이 향하고 있습니다.',
      sosError: 'SOS 신호 전송 실패',
      error: '오류',
      ok: '확인',
      reasonsTitle: '알림 이유:',
      emergencyHelp: '채팅에서 긴급 도움'
    },
    riskLevels: {
      safe: '안전',
      low: '낮음',
      medium: '보통',
      high: '높음',
      critical: '심각'
    },
    settings: {
      title: '설정',
      language: '앱 언어',
      selectLanguage: '언어 선택'
    },
    about: {
      title: '정보',
      subtitle: 'AI 채팅 보호',
      version: '버전 1.0.0',
      currentStatus: '현재 상태',
      currentStatusDescription: '프로젝트는 후기 MVP 단계에 있습니다: 모든 사용자 기능과 디자인이 준비되었으며, 백엔드 통합 및 푸시 알림 준비를 안정화하고 있습니다.',
      stage: '단계',
      aiContent: 'AI 및 콘텐츠',
      remainingSteps: '남은 단계',
      aboutApp: '앱 정보',
      aboutAppDescription: 'KIDS는 인공 지능을 사용하여 자녀의 채팅을 모니터링하고 보호하는 혁신적인 앱입니다. 개인정보 보호와 신뢰를 유지하면서 부모가 자녀를 온라인 위협으로부터 보호하도록 돕습니다.',
      publishUrl: '게시 URL',
      publishUrlDescription: 'App Store 또는 TestFlight 양식을 작성할 때 아래 링크를 사용하세요 — 이것은 Expo 프로젝트의 안정적인 웹 미리보기입니다.',
      project: '프로젝트',
      clickToOpen: '클릭하여 열기',
      license: '라이선스',
      licenseNotFound: 'LICENSE 파일을 찾을 수 없습니다',
      licenseHint1: '프로젝트 루트에 LICENSE를 추가하고 package.json의 "license" 필드를 채워 선택한 라이선스를 기록하세요.',
      licenseHint2: 'package.json에 LICENSE 파일과 "license" 값의 존재를 확인하세요 — 이것은 라이선스가 등록되었는지 이해하는 주요 방법입니다.',
      mainFeatures: '주요 기능',
      aiMonitoring: 'AI 메시지 모니터링',
      aiMonitoringDescription: '고급 AI 모델을 사용하여 텍스트 메시지의 위협, 괴롭힘, 폭력 및 위험한 콘텐츠를 자동 분석',
      imageFiltering: '이미지 필터링',
      imageFilteringDescription: '부적절한 콘텐츠를 감지하기 위한 이미지의 AI 분석: 폭력, 노출, 극단주의, 무기 및 마약',
      sosButton: 'SOS 버튼',
      sosButtonDescription: '한 번의 탭으로 긴급 도움 — 위험한 경우 부모에게 위치 정보와 함께 즉시 알림',
      timeRestrictions: '시간 제한',
      timeRestrictionsDescription: '건강한 디지털 균형을 위한 사용자 지정 가능한 사용 시간 제한 및 일정',
      contactWhitelist: '연락처 화이트리스트',
      contactWhitelistDescription: '알 수 없는 대화 상대를 차단하는 기능을 사용하여 허용된 연락처 관리',
      dataEncryption: '데이터 암호화',
      dataEncryptionDescription: '모든 데이터는 최대 개인정보 보호를 위해 암호화를 사용하여 기기에 로컬로 저장됩니다',
      coppaCompliance: 'COPPA/GDPR-K 준수',
      coppaComplianceDescription: '상세한 동의 로깅을 포함한 국제 아동 데이터 보호 표준을 완전히 준수',
      technologies: '기술',
      techAiModels: '텍스트 및 이미지 분석을 위한 AI 모델',
      techEncryption: '엔드투엔드 메시지 암호화',
      techStorage: 'AsyncStorage를 사용한 로컬 데이터 저장',
      techGeolocation: '긴급 상황을 위한 위치 정보',
      techVoice: '전사가 포함된 음성 메시지',
      techMonitoring: '알림이 포함된 실시간 모니터링',
      securityPrivacy: '보안 및 개인정보 보호',
      securityPrivacyDescription: '보안 및 개인정보 보호를 진지하게 받아들입니다. 모든 데이터는 기기에 로컬로 저장됩니다. 부모의 동의 없이 개인 정보를 수집하지 않습니다. AI 분석은 암호화된 데이터로 작동하며 보안 메타데이터는 메시지 콘텐츠와 별도로 저장됩니다.',
      supportProject: '프로젝트 지원',
      supportProjectDescription: 'KIDS는 자녀를 보호하기 위해 만들어진 오픈 소스 프로젝트입니다. 프로젝트가 마음에 드시면 개발을 지원할 수 있습니다:',
      supportProjectHint: '모든 자금은 프로젝트 개발 및 자녀 안전 개선에 사용됩니다',
      support: '지원',
      supportDescription: '질문이나 제안이 있으시면 문의하세요:',
      email: '이메일: support@kids-app.com',
      website: '웹사이트: www.kids-app.com',
      footer: '© 2024 KIDS. 모든 권리 보유.',
      footerSubtext: '자녀의 안전을 위해 정성스럽게 만들었습니다',
      releaseReadiness: '릴리스 준비',
      releaseReadinessValue: '80%',
      releaseReadinessHint: '남은 작업: 푸시 알림 연결, 서버 동기화 및 기기에서 테스트.',
      ready: '준비됨'
    }
  };
},2590,[],"constants/locales/ko.ts");
//# sourceMappingURL=http://localhost:8082/constants/i18n.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false